package com.roguelite.client;

import com.roguelite.Roguelite;
import com.roguelite.net.RunSummaryPayload;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** End-of-run summary. Shown after death; the player is in spectator mode behind it. */
public class RunSummaryScreen extends Screen {
	private static final int WHITE = 0xFFFFFFFF;
	private static final int GRAY = 0xFFAAAAAA;
	private static final int GREEN = 0xFF55FF55;
	private static final int GOLD = 0xFFFFAA00;

	private final RunSummaryPayload summary;

	public RunSummaryScreen(RunSummaryPayload summary) {
		super(Text.literal("Run over"));
		this.summary = summary;
	}

	@Override
	protected void init() {
		this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> this.close())
			.dimensions(this.width / 2 - 100, this.height - 35, 200, 20).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		String symbol = Roguelite.CURRENCY_SYMBOL;
		int centerX = this.width / 2;
		int y = 18;

		context.drawCenteredTextWithShadow(this.textRenderer,
			Text.literal(String.format("RUN #%06d OVER", summary.runId())), centerX, y, WHITE);
		y += 14;
		context.drawCenteredTextWithShadow(this.textRenderer,
			Text.literal(summary.starterName() + "  |  " + summary.modifierName()), centerX, y, GOLD);
		y += 12;
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(summary.endReason()), centerX, y, GRAY);
		y += 20;

		int left = centerX - 110;
		int right = centerX + 110;
		for (RunSummaryPayload.SummaryLine line : summary.lines()) {
			context.drawTextWithShadow(this.textRenderer, Text.literal(line.label()), left, y, WHITE);
			String pts = "+" + line.points() + " " + symbol;
			context.drawTextWithShadow(this.textRenderer, Text.literal(pts), right - this.textRenderer.getWidth(pts), y, GREEN);
			y += 11;
		}
		if (summary.lines().isEmpty()) {
			context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Nothing earned this run."), centerX, y, GRAY);
			y += 11;
		}

		y += 8;
		if (summary.balanceBefore() >= 0) {
			context.drawCenteredTextWithShadow(this.textRenderer,
				Text.literal("Balance before this run: " + summary.balanceBefore() + " " + symbol), centerX, y, GRAY);
			y += 11;
		}
		if (summary.starterCost() >= 0) {
			String cost = summary.starterCost() == 0 ? "free" : "-" + summary.starterCost() + " " + symbol;
			context.drawCenteredTextWithShadow(this.textRenderer,
				Text.literal("Starter cost: " + cost), centerX, y, GRAY);
			y += 11;
		}
		context.drawCenteredTextWithShadow(this.textRenderer,
			Text.literal("Run score: +" + summary.total() + " " + symbol), centerX, y, WHITE);
		y += 11;
		if (summary.paid() < summary.total()) {
			context.drawCenteredTextWithShadow(this.textRenderer,
				Text.literal("Nothing added (already banked, or profile could not be saved)."), centerX, y, GRAY);
			y += 11;
		}
		context.drawCenteredTextWithShadow(this.textRenderer,
			Text.literal("Balance now: " + summary.balance() + " " + symbol), centerX, y, GOLD);
		y += 20;
		context.drawCenteredTextWithShadow(this.textRenderer,
			Text.literal("Create a new world to start your next run."), centerX, y, GRAY);
	}
}

package com.roguelite.client;

import com.roguelite.net.OpenStarterScreenPayload;
import com.roguelite.net.RunSummaryPayload;
import com.roguelite.net.StartResultPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class RogueliteClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientPlayNetworking.registerGlobalReceiver(OpenStarterScreenPayload.ID, (payload, context) ->
			context.client().setScreen(new StarterSelectScreen(payload.balance(), payload.starters())));

		ClientPlayNetworking.registerGlobalReceiver(StartResultPayload.ID, (payload, context) -> {
			if (payload.ok()) {
				// Run started: close the starter screen.
				if (context.client().currentScreen instanceof StarterSelectScreen) {
					context.client().setScreen(null);
				}
			} else if (context.client().currentScreen instanceof StarterSelectScreen screen) {
				screen.showError(payload.message());
			}
		});

		ClientPlayNetworking.registerGlobalReceiver(RunSummaryPayload.ID, (payload, context) ->
			context.client().setScreen(new RunSummaryScreen(payload)));
	}
}

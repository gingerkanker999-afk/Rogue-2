package com.roguelite.client;

import com.roguelite.Roguelite;
import com.roguelite.net.OpenStarterScreenPayload;
import com.roguelite.net.StartRunRequestPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Starter selection. Presentation only: it shows what the server sent and sends back a request;
 * the server decides whether the purchase is valid.
 */
public class StarterSelectScreen extends Screen {
	private static final int WHITE = 0xFFFFFFFF;
	private static final int GRAY = 0xFFAAAAAA;
	private static final int RED = 0xFFFF5555;
	private static final int GOLD = 0xFFFFAA00;

	private final int balance;
	private final List<OpenStarterScreenPayload.StarterEntry> starters;
	private int selected = 0;
	private boolean waiting = false;
	private String error = null;

	public StarterSelectScreen(int balance, List<OpenStarterScreenPayload.StarterEntry> starters) {
		super(Text.literal("Choose your starter"));
		this.balance = balance;
		this.starters = starters;
	}

	public void showError(String message) {
		this.error = message;
		this.waiting = false;
		this.clearAndInit();
	}

	@Override
	protected void init() {
		int centerX = this.width / 2;
		int buttonWidth = 240;
		int top = 50;

		for (int i = 0; i < starters.size(); i++) {
			final int index = i;
			OpenStarterScreenPayload.StarterEntry entry = starters.get(i);
			String label = (index == selected ? "> " : "  ") + entry.name() + "  -  " + entry.cost() + " " + Roguelite.CURRENCY_SYMBOL;
			ButtonWidget button = ButtonWidget.builder(Text.literal(label), b -> {
				if (waiting) return;
				selected = index;
				error = null;
				this.clearAndInit();
			}).dimensions(centerX - buttonWidth / 2, top + i * 24, buttonWidth, 20).build();
			this.addDrawableChild(button);
		}

		boolean canAfford = !starters.isEmpty() && starters.get(selected).cost() <= balance;
		ButtonWidget confirm = ButtonWidget.builder(Text.literal(waiting ? "Starting..." : "Start Run"), b -> {
			if (waiting || starters.isEmpty()) return;
			waiting = true;
			error = null;
			ClientPlayNetworking.send(new StartRunRequestPayload(starters.get(selected).id()));
			this.clearAndInit();
		}).dimensions(centerX - 100, this.height - 56, 200, 20).build();
		confirm.active = canAfford && !waiting;
		this.addDrawableChild(confirm);

		this.addDrawableChild(ButtonWidget.builder(Text.literal("Not now"), b -> this.close())
			.dimensions(centerX - 100, this.height - 18, 200, 14).build());
	}

	/** Esc / "Not now": leave without starting. The player can reopen this with /roguelite start. */
	@Override
	public void close() {
		if (this.client != null && this.client.player != null) {
			this.client.player.sendMessage(Text.literal("No run started. Type /roguelite start to choose a starter."), false);
		}
		super.close();
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		int centerX = this.width / 2;
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, centerX, 15, WHITE);
		context.drawCenteredTextWithShadow(this.textRenderer,
			Text.literal("Balance: " + balance + " " + Roguelite.CURRENCY_SYMBOL), centerX, 30, GOLD);

		if (!starters.isEmpty()) {
			OpenStarterScreenPayload.StarterEntry entry = starters.get(selected);
			int y = 50 + starters.size() * 24 + 8;
			context.drawCenteredTextWithShadow(this.textRenderer,
				Text.literal("Modifier pool: " + entry.poolLabel()), centerX, y, WHITE);
			y += 14;
			List<OrderedText> lines = this.textRenderer.wrapLines(Text.literal(entry.description()), 260);
			for (OrderedText line : lines) {
				int lineWidth = this.textRenderer.getWidth(line);
				context.drawTextWithShadow(this.textRenderer, line, centerX - lineWidth / 2, y, GRAY);
				y += 10;
			}
			if (entry.cost() > balance) {
				context.drawCenteredTextWithShadow(this.textRenderer,
					Text.literal("Not enough " + Roguelite.CURRENCY_SYMBOL), centerX, y + 6, RED);
			}
		}

		if (error != null) {
			context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(error), centerX, this.height - 70, RED);
		}
	}

}

package com.roguelite.client;

import com.roguelite.gambling.session.ButtonSpec;
import com.roguelite.net.GamblingActionPayload;
import com.roguelite.net.GamblingScreenPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * A generic server-driven screen: the server decides the title, the text lines and the buttons, and this class just
 * draws them and reports which button was pressed. Esc or closing it tells the server you left the table.
 */
public class GamblingScreen extends Screen {
	private static final int WHITE = 0xFFFFFFFF;
	private static final int RED = 0xFFFF5555;
	private static final int GOLD = 0xFFFFAA00;
	private static final int LINE_HEIGHT = 11;

	private GamblingScreenPayload data;
	private boolean waiting = false;
	private boolean leaving = false;
	private List<OrderedText> wrappedLines = new ArrayList<>();
	private List<Integer> wrappedColors = new ArrayList<>();

	public GamblingScreen(GamblingScreenPayload data) {
		super(Text.literal(data.title()));
		this.data = data;
	}

	/** The server sent a new screen state. */
	public void update(GamblingScreenPayload newData) {
		this.data = newData;
		this.waiting = false;
		this.clearAndInit();
	}

	@Override
	protected void init() {
		wrappedLines = new ArrayList<>();
		wrappedColors = new ArrayList<>();
		for (String line : data.lines()) {
			int color = line.startsWith("!") ? RED : WHITE;
			for (OrderedText part : this.textRenderer.wrapLines(Text.literal(line), 320)) {
				wrappedLines.add(part);
				wrappedColors.add(color);
			}
		}

		int centerX = this.width / 2;
		int startY = 34 + wrappedLines.size() * LINE_HEIGHT + 12;
		int buttonWidth = 200;
		int rowHeight = 24;
		int rows = Math.max(1, (this.height - 12 - startY) / rowHeight);
		int count = data.buttons().size();
		int columns = Math.max(1, (count + rows - 1) / rows);
		int totalWidth = columns * buttonWidth + (columns - 1) * 8;
		int left = centerX - totalWidth / 2;

		for (int i = 0; i < count; i++) {
			ButtonSpec spec = data.buttons().get(i);
			int column = i / rows;
			int row = i % rows;
			ButtonWidget button = ButtonWidget.builder(Text.literal(spec.label()), b -> {
				if (waiting) return;
				waiting = true;
				ClientPlayNetworking.send(new GamblingActionPayload(spec.action(), spec.arg(), spec.amount()));
			}).dimensions(left + column * (buttonWidth + 8), startY + row * rowHeight, buttonWidth, 20).build();
			this.addDrawableChild(button);
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		int centerX = this.width / 2;
		context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(data.title()), centerX, 14, GOLD);
		int y = 34;
		for (int i = 0; i < wrappedLines.size(); i++) {
			OrderedText line = wrappedLines.get(i);
			int lineWidth = this.textRenderer.getWidth(line);
			context.drawTextWithShadow(this.textRenderer, line, centerX - lineWidth / 2, y, wrappedColors.get(i));
			y += LINE_HEIGHT;
		}
	}

	/** Esc: leave the table. The server finishes any round in progress for you. */
	@Override
	public void close() {
		if (!leaving) {
			leaving = true;
			ClientPlayNetworking.send(new GamblingActionPayload("leave", "", 0));
		}
		super.close();
	}
}

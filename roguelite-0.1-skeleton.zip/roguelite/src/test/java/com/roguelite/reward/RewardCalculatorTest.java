package com.roguelite.reward;

import com.roguelite.core.RunState;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RewardCalculatorTest {
	private static RewardDef def(String id, String label, int points, boolean repeatable) {
		RewardDef d = new RewardDef();
		d.id = id;
		d.label = label;
		d.points = points;
		d.repeatable = repeatable;
		return d;
	}

	private static final List<RewardDef> TABLE = List.of(
		def("survive_day", "Day survived", 2, true),
		def("find_diamond", "First diamond", 5, false),
		def("enter_nether", "Nether entered", 10, false),
		def("find_relic", "Relic found", 5, true));

	private static RunState run() {
		RunState r = new RunState();
		r.startTick = 1000;
		return r;
	}

	@Test
	void emptyRunScoresZero() {
		RewardCalculator.Result result = RewardCalculator.preview(run(), 1000, TABLE);
		assertEquals(0, result.total());
		assertTrue(result.lines().isEmpty());
	}

	@Test
	void daysSurvivedArePaidPerWholeDay() {
		RunState r = run();
		assertEquals(0, RewardCalculator.preview(r, 1000 + 23_999, TABLE).total());
		assertEquals(2, RewardCalculator.preview(r, 1000 + 24_000, TABLE).total());
		assertEquals(6, RewardCalculator.preview(r, 1000 + 72_500, TABLE).total());
	}

	@Test
	void oneTimeRewardsPayOnceAndRepeatablesPayPerCount() {
		RunState r = run();
		r.achievements.add("find_diamond");
		r.achievements.add("enter_nether");
		r.counters.put("find_relic", 3L);
		RewardCalculator.Result result = RewardCalculator.preview(r, 1000 + 48_000, TABLE);
		// 2 days (4) + diamond (5) + nether (10) + 3 relics (15)
		assertEquals(34, result.total());
		assertEquals(4, result.lines().size());
	}

	@Test
	void previewDoesNotChangeTheRunButCalculateDoes() {
		RunState r = run();
		r.achievements.add("find_diamond");
		RewardCalculator.preview(r, 1000 + 48_000, TABLE);
		assertEquals(0, r.rewardTotal);
		assertTrue(r.rewardLines.isEmpty());
		assertTrue(r.counters.isEmpty());

		RewardCalculator.calculate(r, 1000 + 48_000, TABLE);
		assertEquals(9, r.rewardTotal);
		assertEquals(2L, r.counters.get("survive_day"));
		RewardCalculator.calculate(r, 1000 + 48_000, TABLE);
		assertEquals(9, r.rewardTotal);
		assertEquals(2, r.rewardLines.size());
	}
}

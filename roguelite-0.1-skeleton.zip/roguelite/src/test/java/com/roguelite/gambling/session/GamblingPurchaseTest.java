package com.roguelite.gambling.session;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GamblingPurchaseTest {
	/** Relics with per-run counters and an optional Daily Roll preview, for the purchase tests. */
	static final class PurchaseRelics implements Relics {
		final List<Option> offer = new ArrayList<>();
		final java.util.Map<String, Integer> counters = new java.util.HashMap<>();
		String upcoming;

		public List<Ref> wagerable() { return List.of(); }
		public void lose(String instanceId) {}
		public List<Option> rollOptions(int count) { return new ArrayList<>(offer.subList(0, Math.min(count, offer.size()))); }
		public void grant(String relicId) {}
		public int countOf(String relicId) { return 0; }
		public int counter(String key) { return counters.getOrDefault(key, 0); }
		public void bump(String key) { counters.merge(key, 1, Integer::sum); }
		public String upcomingDailyRoll() { return upcoming; }
	}

	static final class Chips2 implements Chips {
		int chips;
		Chips2(int c) { chips = c; }
		public int count() { return chips; }
		public boolean take(int n) { if (n <= 0 || chips < n) return false; chips -= n; return true; }
		public void give(int n) { chips += n; }
	}

	private static PurchaseRelics threeOffers() {
		PurchaseRelics r = new PurchaseRelics();
		r.offer.add(new Relics.Option("slow_bleed", "Slow Bleed", "x"));
		r.offer.add(new Relics.Option("magpies_eye", "Magpie's Eye", "y"));
		r.offer.add(new Relics.Option("jesters_die", "Jester's Die", "z"));
		return r;
	}

	@Test
	void relicPullCostsThirtyAndOffersChoices() {
		Chips2 chips = new Chips2(40);
		GamblingSession s = new GamblingSession(chips, threeOffers(), new Random(1));
		s.open();
		ScreenModel choice = s.handle("relic_pull", "", 0);
		assertEquals(10, chips.count());
		assertEquals("Claim a relic", choice.title());
		assertEquals(3, choice.buttons().size());
	}

	@Test
	void relicPullIsRefusedWhenBroke() {
		Chips2 chips = new Chips2(20);
		GamblingSession s = new GamblingSession(chips, threeOffers(), new Random(1));
		s.open();
		ScreenModel m = s.handle("relic_pull", "", 0);
		assertEquals(20, chips.count());
		assertTrue(m.lines().get(0).startsWith("!"));
	}

	@Test
	void relicPullIsCappedPerRun() {
		Chips2 chips = new Chips2(100);
		PurchaseRelics relics = threeOffers();
		relics.counters.put("relic_pulls", 2);
		GamblingSession s = new GamblingSession(chips, relics, new Random(1));
		s.open();
		ScreenModel m = s.handle("relic_pull", "", 0);
		assertEquals(100, chips.count());
		assertTrue(m.lines().get(0).startsWith("!"));
	}

	@Test
	void previewNeedsADailyRollModifier() {
		Chips2 chips = new Chips2(10);
		GamblingSession s = new GamblingSession(chips, threeOffers(), new Random(1));
		s.open();
		ScreenModel m = s.handle("preview_roll", "", 0);
		assertEquals(10, chips.count());
		assertTrue(m.lines().get(0).startsWith("!"));
	}

	@Test
	void previewShowsTomorrowsRollForFive() {
		Chips2 chips = new Chips2(10);
		PurchaseRelics relics = threeOffers();
		relics.upcoming = "Mild blessing";
		GamblingSession s = new GamblingSession(chips, relics, new Random(1));
		s.open();
		ScreenModel m = s.handle("preview_roll", "", 0);
		assertEquals(5, chips.count());
		assertTrue(m.lines().contains("Tomorrow's Daily Roll: Mild blessing."));
		assertEquals(1, (int) relics.counters.get("previews"));
	}
}

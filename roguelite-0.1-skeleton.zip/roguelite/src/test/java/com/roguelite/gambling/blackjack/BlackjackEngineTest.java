package com.roguelite.gambling.blackjack;

import com.roguelite.gambling.RelicOutcome;
import com.roguelite.gambling.Wager;
import org.junit.jupiter.api.Test;

import java.util.Random;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BlackjackEngineTest {
	// ---- helpers -------------------------------------------------------------------------------------------

	private static Card c(Rank rank) {
		return new Card(rank, Suit.SPADES);
	}

	/** Deal order is: player, dealer(up), player, dealer(hole), then draws in order. */
	private static BlackjackGame game(Wager wager, boolean surrender, Rank... order) {
		Card[] cards = new Card[order.length];
		for (int i = 0; i < order.length; i++) cards[i] = c(order[i]);
		BlackjackGame g = new BlackjackGame(Shoe.stacked(cards));
		g.start(wager, surrender);
		return g;
	}

	private static Wager chips(int n) {
		return new Wager.ChipWager(n);
	}

	private static Wager relic() {
		return new Wager.RelicWager("relic-instance-1");
	}

	// ---- hands ---------------------------------------------------------------------------------------------

	@Test
	void handTotalsHandleAces() {
		Hand h = new Hand();
		h.add(c(Rank.ACE));
		h.add(c(Rank.SIX));
		assertEquals(17, h.total());
		assertTrue(h.isSoft());
		h.add(c(Rank.TEN));
		assertEquals(17, h.total());
		assertFalse(h.isSoft());

		Hand aces = new Hand();
		aces.add(c(Rank.ACE));
		aces.add(c(Rank.ACE));
		assertEquals(12, aces.total());
		aces.add(c(Rank.NINE));
		assertEquals(21, aces.total());
		assertTrue(aces.isSoft());

		Hand bust = new Hand();
		bust.add(c(Rank.TEN));
		bust.add(c(Rank.SIX));
		bust.add(c(Rank.TEN));
		assertTrue(bust.isBust());
	}

	@Test
	void blackjackNeedsExactlyTwoCards() {
		Hand nat = new Hand();
		nat.add(c(Rank.ACE));
		nat.add(c(Rank.KING));
		assertTrue(nat.isBlackjack());

		Hand sevens = new Hand();
		sevens.add(c(Rank.SEVEN));
		sevens.add(c(Rank.SEVEN));
		sevens.add(c(Rank.SEVEN));
		assertEquals(21, sevens.total());
		assertFalse(sevens.isBlackjack());
	}

	// ---- shoe ----------------------------------------------------------------------------------------------

	@Test
	void sixDeckShoeHasTheRightCards() {
		Shoe shoe = new Shoe(6, new Random(1));
		assertEquals(312, shoe.remaining());
		int[] ranks = new int[Rank.values().length];
		int[] suits = new int[Suit.values().length];
		while (shoe.remaining() > 0) {
			Card card = shoe.draw();
			ranks[card.rank().ordinal()]++;
			suits[card.suit().ordinal()]++;
		}
		for (int n : ranks) assertEquals(24, n);
		for (int n : suits) assertEquals(78, n);
	}

	@Test
	void sameSeedGivesSameOrderAndDifferentSeedDiffers() {
		Shoe a = new Shoe(1, new Random(42));
		Shoe b = new Shoe(1, new Random(42));
		Shoe other = new Shoe(1, new Random(43));
		boolean differs = false;
		for (int i = 0; i < 52; i++) {
			Card x = a.draw();
			assertEquals(x, b.draw());
			if (!x.equals(other.draw())) differs = true;
		}
		assertTrue(differs);
	}

	@Test
	void reshuffleRestoresAllCards() {
		Shoe shoe = new Shoe(1, new Random(5));
		for (int i = 0; i < 40; i++) shoe.draw();
		shoe.shuffle();
		assertEquals(52, shoe.remaining());
	}

	// ---- dealing and naturals ------------------------------------------------------------------------------

	@Test
	void dealOrderAndHiddenHoleCard() {
		// player 10,7  dealer 9 up, 8 hole
		BlackjackGame g = game(chips(10), false, Rank.TEN, Rank.NINE, Rank.SEVEN, Rank.EIGHT);
		GameView v = g.view();
		assertEquals(Phase.PLAYER_TURN, v.phase());
		assertEquals(2, v.playerCards().size());
		assertEquals(17, v.playerTotal());
		assertEquals(1, v.dealerCards().size());
		assertEquals(Rank.NINE, v.dealerCards().get(0).rank());
		assertTrue(v.dealerHoleHidden());
		assertFalse(v.dealerTotal().isPresent());

		g.act(Action.STAND, 0);
		GameView after = g.view();
		assertEquals(Phase.SETTLED, after.phase());
		assertFalse(after.dealerHoleHidden());
		assertEquals(2, after.dealerCards().size());
		assertEquals(17, after.dealerTotal().getAsInt());
		assertEquals(Outcome.PUSH, after.settlement().outcome());
		assertEquals(10, after.settlement().chipPayout());
		assertEquals(0, after.settlement().chipNet());
	}

	@Test
	void playerBlackjackPaysThreeToTwo() {
		BlackjackGame g = game(chips(10), false, Rank.ACE, Rank.NINE, Rank.KING, Rank.SEVEN);
		Settlement s = g.settlement();
		assertEquals(Outcome.PLAYER_BLACKJACK, s.outcome());
		assertEquals(25, s.chipPayout());
		assertEquals(15, s.chipNet());
		assertEquals(Phase.SETTLED, g.phase());
	}

	@Test
	void dealerBlackjackEndsRoundAndPushesAgainstPlayerBlackjack() {
		BlackjackGame lose = game(chips(10), false, Rank.TEN, Rank.ACE, Rank.SEVEN, Rank.KING);
		assertEquals(Outcome.LOSE, lose.settlement().outcome());
		assertEquals(0, lose.settlement().chipPayout());
		assertFalse(lose.view().dealerHoleHidden());

		BlackjackGame push = game(chips(10), false, Rank.ACE, Rank.ACE, Rank.KING, Rank.KING);
		assertEquals(Outcome.PUSH, push.settlement().outcome());
		assertEquals(10, push.settlement().chipPayout());
	}

	// ---- dealer play ---------------------------------------------------------------------------------------

	@Test
	void dealerStandsOnSoftSeventeen() {
		// player 10,8 = 18; dealer A,6 = soft 17; NINE would be drawn if the dealer hit
		BlackjackGame g = game(chips(10), false, Rank.TEN, Rank.ACE, Rank.EIGHT, Rank.SIX, Rank.NINE);
		g.act(Action.STAND, 0);
		assertEquals(2, g.view().dealerCards().size());
		assertEquals(17, g.view().dealerTotal().getAsInt());
		assertEquals(Outcome.WIN, g.settlement().outcome());
		assertEquals(20, g.settlement().chipPayout());
	}

	@Test
	void dealerHitsSixteenAndCanBeatThePlayerOrBust() {
		// dealer 10,6 draws 5 -> 21 beats player 18
		BlackjackGame beat = game(chips(10), false, Rank.TEN, Rank.TEN, Rank.EIGHT, Rank.SIX, Rank.FIVE);
		beat.act(Action.STAND, 0);
		assertEquals(21, beat.settlement().dealerTotal());
		assertEquals(Outcome.LOSE, beat.settlement().outcome());

		// dealer 10,6 draws 10 -> bust
		BlackjackGame bust = game(chips(10), false, Rank.TEN, Rank.TEN, Rank.EIGHT, Rank.SIX, Rank.TEN);
		bust.act(Action.STAND, 0);
		assertEquals(Outcome.WIN, bust.settlement().outcome());
		assertEquals(20, bust.settlement().chipPayout());
	}

	// ---- player actions ------------------------------------------------------------------------------------

	@Test
	void playerBustLosesAndDealerDoesNotDraw() {
		// player 10,6; dealer 9,7 (would have to hit); player hits KING -> bust; NINE must stay in the shoe
		BlackjackGame g = game(chips(10), false, Rank.TEN, Rank.NINE, Rank.SIX, Rank.SEVEN, Rank.KING, Rank.NINE);
		g.act(Action.HIT, 0);
		assertEquals(Outcome.LOSE, g.settlement().outcome());
		assertEquals(0, g.settlement().chipPayout());
		assertEquals(-10, g.settlement().chipNet());
		assertEquals(2, g.view().dealerCards().size());
	}

	@Test
	void hittingToTwentyOneAutoStands() {
		// player 10,5 hits 6 = 21; dealer 10,7 = 17
		BlackjackGame g = game(chips(10), false, Rank.TEN, Rank.TEN, Rank.FIVE, Rank.SEVEN, Rank.SIX);
		g.act(Action.HIT, 0);
		assertEquals(Phase.SETTLED, g.phase());
		assertEquals(Outcome.WIN, g.settlement().outcome());
		assertEquals(21, g.settlement().playerTotal());
	}

	@Test
	void doubleDrawsExactlyOneCardAndDoublesStake() {
		// player 5,6 = 11; dealer 10,7 = 17; double draws TEN = 21
		BlackjackGame g = game(chips(10), false, Rank.FIVE, Rank.TEN, Rank.SIX, Rank.SEVEN, Rank.TEN);
		assertTrue(g.legalActions(10).contains(Action.DOUBLE));
		g.act(Action.DOUBLE, 10);
		Settlement s = g.settlement();
		assertEquals(Outcome.WIN, s.outcome());
		assertEquals(20, s.finalStake());
		assertEquals(40, s.chipPayout());
		assertEquals(20, s.chipNet());
		assertEquals(3, g.view().playerCards().size());
	}

	@Test
	void doubleNeedsSpareChipsAndOnlyOnFirstAction() {
		BlackjackGame poor = game(chips(10), false, Rank.FIVE, Rank.TEN, Rank.SIX, Rank.SEVEN, Rank.TWO, Rank.TWO);
		assertFalse(poor.legalActions(9).contains(Action.DOUBLE));
		assertThrows(IllegalStateException.class, () -> poor.act(Action.DOUBLE, 9));

		BlackjackGame hit = game(chips(10), false, Rank.FIVE, Rank.TEN, Rank.SIX, Rank.SEVEN, Rank.TWO, Rank.TWO);
		hit.act(Action.HIT, 100);
		assertFalse(hit.legalActions(100).contains(Action.DOUBLE));
	}

	@Test
	void relicWagersCannotDouble() {
		BlackjackGame g = game(relic(), false, Rank.FIVE, Rank.TEN, Rank.SIX, Rank.SEVEN, Rank.TWO);
		assertFalse(g.legalActions(1000).contains(Action.DOUBLE));
	}

	// ---- surrender -----------------------------------------------------------------------------------------

	@Test
	void surrenderOnlyWhenAllowedAndOnlyFirst() {
		BlackjackGame no = game(chips(10), false, Rank.TEN, Rank.NINE, Rank.SEVEN, Rank.EIGHT);
		assertFalse(no.legalActions(0).contains(Action.SURRENDER));

		BlackjackGame yes = game(chips(10), true, Rank.TEN, Rank.NINE, Rank.TWO, Rank.EIGHT, Rank.TWO);
		assertTrue(yes.legalActions(0).contains(Action.SURRENDER));
		yes.act(Action.HIT, 0);
		assertFalse(yes.legalActions(0).contains(Action.SURRENDER));
	}

	@Test
	void freeSurrenderReturnsFullStake() {
		BlackjackGame g = game(chips(10), true, Rank.TEN, Rank.NINE, Rank.SEVEN, Rank.EIGHT);
		g.act(Action.SURRENDER, 0);
		assertEquals(Outcome.SURRENDER, g.settlement().outcome());
		assertEquals(10, g.settlement().chipPayout());
		assertEquals(0, g.settlement().chipNet());
	}

	@Test
	void tableGivesOneFreeSurrenderPerSession() {
		Card[] cards = new Card[] {
			c(Rank.TEN), c(Rank.NINE), c(Rank.SEVEN), c(Rank.EIGHT),
			c(Rank.TEN), c(Rank.NINE), c(Rank.SEVEN), c(Rank.EIGHT)
		};
		BlackjackTable table = new BlackjackTable(new Rules(1, 0), Shoe.stacked(cards), 1);
		assertEquals(1, table.freeSurrendersLeft());

		table.startRound(chips(5));
		assertTrue(table.legalActions(0).contains(Action.SURRENDER));
		table.act(Action.SURRENDER, 0);
		assertEquals(0, table.freeSurrendersLeft());

		table.startRound(chips(5));
		assertFalse(table.legalActions(0).contains(Action.SURRENDER));
		assertEquals(2, table.roundsPlayed());
	}

	@Test
	void tableRefusesANewRoundWhileOneIsInProgress() {
		Card[] cards = new Card[] {
			c(Rank.TEN), c(Rank.NINE), c(Rank.SEVEN), c(Rank.EIGHT),
			c(Rank.TEN), c(Rank.NINE), c(Rank.SEVEN), c(Rank.EIGHT)
		};
		BlackjackTable table = new BlackjackTable(new Rules(1, 0), Shoe.stacked(cards), 0);
		table.startRound(chips(5));
		assertThrows(IllegalStateException.class, () -> table.startRound(chips(5)));
		table.act(Action.STAND, 0);
		table.startRound(chips(5));
	}

	// ---- relic wagers --------------------------------------------------------------------------------------

	@Test
	void relicWagerOutcomes() {
		// win: player 10,9 = 19 vs dealer 10,7 = 17
		BlackjackGame win = game(relic(), false, Rank.TEN, Rank.TEN, Rank.NINE, Rank.SEVEN);
		win.act(Action.STAND, 0);
		assertEquals(RelicOutcome.WON, win.settlement().relicOutcome());
		assertEquals(0, win.settlement().chipPayout());
		assertEquals(0, win.settlement().finalStake());

		// lose: player 10,7 = 17 vs dealer 10,9 = 19
		BlackjackGame lose = game(relic(), false, Rank.TEN, Rank.TEN, Rank.SEVEN, Rank.NINE);
		lose.act(Action.STAND, 0);
		assertEquals(RelicOutcome.LOST, lose.settlement().relicOutcome());

		// push: 17 vs 17
		BlackjackGame push = game(relic(), false, Rank.TEN, Rank.TEN, Rank.SEVEN, Rank.SEVEN);
		push.act(Action.STAND, 0);
		assertEquals(RelicOutcome.KEPT, push.settlement().relicOutcome());

		// natural blackjack wins the relic bet
		BlackjackGame nat = game(relic(), false, Rank.ACE, Rank.NINE, Rank.KING, Rank.SEVEN);
		assertEquals(RelicOutcome.WON, nat.settlement().relicOutcome());

		// surrender keeps the relic
		BlackjackGame sur = game(relic(), true, Rank.TEN, Rank.NINE, Rank.SEVEN, Rank.EIGHT);
		sur.act(Action.SURRENDER, 0);
		assertEquals(RelicOutcome.KEPT, sur.settlement().relicOutcome());
	}

	@Test
	void chipWagersNeverProduceRelicOutcomes() {
		BlackjackGame g = game(chips(3), false, Rank.TEN, Rank.TEN, Rank.NINE, Rank.SEVEN);
		g.act(Action.STAND, 0);
		assertEquals(RelicOutcome.NONE, g.settlement().relicOutcome());
	}

	// ---- state machine guards ------------------------------------------------------------------------------

	@Test
	void illegalCallsAreRejected() {
		BlackjackGame g = game(chips(10), false, Rank.TEN, Rank.NINE, Rank.SEVEN, Rank.EIGHT);
		assertThrows(IllegalStateException.class, () -> g.start(chips(1), false));
		g.act(Action.STAND, 0);
		assertThrows(IllegalStateException.class, () -> g.act(Action.HIT, 0));
		assertEquals(Set.of(), g.legalActions(100));
		assertThrows(IllegalArgumentException.class, () -> new Wager.ChipWager(0));
	}

	// ---- statistical sanity --------------------------------------------------------------------------------

	@Test
	void simulatedReturnIsSane() {
		// A player who copies the dealer (hit below 17) should lose a few percent, never win big, never lose big.
		BlackjackTable table = new BlackjackTable(Rules.standard(), new Random(12345), 0);
		int rounds = 200_000;
		long returned = 0;
		for (int i = 0; i < rounds; i++) {
			table.startRound(chips(2));
			while (table.roundInProgress()) {
				GameView v = table.view().orElseThrow();
				table.act(v.playerTotal() < 17 ? Action.HIT : Action.STAND, 0);
			}
			Settlement s = table.view().orElseThrow().settlement();
			assertTrue(s.chipPayout() == 0 || s.chipPayout() == 2 || s.chipPayout() == 4 || s.chipPayout() == 5);
			returned += s.chipPayout();
		}
		double ratio = returned / (double) (rounds * 2L);
		assertTrue(ratio > 0.90 && ratio < 1.0, "return ratio was " + ratio);
	}
}

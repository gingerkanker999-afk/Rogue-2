package com.roguelite.gambling.session;

import com.roguelite.gambling.blackjack.BlackjackTable;
import com.roguelite.gambling.blackjack.Card;
import com.roguelite.gambling.blackjack.Rank;
import com.roguelite.gambling.blackjack.Rules;
import com.roguelite.gambling.blackjack.Shoe;
import com.roguelite.gambling.blackjack.Suit;
import com.roguelite.gambling.ceelo.DiceRoll;
import com.roguelite.gambling.ceelo.DiceSource;
import org.junit.jupiter.api.Test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GamblingSessionTest {
	// ---- fakes ---------------------------------------------------------------------------------------------

	static final class FakeChips implements Chips {
		int chips;

		FakeChips(int chips) {
			this.chips = chips;
		}

		public int count() {
			return chips;
		}

		public boolean take(int n) {
			if (n <= 0 || chips < n) return false;
			chips -= n;
			return true;
		}

		public void give(int n) {
			chips += n;
		}
	}

	static final class FakeRelics implements Relics {
		final List<Ref> owned = new ArrayList<>();
		final List<Option> offer = new ArrayList<>();
		final List<String> granted = new ArrayList<>();

		public List<Ref> wagerable() {
			return new ArrayList<>(owned);
		}

		public void lose(String instanceId) {
			owned.removeIf(r -> r.instanceId().equals(instanceId));
		}

		public List<Option> rollOptions(int count) {
			return new ArrayList<>(offer.subList(0, Math.min(count, offer.size())));
		}

		public void grant(String relicId) {
			granted.add(relicId);
		}

		public int countOf(String relicId) {
			return (int) owned.stream().filter(r -> r.relicId().equals(relicId)).count();
		}
	}

	// ---- helpers -------------------------------------------------------------------------------------------

	private static Card c(Rank r) {
		return new Card(r, Suit.SPADES);
	}

	private static GamblingSession session(FakeChips chips, FakeRelics relics, Rank[] cards, DiceRoll... dice) {
		Card[] deck = new Card[cards.length];
		for (int i = 0; i < cards.length; i++) deck[i] = c(cards[i]);
		Deque<DiceRoll> queue = new ArrayDeque<>(List.of(dice));
		return new GamblingSession(chips, relics, new Random(1),
			n -> new BlackjackTable(new Rules(1, 0), Shoe.stacked(deck), n),
			() -> () -> {
				DiceRoll next = queue.poll();
				if (next == null) throw new IllegalStateException("dice script ran out");
				return next;
			});
	}

	private static Rank[] cards(Rank... r) {
		return r;
	}

	private static DiceRoll d(int a, int b, int c) {
		return new DiceRoll(a, b, c);
	}

	private static Relics.Ref ref(String instance, String relic, String name) {
		return new Relics.Ref(instance, relic, name);
	}

	private static boolean hasButton(ScreenModel m, String action) {
		return m.hasAction(action);
	}

	// ---- menus and bets ------------------------------------------------------------------------------------

	@Test
	void menuOffersBothGamesAndLeaving() {
		GamblingSession s = session(new FakeChips(10), new FakeRelics(), cards());
		ScreenModel m = s.open();
		assertEquals("Dealer's Deck", m.title());
		assertTrue(hasButton(m, "play"));
		assertTrue(hasButton(m, "leave"));
		assertEquals(4, m.buttons().size());
	}

	@Test
	void betScreenOnlyOffersAffordableBets() {
		GamblingSession s = session(new FakeChips(7), new FakeRelics(), cards());
		s.open();
		ScreenModel bet = s.handle("play", "blackjack", 0);
		List<Integer> amounts = new ArrayList<>();
		for (ButtonSpec b : bet.buttons()) if (b.action().equals("bet_chips")) amounts.add(b.amount());
		assertEquals(List.of(1, 5), amounts);

		GamblingSession broke = session(new FakeChips(0), new FakeRelics(), cards());
		broke.open();
		ScreenModel nothing = broke.handle("play", "ceelo", 0);
		assertFalse(hasButton(nothing, "bet_chips"));
		assertTrue(nothing.lines().contains("You have nothing to wager."));
	}

	@Test
	void invalidBetsAreRejectedAndNothingIsTaken() {
		FakeChips chips = new FakeChips(5);
		GamblingSession s = session(chips, new FakeRelics(), cards());
		s.open();
		s.handle("play", "blackjack", 0);
		for (int bad : new int[] {0, -3, 101, 1000, 6}) {
			ScreenModel m = s.handle("bet_chips", "", bad);
			assertTrue(m.lines().get(0).startsWith("!"));
			assertEquals(5, chips.chips);
			assertEquals(0, s.escrowedChips());
		}
	}

	@Test
	void actionsOutOfStateAreRejected() {
		FakeChips chips = new FakeChips(20);
		GamblingSession s = session(chips, new FakeRelics(), cards());
		s.open();
		for (String action : new String[] {"hit", "stand", "double", "surrender", "roll", "bet_chips", "bet_relic", "choose_relic", "nonsense"}) {
			ScreenModel m = s.handle(action, "x", 5);
			assertTrue(m.lines().get(0).startsWith("!"));
		}
		assertEquals(20, chips.chips);
		assertTrue(s.handle(null, null, 0).lines().get(0).startsWith("!"));
	}

	// ---- blackjack with chips ------------------------------------------------------------------------------

	@Test
	void blackjackWinPaysDoubleTheStake() {
		FakeChips chips = new FakeChips(20);
		// player 10,9 = 19; dealer 10,7 = 17
		GamblingSession s = session(chips, new FakeRelics(), cards(Rank.TEN, Rank.TEN, Rank.NINE, Rank.SEVEN));
		s.open();
		s.handle("play", "blackjack", 0);
		ScreenModel round = s.handle("bet_chips", "", 5);
		assertEquals(15, chips.chips);
		assertEquals(5, s.escrowedChips());
		assertTrue(hasButton(round, "hit") && hasButton(round, "stand"));
		assertFalse(hasButton(round, "surrender"));

		ScreenModel result = s.handle("stand", "", 0);
		assertEquals(25, chips.chips);
		assertEquals(0, s.escrowedChips());
		assertTrue(hasButton(result, "play"));
		assertTrue(result.lines().contains("You win!"));
		assertTrue(result.lines().contains("+5 chips"));
	}

	@Test
	void blackjackLossLosesTheStake() {
		FakeChips chips = new FakeChips(20);
		// player 10,7 = 17; dealer 10,9 = 19
		GamblingSession s = session(chips, new FakeRelics(), cards(Rank.TEN, Rank.TEN, Rank.SEVEN, Rank.NINE));
		s.open();
		s.handle("play", "blackjack", 0);
		s.handle("bet_chips", "", 5);
		ScreenModel result = s.handle("stand", "", 0);
		assertEquals(15, chips.chips);
		assertTrue(result.lines().contains("-5 chips"));
	}

	@Test
	void naturalBlackjackPaysThreeToTwoImmediately() {
		FakeChips chips = new FakeChips(20);
		GamblingSession s = session(chips, new FakeRelics(), cards(Rank.ACE, Rank.NINE, Rank.KING, Rank.SEVEN));
		s.open();
		s.handle("play", "blackjack", 0);
		ScreenModel result = s.handle("bet_chips", "", 10);
		assertEquals(10 + 25, chips.chips);
		assertTrue(result.lines().contains("BLACKJACK!"));
		assertTrue(hasButton(result, "play"));
	}

	@Test
	void doubleTakesAnExtraStakeAndPaysOnBoth() {
		FakeChips chips = new FakeChips(30);
		// player 5,6 = 11; dealer 10,7 = 17; double draws TEN = 21
		GamblingSession s = session(chips, new FakeRelics(), cards(Rank.FIVE, Rank.TEN, Rank.SIX, Rank.SEVEN, Rank.TEN));
		s.open();
		s.handle("play", "blackjack", 0);
		ScreenModel round = s.handle("bet_chips", "", 10);
		assertTrue(hasButton(round, "double"));
		assertEquals(20, chips.chips);

		s.handle("double", "", 0);
		// 30 - 10 - 10 = 10, then payout 4 x 10 = 40
		assertEquals(50, chips.chips);
		assertEquals(0, s.escrowedChips());
	}

	@Test
	void doubleIsHiddenWhenYouCannotAffordIt() {
		FakeChips chips = new FakeChips(12);
		GamblingSession s = session(chips, new FakeRelics(), cards(Rank.FIVE, Rank.TEN, Rank.SIX, Rank.SEVEN, Rank.TWO));
		s.open();
		s.handle("play", "blackjack", 0);
		ScreenModel round = s.handle("bet_chips", "", 10);
		assertFalse(hasButton(round, "double"));
		ScreenModel tried = s.handle("double", "", 0);
		assertTrue(tried.lines().get(0).startsWith("!"));
		assertEquals(2, chips.chips);
	}

	@Test
	void hollowCoinGivesAFreeSurrenderThatRefundsTheStake() {
		FakeChips chips = new FakeChips(20);
		FakeRelics relics = new FakeRelics();
		relics.owned.add(ref("i1", "hollow_coin", "Hollow Coin"));
		GamblingSession s = session(chips, relics, cards(Rank.TEN, Rank.NINE, Rank.SEVEN, Rank.EIGHT));
		s.open();
		s.handle("play", "blackjack", 0);
		ScreenModel round = s.handle("bet_chips", "", 5);
		assertTrue(hasButton(round, "surrender"));
		s.handle("surrender", "", 0);
		assertEquals(20, chips.chips);
	}

	// ---- cee-lo --------------------------------------------------------------------------------------------

	@Test
	void ceeloRoundPaysOnAWin() {
		FakeChips chips = new FakeChips(10);
		GamblingSession s = session(chips, new FakeRelics(), cards(), d(2, 2, 4), d(6, 6, 6));
		s.open();
		s.handle("play", "ceelo", 0);
		ScreenModel round = s.handle("bet_chips", "", 5);
		assertTrue(hasButton(round, "roll"));
		assertEquals(5, chips.chips);
		ScreenModel result = s.handle("roll", "", 0);
		assertEquals(15, chips.chips);
		assertTrue(result.lines().contains("You win!"));
	}

	@Test
	void ceeloDealerInstantWinEndsTheRoundAtOnce() {
		FakeChips chips = new FakeChips(10);
		GamblingSession s = session(chips, new FakeRelics(), cards(), d(3, 3, 3));
		s.open();
		s.handle("play", "ceelo", 0);
		ScreenModel result = s.handle("bet_chips", "", 5);
		assertEquals(5, chips.chips);
		assertFalse(hasButton(result, "roll"));
		assertTrue(result.lines().contains("You lose."));
	}

	// ---- relic wagers --------------------------------------------------------------------------------------

	private static FakeRelics oneRelic() {
		FakeRelics relics = new FakeRelics();
		relics.owned.add(ref("inst-1", "moles_tooth", "Mole's Tooth"));
		relics.offer.add(new Relics.Option("magpies_eye", "Magpie's Eye", "Glows."));
		relics.offer.add(new Relics.Option("slow_bleed", "Slow Bleed", "Bleeds."));
		return relics;
	}

	@Test
	void losingARelicWagerRemovesTheRelic() {
		FakeRelics relics = oneRelic();
		// player 10,7 = 17 vs dealer 10,9 = 19
		GamblingSession s = session(new FakeChips(0), relics, cards(Rank.TEN, Rank.TEN, Rank.SEVEN, Rank.NINE));
		s.open();
		ScreenModel bet = s.handle("play", "blackjack", 0);
		assertTrue(hasButton(bet, "bet_relic"));
		s.handle("bet_relic", "inst-1", 0);
		ScreenModel result = s.handle("stand", "", 0);
		assertTrue(relics.owned.isEmpty());
		assertTrue(result.lines().contains("Mole's Tooth is gone for this run."));
	}

	@Test
	void winningARelicWagerOffersTwoRelicsAndGrantsTheChosenOne() {
		FakeRelics relics = oneRelic();
		// player 10,9 = 19 vs dealer 10,7 = 17
		GamblingSession s = session(new FakeChips(0), relics, cards(Rank.TEN, Rank.TEN, Rank.NINE, Rank.SEVEN));
		s.open();
		s.handle("play", "blackjack", 0);
		s.handle("bet_relic", "inst-1", 0);
		ScreenModel choice = s.handle("stand", "", 0);
		assertEquals("Claim a relic", choice.title());
		assertEquals(2, choice.buttons().size());
		assertEquals(1, relics.owned.size());

		ScreenModel bogus = s.handle("choose_relic", "not_offered", 0);
		assertTrue(bogus.lines().get(0).startsWith("!"));
		assertTrue(relics.granted.isEmpty());

		ScreenModel done = s.handle("choose_relic", "slow_bleed", 0);
		assertEquals(List.of("slow_bleed"), relics.granted);
		assertTrue(hasButton(done, "play"));
		assertFalse(hasButton(done, "choose_relic"));
	}

	@Test
	void aPushReturnsTheWageredRelic() {
		FakeRelics relics = oneRelic();
		// 17 vs 17
		GamblingSession s = session(new FakeChips(0), relics, cards(Rank.TEN, Rank.TEN, Rank.SEVEN, Rank.SEVEN));
		s.open();
		s.handle("play", "blackjack", 0);
		s.handle("bet_relic", "inst-1", 0);
		ScreenModel result = s.handle("stand", "", 0);
		assertEquals(1, relics.owned.size());
		assertTrue(result.lines().contains("Mole's Tooth is returned to you."));
	}

	@Test
	void cannotWagerARelicYouDoNotOwn() {
		GamblingSession s = session(new FakeChips(0), oneRelic(), cards(Rank.TEN, Rank.TEN, Rank.SEVEN, Rank.SEVEN));
		s.open();
		s.handle("play", "blackjack", 0);
		ScreenModel m = s.handle("bet_relic", "someone-elses", 0);
		assertTrue(m.lines().get(0).startsWith("!"));
	}

	// ---- leaving and disconnecting -------------------------------------------------------------------------

	@Test
	void leavingMidBlackjackRoundStandsAndSettles() {
		FakeChips chips = new FakeChips(20);
		GamblingSession s = session(chips, new FakeRelics(), cards(Rank.TEN, Rank.TEN, Rank.NINE, Rank.SEVEN));
		s.open();
		s.handle("play", "blackjack", 0);
		s.handle("bet_chips", "", 5);
		assertEquals(15, chips.chips);
		ScreenModel closed = s.handle("leave", "", 0);
		assertTrue(closed.close());
		assertEquals(25, chips.chips);
		assertEquals(0, s.escrowedChips());
	}

	@Test
	void leavingMidBlackjackRoundCannotDodgeALoss() {
		FakeChips chips = new FakeChips(20);
		GamblingSession s = session(chips, new FakeRelics(), cards(Rank.TEN, Rank.TEN, Rank.SEVEN, Rank.NINE));
		s.open();
		s.handle("play", "blackjack", 0);
		s.handle("bet_chips", "", 5);
		s.forceFinish();
		assertEquals(15, chips.chips);
	}

	@Test
	void leavingMidCeeloRoundRollsForThePlayer() {
		FakeChips chips = new FakeChips(10);
		GamblingSession s = session(chips, new FakeRelics(), cards(), d(2, 2, 4), d(1, 2, 3));
		s.open();
		s.handle("play", "ceelo", 0);
		s.handle("bet_chips", "", 5);
		s.forceFinish();
		assertEquals(5, chips.chips);
		assertEquals(0, s.escrowedChips());
	}

	@Test
	void leavingDuringARelicChoiceGrantsOneAtRandom() {
		FakeRelics relics = oneRelic();
		GamblingSession s = session(new FakeChips(0), relics, cards(Rank.TEN, Rank.TEN, Rank.NINE, Rank.SEVEN));
		s.open();
		s.handle("play", "blackjack", 0);
		s.handle("bet_relic", "inst-1", 0);
		s.handle("stand", "", 0);
		ScreenModel closed = s.handle("leave", "", 0);
		assertTrue(closed.close());
		assertEquals(1, relics.granted.size());
		assertTrue(relics.granted.get(0).equals("magpies_eye") || relics.granted.get(0).equals("slow_bleed"));
	}

	@Test
	void leavingFromTheMenuJustCloses() {
		GamblingSession s = session(new FakeChips(10), new FakeRelics(), cards());
		s.open();
		assertTrue(s.handle("leave", "", 0).close());
	}

	// ---- you cannot walk away mid-round through the menu ---------------------------------------------------

	@Test
	void cannotOpenAnotherGameOrReturnToMenuDuringARound() {
		FakeChips chips = new FakeChips(20);
		GamblingSession s = session(chips, new FakeRelics(), cards(Rank.TEN, Rank.TEN, Rank.SEVEN, Rank.NINE));
		s.open();
		s.handle("play", "blackjack", 0);
		s.handle("bet_chips", "", 5);
		assertTrue(s.handle("menu", "", 0).lines().get(0).startsWith("!"));
		assertTrue(s.handle("play", "ceelo", 0).lines().get(0).startsWith("!"));
		assertEquals(5, s.escrowedChips());
	}

	// ---- randomized soak -----------------------------------------------------------------------------------

	@Test
	void randomPlayNeverBreaksTheChipsOrLeavesEscrowBehind() {
		Random pick = new Random(99);
		for (int run = 0; run < 3000; run++) {
			FakeChips chips = new FakeChips(pick.nextInt(60));
			FakeRelics relics = new FakeRelics();
			if (pick.nextBoolean()) relics.owned.add(ref("r" + run, "hollow_coin", "Hollow Coin"));
			relics.offer.add(new Relics.Option("magpies_eye", "Magpie's Eye", "x"));
			relics.offer.add(new Relics.Option("slow_bleed", "Slow Bleed", "y"));
			GamblingSession s = new GamblingSession(chips, relics, new Random(run));
			ScreenModel m = s.open();
			for (int step = 0; step < 40 && !m.close(); step++) {
				ButtonSpec b = m.buttons().get(pick.nextInt(m.buttons().size()));
				m = s.handle(b.action(), b.arg(), b.amount());
				assertTrue(chips.chips >= 0);
				assertTrue(s.escrowedChips() >= 0);
			}
			s.forceFinish();
			assertEquals(0, s.escrowedChips());
			assertTrue(chips.chips >= 0);
		}
	}
}

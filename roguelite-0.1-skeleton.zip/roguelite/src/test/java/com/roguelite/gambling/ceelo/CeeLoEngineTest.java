package com.roguelite.gambling.ceelo;

import com.roguelite.gambling.RelicOutcome;
import com.roguelite.gambling.Wager;
import org.junit.jupiter.api.Test;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CeeLoEngineTest {
	// ---- helpers -------------------------------------------------------------------------------------------

	private static DiceRoll r(int a, int b, int c) {
		return new DiceRoll(a, b, c);
	}

	/** Dice that come out in exactly this order (dealer's rolls first, then the player's). */
	private static DiceSource script(DiceRoll... rolls) {
		Deque<DiceRoll> queue = new ArrayDeque<>();
		for (DiceRoll roll : rolls) queue.add(roll);
		return () -> {
			DiceRoll next = queue.poll();
			if (next == null) throw new IllegalStateException("script ran out of dice");
			return next;
		};
	}

	private static CeeLoGame started(Wager wager, DiceRoll... rolls) {
		CeeLoGame g = new CeeLoGame(script(rolls));
		g.start(wager);
		return g;
	}

	private static Wager chips(int n) {
		return new Wager.ChipWager(n);
	}

	private static Wager relic() {
		return new Wager.RelicWager("relic-1");
	}

	// ---- scoring -------------------------------------------------------------------------------------------

	@Test
	void classifiesEveryKindOfRoll() {
		assertEquals(RollScore.Kind.AUTO_WIN, RollScore.of(r(5, 6, 4)).kind());
		assertEquals(RollScore.Kind.AUTO_WIN, RollScore.of(r(4, 5, 6)).kind());
		assertEquals(RollScore.Kind.AUTO_LOSS, RollScore.of(r(3, 1, 2)).kind());
		assertEquals(RollScore.Kind.TRIPLE, RollScore.of(r(3, 3, 3)).kind());
		assertEquals(3, RollScore.of(r(3, 3, 3)).value());
		assertEquals(RollScore.Kind.NO_SCORE, RollScore.of(r(1, 3, 5)).kind());
		assertEquals(RollScore.Kind.NO_SCORE, RollScore.of(r(2, 4, 6)).kind());
		assertFalse(RollScore.of(r(1, 3, 5)).isFinal());
	}

	@Test
	void pairPlusOddDieMakesThePointWhicheverOrder() {
		assertEquals(5, RollScore.of(r(2, 2, 5)).value());
		assertEquals(5, RollScore.of(r(2, 5, 2)).value());
		assertEquals(5, RollScore.of(r(5, 2, 2)).value());
		assertEquals(6, RollScore.of(r(2, 6, 2)).value());
		assertEquals(1, RollScore.of(r(6, 6, 1)).value());
		assertEquals(RollScore.Kind.POINT, RollScore.of(r(6, 6, 1)).kind());
	}

	@Test
	void strengthOrdersEverythingCorrectly() {
		int autoLoss = RollScore.of(r(1, 2, 3)).strength();
		int point1 = RollScore.of(r(6, 6, 1)).strength();
		int point6 = RollScore.of(r(1, 1, 6)).strength();
		int triple1 = RollScore.of(r(1, 1, 1)).strength();
		int triple6 = RollScore.of(r(6, 6, 6)).strength();
		int autoWin = RollScore.of(r(4, 5, 6)).strength();
		assertTrue(autoLoss < point1);
		assertTrue(point1 < point6);
		assertTrue(point6 < triple1);
		assertTrue(triple1 < triple6);
		assertTrue(triple6 < autoWin);
	}

	@Test
	void allTwoHundredSixteenRollsAreAccountedFor() {
		int win = 0, loss = 0, triple = 0, point = 0, none = 0;
		for (int a = 1; a <= 6; a++) {
			for (int b = 1; b <= 6; b++) {
				for (int c = 1; c <= 6; c++) {
					switch (RollScore.of(r(a, b, c)).kind()) {
						case AUTO_WIN -> win++;
						case AUTO_LOSS -> loss++;
						case TRIPLE -> triple++;
						case POINT -> point++;
						case NO_SCORE -> none++;
					}
				}
			}
		}
		assertEquals(6, win);
		assertEquals(6, loss);
		assertEquals(6, triple);
		assertEquals(90, point);
		assertEquals(108, none);
	}

	@Test
	void diceMustShowOneToSix() {
		assertThrows(IllegalArgumentException.class, () -> new DiceRoll(0, 1, 1));
		assertThrows(IllegalArgumentException.class, () -> new DiceRoll(1, 7, 1));
	}

	// ---- the dealer rolls first ----------------------------------------------------------------------------

	@Test
	void dealerTripleOrFourFiveSixWinsInstantly() {
		CeeLoGame triple = started(chips(10), r(3, 3, 3));
		assertEquals(CeeLoGame.Phase.SETTLED, triple.phase());
		assertEquals(CeeLoGame.Outcome.LOSE, triple.settlement().outcome());
		assertEquals(0, triple.settlement().chipPayout());
		assertEquals(-10, triple.settlement().chipNet());
		assertEquals(null, triple.settlement().playerScore());

		CeeLoGame cee = started(chips(10), r(4, 6, 5));
		assertEquals(CeeLoGame.Outcome.LOSE, cee.settlement().outcome());
	}

	@Test
	void dealerOneTwoThreeLosesInstantly() {
		CeeLoGame g = started(chips(10), r(1, 3, 2));
		assertEquals(CeeLoGame.Phase.SETTLED, g.phase());
		assertEquals(CeeLoGame.Outcome.WIN, g.settlement().outcome());
		assertEquals(20, g.settlement().chipPayout());
		assertEquals(10, g.settlement().chipNet());
	}

	@Test
	void dealerRerollsUntilSomethingScores() {
		CeeLoGame g = started(chips(10), r(1, 3, 5), r(2, 4, 6), r(2, 2, 4));
		assertEquals(CeeLoGame.Phase.AWAITING_ROLL, g.phase());
		CeeLoView v = g.view();
		assertEquals(3, v.dealerRolls().size());
		assertEquals(4, v.dealerScore().value());
		assertEquals(RollScore.Kind.POINT, v.dealerScore().kind());
		assertEquals(0, v.playerRolls().size());
	}

	// ---- the player rolls ----------------------------------------------------------------------------------

	private CeeLoGame dealerPoint4(Wager wager, DiceRoll... playerRolls) {
		DiceRoll[] all = new DiceRoll[playerRolls.length + 1];
		all[0] = r(2, 2, 4);
		System.arraycopy(playerRolls, 0, all, 1, playerRolls.length);
		CeeLoGame g = started(wager, all);
		g.rollPlayer();
		return g;
	}

	@Test
	void playerWinsWithTripleFourFiveSixOrHigherPoint() {
		assertEquals(CeeLoGame.Outcome.WIN, dealerPoint4(chips(5), r(6, 6, 6)).settlement().outcome());
		assertEquals(CeeLoGame.Outcome.WIN, dealerPoint4(chips(5), r(5, 4, 6)).settlement().outcome());
		assertEquals(CeeLoGame.Outcome.WIN, dealerPoint4(chips(5), r(3, 3, 5)).settlement().outcome());
	}

	@Test
	void playerLosesWithOneTwoThreeOrLowerPoint() {
		assertEquals(CeeLoGame.Outcome.LOSE, dealerPoint4(chips(5), r(3, 2, 1)).settlement().outcome());
		assertEquals(CeeLoGame.Outcome.LOSE, dealerPoint4(chips(5), r(3, 3, 1)).settlement().outcome());
	}

	@Test
	void equalPointsPush() {
		CeeLoGame g = dealerPoint4(chips(5), r(1, 1, 4));
		assertEquals(CeeLoGame.Outcome.PUSH, g.settlement().outcome());
		assertEquals(5, g.settlement().chipPayout());
		assertEquals(0, g.settlement().chipNet());
	}

	@Test
	void playerRerollsUntilSomethingScores() {
		CeeLoGame g = dealerPoint4(chips(5), r(1, 3, 5), r(2, 4, 6), r(1, 1, 6));
		assertEquals(3, g.view().playerRolls().size());
		assertEquals(CeeLoGame.Outcome.WIN, g.settlement().outcome());
	}

	@Test
	void aHigherPlayerTripleDoesNotBeatADealerTriple() {
		// Banker rules: the dealer's triple wins at once, so the player never rolls.
		CeeLoGame g = started(chips(5), r(1, 1, 1), r(6, 6, 6));
		assertEquals(CeeLoGame.Outcome.LOSE, g.settlement().outcome());
		assertEquals(0, g.view().playerRolls().size());
	}

	// ---- relic wagers --------------------------------------------------------------------------------------

	@Test
	void relicWagerOutcomes() {
		CeeLoGame win = dealerPoint4(relic(), r(6, 6, 6));
		assertEquals(RelicOutcome.WON, win.settlement().relicOutcome());
		assertEquals(0, win.settlement().chipPayout());
		assertEquals(0, win.settlement().stake());

		assertEquals(RelicOutcome.LOST, dealerPoint4(relic(), r(1, 2, 3)).settlement().relicOutcome());
		assertEquals(RelicOutcome.KEPT, dealerPoint4(relic(), r(1, 1, 4)).settlement().relicOutcome());
		assertEquals(RelicOutcome.LOST, started(relic(), r(5, 5, 5)).settlement().relicOutcome());
		assertEquals(RelicOutcome.WON, started(relic(), r(3, 1, 2)).settlement().relicOutcome());
	}

	@Test
	void chipWagersNeverProduceRelicOutcomes() {
		assertEquals(RelicOutcome.NONE, dealerPoint4(chips(5), r(6, 6, 6)).settlement().relicOutcome());
	}

	// ---- state machine guards ------------------------------------------------------------------------------

	@Test
	void illegalCallsAreRejected() {
		CeeLoGame notStarted = new CeeLoGame(script(r(2, 2, 4)));
		assertThrows(IllegalStateException.class, notStarted::rollPlayer);

		CeeLoGame g = started(chips(5), r(2, 2, 4), r(6, 6, 6));
		assertThrows(IllegalStateException.class, () -> g.start(chips(5)));
		g.rollPlayer();
		assertThrows(IllegalStateException.class, g::rollPlayer);
	}

	@Test
	void tableRunsRoundsAndRefusesOverlap() {
		CeeLoTable table = new CeeLoTable(script(r(2, 2, 4), r(6, 6, 6), r(3, 3, 3)));
		table.startRound(chips(1));
		assertTrue(table.roundInProgress());
		assertThrows(IllegalStateException.class, () -> table.startRound(chips(1)));
		table.rollPlayer();
		assertFalse(table.roundInProgress());
		table.startRound(chips(1));
		assertEquals(2, table.roundsPlayed());
		assertFalse(table.roundInProgress());
	}

	// ---- the numbers ---------------------------------------------------------------------------------------

	@Test
	void exactHouseEdgeIsOneOverOneHundredEight() {
		// Every scoring roll is equally likely among the 108 that score, so enumerate those.
		java.util.List<RollScore> scoring = new java.util.ArrayList<>();
		for (int a = 1; a <= 6; a++) {
			for (int b = 1; b <= 6; b++) {
				for (int c = 1; c <= 6; c++) {
					RollScore s = RollScore.of(r(a, b, c));
					if (s.isFinal()) scoring.add(s);
				}
			}
		}
		assertEquals(108, scoring.size());

		double ev = 0;
		for (RollScore dealer : scoring) {
			double pd = 1.0 / scoring.size();
			if (dealer.kind() == RollScore.Kind.AUTO_WIN || dealer.kind() == RollScore.Kind.TRIPLE) {
				ev += pd * -1;
			} else if (dealer.kind() == RollScore.Kind.AUTO_LOSS) {
				ev += pd * 1;
			} else {
				for (RollScore player : scoring) {
					double pp = 1.0 / scoring.size();
					double result;
					if (player.kind() == RollScore.Kind.AUTO_WIN || player.kind() == RollScore.Kind.TRIPLE) {
						result = 1;
					} else if (player.kind() == RollScore.Kind.AUTO_LOSS) {
						result = -1;
					} else {
						result = Integer.compare(player.value(), dealer.value());
					}
					ev += pd * pp * result;
				}
			}
		}
		assertTrue(Math.abs(ev - (-1.0 / 108.0)) < 1e-12, "expected value was " + ev);
	}

	@Test
	void simulatedReturnMatchesTheExactEdge() {
		CeeLoTable table = new CeeLoTable(DiceSource.random(new Random(2024)));
		int rounds = 400_000;
		long net = 0;
		for (int i = 0; i < rounds; i++) {
			table.startRound(chips(1));
			if (table.roundInProgress()) table.rollPlayer();
			net += table.view().orElseThrow().settlement().chipNet();
		}
		double perRound = net / (double) rounds;
		assertTrue(perRound > -0.025 && perRound < 0.005, "average net per round was " + perRound);
	}
}

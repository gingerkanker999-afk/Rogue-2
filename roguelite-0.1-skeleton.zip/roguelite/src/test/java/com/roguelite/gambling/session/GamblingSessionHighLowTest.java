package com.roguelite.gambling.session;

import com.roguelite.gambling.highlow.HighLowGame;
import org.junit.jupiter.api.Test;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GamblingSessionHighLowTest {
	private static HighLowGame.RankSource script(int... values) {
		Deque<Integer> queue = new ArrayDeque<>();
		for (int v : values) queue.add(v);
		return () -> {
			Integer next = queue.poll();
			if (next == null) throw new IllegalStateException("script ran out");
			return next;
		};
	}

	private static GamblingSession session(GamblingSessionTest.FakeChips chips, int... cards) {
		return new GamblingSession(chips, new GamblingSessionTest.FakeRelics(), new Random(1),
			ignored -> {
				throw new IllegalStateException("blackjack not used here");
			},
			() -> {
				throw new IllegalStateException("dice not used here");
			},
			() -> script(cards));
	}

	@Test
	void highLowCashOutPaysThePot() {
		GamblingSessionTest.FakeChips chips = new GamblingSessionTest.FakeChips(20);
		GamblingSession s = session(chips, 9, 12);
		s.open();
		ScreenModel bet = s.handle("play", "highlow", 0);
		assertTrue(bet.buttons().stream().noneMatch(b -> b.action().equals("bet_relic")));

		ScreenModel round = s.handle("bet_chips", "", 10);
		assertTrue(round.hasAction("higher"));
		assertTrue(round.hasAction("lower"));
		assertEquals(10, chips.count());

		s.handle("higher", "", 0);
		ScreenModel result = s.handle("cashout", "", 0);
		assertTrue(result.hasAction("play"));
		assertEquals(34, chips.count());
		assertEquals(0, s.escrowedChips());
	}

	@Test
	void wrongCallLosesTheStake() {
		GamblingSessionTest.FakeChips chips = new GamblingSessionTest.FakeChips(20);
		GamblingSession s = session(chips, 9, 9);
		s.open();
		s.handle("play", "highlow", 0);
		s.handle("bet_chips", "", 10);
		ScreenModel result = s.handle("higher", "", 0);
		assertEquals(10, chips.count());
		assertTrue(result.lines().contains("Wrong call."));
	}

	@Test
	void leavingMidRoundCashesOutInsteadOfRefunding() {
		GamblingSessionTest.FakeChips chips = new GamblingSessionTest.FakeChips(20);
		GamblingSession s = session(chips, 9, 12);
		s.open();
		s.handle("play", "highlow", 0);
		s.handle("bet_chips", "", 10);
		s.handle("higher", "", 0);
		s.forceFinish();
		assertEquals(34, chips.count());
		assertEquals(0, s.escrowedChips());
	}
}

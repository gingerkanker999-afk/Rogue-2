package com.roguelite.gambling.highlow;

import com.roguelite.gambling.highlow.HighLowGame.Guess;
import org.junit.jupiter.api.Test;

import java.util.ArrayDeque;
import java.util.Deque;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class HighLowGameTest {
	static HighLowGame.RankSource src(int... values) {
		Deque<Integer> queue = new ArrayDeque<>();
		for (int v : values) queue.add(v);
		return () -> {
			Integer next = queue.poll();
			if (next == null) throw new IllegalStateException("script ran out");
			return next;
		};
	}

	@Test
	void startDealsTheFirstCardAndOpensGuessing() {
		HighLowGame g = new HighLowGame(src(9));
		assertEquals(HighLowGame.Phase.BETTING, g.phase());
		g.start(10);
		assertEquals(HighLowGame.Phase.GUESSING, g.phase());
		assertEquals(9, g.current());
		assertEquals(10, g.pot());
	}

	@Test
	void edgeCardsCannotGuessOutOfRange() {
		HighLowGame ace = new HighLowGame(src(14));
		ace.start(5);
		assertFalse(ace.canGuess(Guess.HIGHER));
		assertTrue(ace.canGuess(Guess.LOWER));

		HighLowGame two = new HighLowGame(src(2));
		two.start(5);
		assertFalse(two.canGuess(Guess.LOWER));
		assertTrue(two.canGuess(Guess.HIGHER));
	}

	@Test
	void correctGuessGrowsThePotByFairOdds() {
		// 10, J, Q, K, A all beat a 9: 5 of 13 ranks, so pot x 0.95 x 13 / 5
		HighLowGame g = new HighLowGame(src(9, 12));
		g.start(10);
		g.guess(Guess.HIGHER);
		assertEquals(24, g.pot());
		assertEquals(1, g.steps());
		assertEquals(HighLowGame.Phase.GUESSING, g.phase());
	}

	@Test
	void tieLosesTheWholeStake() {
		HighLowGame g = new HighLowGame(src(9, 9));
		g.start(10);
		g.guess(Guess.HIGHER);
		assertEquals(HighLowGame.Phase.SETTLED, g.phase());
		assertEquals(HighLowGame.Outcome.LOSE, g.outcome());
		assertEquals(-10, g.chipNet());
	}

	@Test
	void wrongDirectionLoses() {
		HighLowGame g = new HighLowGame(src(9, 12));
		g.start(10);
		g.guess(Guess.LOWER);
		assertEquals(HighLowGame.Outcome.LOSE, g.outcome());
		assertEquals(0, g.payout());
	}

	@Test
	void cashOutPaysThePot() {
		HighLowGame g = new HighLowGame(src(9, 12));
		g.start(10);
		g.guess(Guess.HIGHER);
		g.cashOut();
		assertEquals(HighLowGame.Outcome.CASH_OUT, g.outcome());
		assertEquals(24, g.payout());
		assertEquals(14, g.chipNet());
	}

	@Test
	void stepLimitStopsFurtherGuesses() {
		HighLowGame g = new HighLowGame(src(2, 3, 4, 5, 6));
		g.start(10);
		g.guess(Guess.HIGHER); // pot 10
		g.guess(Guess.HIGHER); // pot 11
		g.guess(Guess.HIGHER); // pot 13
		g.guess(Guess.HIGHER); // pot 17, four steps
		assertEquals(4, g.steps());
		assertFalse(g.canGuess(Guess.HIGHER));
		assertThrows(IllegalStateException.class, () -> g.guess(Guess.HIGHER));
		g.cashOut();
		assertEquals(17, g.payout());
	}

	@Test
	void cashOutIsRejectedOnceSettled() {
		HighLowGame g = new HighLowGame(src(9, 9));
		g.start(10);
		g.guess(Guess.HIGHER);
		assertThrows(IllegalStateException.class, g::cashOut);
	}

	@Test
	void everyStartingCardPaysAboutNinetyFivePercentOfStakeOnAverage() {
		int stake = 100_000;
		for (int c = 2; c <= 14; c++) {
			for (Guess guess : Guess.values()) {
				HighLowGame probe = new HighLowGame(src(c));
				probe.start(stake);
				if (!probe.canGuess(guess)) continue;
				double total = 0;
				for (int d = 2; d <= 14; d++) {
					boolean won = guess == Guess.HIGHER ? d > c : d < c;
					if (!won) continue;
					HighLowGame g = new HighLowGame(src(c, d));
					g.start(stake);
					g.guess(guess);
					total += g.pot();
				}
				double average = total / 13.0;
				assertTrue(Math.abs(average - 0.95 * stake) < 2.0,
					"card " + c + " " + guess + " averaged " + average);
			}
		}
	}

	@Test
	void invalidStartsAreRejected() {
		assertThrows(IllegalArgumentException.class, () -> new HighLowGame(src(9)).start(0));
		HighLowGame g = new HighLowGame(src(9));
		g.start(5);
		assertThrows(IllegalStateException.class, () -> g.start(5));
	}
}

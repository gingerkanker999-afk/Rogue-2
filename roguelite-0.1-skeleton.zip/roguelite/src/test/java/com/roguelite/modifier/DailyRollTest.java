package com.roguelite.modifier;

import com.roguelite.modifier.DailyRoll;
import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DailyRollTest {
	@Test
	void effectTableMatchesTheDesign() {
		assertEquals("Harsh curse", DailyRoll.effect(1).name());
		assertEquals("Major blessing", DailyRoll.effect(6).name());
		assertTrue(DailyRoll.effect(1).mining() < 0);
		assertTrue(DailyRoll.effect(6).attack() > 0);
	}

	@Test
	void rollsAlwaysLandOnTheDie() {
		Random rng = new Random(3);
		for (int i = 0; i < 10_000; i++) {
			int face = DailyRoll.roll(rng, 8);
			assertTrue(face >= 1 && face <= 6);
		}
	}

	@Test
	void withoutLuckEveryFaceIsEquallyLikely() {
		Random rng = new Random(5);
		int[] counts = new int[7];
		int n = 120_000;
		for (int i = 0; i < n; i++) counts[DailyRoll.roll(rng, 0)]++;
		for (int face = 1; face <= 6; face++) {
			double share = counts[face] / (double) n;
			assertTrue(Math.abs(share - 1.0 / 6.0) < 0.01, "face " + face + " share " + share);
		}
	}

	@Test
	void luckRaisesTheAverageRoll() {
		int n = 200_000;
		Random plain = new Random(7);
		Random lucky = new Random(7);
		double plainTotal = 0;
		double luckyTotal = 0;
		for (int i = 0; i < n; i++) {
			plainTotal += DailyRoll.roll(plain, 0);
			luckyTotal += DailyRoll.roll(lucky, 10);
		}
		assertTrue(luckyTotal / n > plainTotal / n + 0.15,
			"lucky " + luckyTotal / n + " vs plain " + plainTotal / n);
	}

	@Test
	void absurdLuckIsClampedNotFatal() {
		Random rng = new Random(9);
		int face = DailyRoll.roll(rng, 999);
		assertTrue(face >= 1 && face <= 6);
	}
}

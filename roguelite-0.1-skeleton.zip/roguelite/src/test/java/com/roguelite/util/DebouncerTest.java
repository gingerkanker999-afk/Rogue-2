package com.roguelite.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DebouncerTest {
	@Test
	void firstSampleIsTakenImmediately() {
		assertTrue(new Debouncer(3).update(true));
		assertFalse(new Debouncer(3).update(false));
	}

	@Test
	void flipsOnlyAfterEnoughConsecutiveOppositeSamples() {
		Debouncer d = new Debouncer(3);
		assertTrue(d.update(true));
		assertTrue(d.update(false));
		assertTrue(d.update(false));
		assertFalse(d.update(false));
		assertFalse(d.current());
	}

	@Test
	void anInterruptedStreakStartsOver() {
		Debouncer d = new Debouncer(3);
		d.update(true);
		d.update(false);
		d.update(false);
		assertTrue(d.update(true));
		d.update(false);
		d.update(false);
		assertTrue(d.current());
		assertFalse(d.update(false));
	}

	@Test
	void thresholdOneFlipsInstantly() {
		Debouncer d = new Debouncer(1);
		d.update(true);
		assertFalse(d.update(false));
		assertTrue(d.update(true));
	}

	@Test
	void rejectsABadThreshold() {
		assertThrows(IllegalArgumentException.class, () -> new Debouncer(0));
	}

	@Test
	void flickeringAtACaveMouthNeverChangesTheState() {
		Debouncer d = new Debouncer(3);
		d.update(true);
		boolean changed = false;
		for (int i = 0; i < 100; i++) {
			if (!d.update(i % 2 == 0)) changed = true;
		}
		assertFalse(changed);
	}
}

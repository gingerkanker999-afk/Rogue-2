package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BlightTrackerTest {
	/** Runs the tracker for {@code ticks} with the player at {@code health}, applying damage as the game would. */
	private static double drainFor(BlightTracker tracker, String key, int ticks, double start) {
		double health = start;
		for (int i = 0; i < ticks; i++) {
			BlightTracker.Step step = tracker.step(key, true, health);
			if (step.restoreTo() >= 0) health = step.restoreTo();
			health -= step.damage();
		}
		return health;
	}

	@Test
	void aFullBarDrainsInSixtySeconds() {
		BlightTracker t = new BlightTracker();
		assertEquals(0.0, drainFor(t, "a", 1200, 20.0), 1e-9);
	}

	@Test
	void oneHealthPerThreeSeconds() {
		BlightTracker t = new BlightTracker();
		assertEquals(20.0, drainFor(t, "b", 59, 20.0), 1e-9);
		BlightTracker.Step step = t.step("c", true, 20.0);
		assertEquals(0, step.damage());
	}

	@Test
	void healingInsideIsUndone() {
		BlightTracker t = new BlightTracker();
		t.step("d", true, 10.0);
		BlightTracker.Step healed = t.step("d", true, 18.0);
		assertEquals(10.0, healed.restoreTo(), 1e-9);
	}

	@Test
	void leavingResetsTheTimer() {
		BlightTracker t = new BlightTracker();
		drainFor(t, "e", 100, 20.0);
		t.step("e", false, 15.0);
		BlightTracker.Step back = t.step("e", true, 15.0);
		assertEquals(0, back.damage());
	}

	@Test
	void damageFromOtherSourcesIsNotCountedTwice() {
		BlightTracker t = new BlightTracker();
		t.step("f", true, 20.0);
		drainFor(t, "f", 59, 20.0);
		BlightTracker.Step hit = t.step("f", true, 14.0);
		assertEquals(0, hit.damage());
		assertEquals(-1, hit.restoreTo(), 1e-9);
	}
}

package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RunLogTest {
	@Test
	void escapesCommasQuotesAndNewlines() {
		assertEquals("plain", RunLog.escape("plain"));
		assertEquals("\"a,b\"", RunLog.escape("a,b"));
		assertEquals("\"say \"\"hi\"\"\"", RunLog.escape("say \"hi\""));
		assertEquals("", RunLog.escape(null));
	}

	@Test
	void runRowHasTheRightColumnsAndRewards() {
		RunState run = new RunState();
		run.runId = 7;
		run.starterId = "scavenger";
		run.modifierId = "tradewinds";
		run.endReason = "Died - banked 25%";
		run.rewardTotal = 12;
		run.rewardPaid = 3;
		RunState.RewardLine a = new RunState.RewardLine();
		a.label = "Day survived x2";
		a.points = 4;
		RunState.RewardLine b = new RunState.RewardLine();
		b.label = "Relic found";
		b.points = 8;
		run.rewardLines.add(a);
		run.rewardLines.add(b);

		String row = RunLog.runRow("2026-10-31T12:00:00Z", run, 2400, 3);
		String[] cols = row.split(",", -1);
		assertEquals(11, cols.length);
		assertEquals("run", cols[1]);
		assertEquals("7", cols[2]);
		assertEquals("2.0", cols[5]);
		assertTrue(row.contains("Died - banked 25%"));
		assertTrue(row.contains("Day survived x2 +4; Relic found +8"));
		assertEquals("3", cols[10]);
	}

	@Test
	void buyRowRecordsTheCostAsNegativePaid() {
		String row = RunLog.buyRow("t", "scavenger", 5, 0);
		String[] cols = row.split(",", -1);
		assertEquals("buy", cols[1]);
		assertEquals("-5", cols[9]);
		assertEquals("0", cols[10]);
	}
}

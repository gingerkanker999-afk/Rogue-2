package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class CacheRulesTest {
	@Test
	void entriesRoundTripToTheirKind() {
		String entry = CacheRules.entry(CacheRules.Kind.VAULT, "1,64,-3");
		assertEquals("vault@1,64,-3", entry);
		assertEquals(CacheRules.Kind.VAULT, CacheRules.kindOf(entry));
		assertEquals(CacheRules.Kind.CACHE, CacheRules.kindOf("cache@0,70,0"));
	}

	@Test
	void malformedEntriesHaveNoKind() {
		assertNull(CacheRules.kindOf("nonsense"));
		assertNull(CacheRules.kindOf("pit@0,0,0"));
	}

	@Test
	void eachKindPaysItsOwnReward() {
		assertEquals("vault_opened", CacheRules.Kind.VAULT.rewardId);
		assertEquals("cache_opened", CacheRules.Kind.CACHE.rewardId);
		assertEquals("roguelite:vault", CacheRules.Kind.VAULT.lootTable);
	}
}

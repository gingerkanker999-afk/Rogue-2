package com.roguelite.core;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ZoneRulesTest {
	@Test
	void runsSitTwentyThousandBlocksApart() {
		assertEquals(20_000, ZoneRules.centreX(1));
		assertEquals(40_000, ZoneRules.centreX(2));
		assertEquals(0, ZoneRules.centreZ(7));
	}

	@Test
	void ruinsNeverReachAnotherZone() {
		int gap = ZoneRules.centreX(2) - ZoneRules.centreX(1);
		assertTrue(gap > 2 * BlightRules.RUIN_RADIUS);
	}

	@Test
	void ruinLookupFindsTheRightRuinOrNothing() {
		Ruin a = new Ruin(1, 0, 0);
		Ruin b = new Ruin(2, 20_000, 0);
		List<Ruin> ruins = List.of(a, b);
		assertEquals(a, RuinRules.ruinAt(ruins, 10, 10));
		assertEquals(b, RuinRules.ruinAt(ruins, 20_005, 0));
		assertNull(RuinRules.ruinAt(ruins, 500, 500));
	}
}

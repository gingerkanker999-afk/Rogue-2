package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class StashRulesTest {
	@Test
	void upgradeLadderIsFifteenTwentyFiveThirtyFive() {
		assertEquals(15, StashRules.upgradeCost(0));
		assertEquals(25, StashRules.upgradeCost(1));
		assertEquals(35, StashRules.upgradeCost(2));
		assertEquals(-1, StashRules.upgradeCost(3));
	}

	@Test
	void eachUpgradeAddsNineSlots() {
		assertEquals(9, StashRules.slots(0));
		assertEquals(18, StashRules.slots(1));
		assertEquals(27, StashRules.slots(2));
		assertEquals(36, StashRules.slots(3));
		assertEquals(36 * 64, StashRules.capacityItems(3));
	}

	@Test
	void onlyTheAllowListIsAccepted() {
		assertTrue(StashRules.allowed("minecraft:bread"));
		assertFalse(StashRules.allowed("minecraft:diamond"));
		assertFalse(StashRules.allowed("minecraft:golden_apple"));
	}

	@Test
	void depositNeverExceedsTheRoomLeft() {
		assertEquals(10, StashRules.depositAmount(0, 576, 10));
		assertEquals(4, StashRules.depositAmount(570, 574, 10));
		assertEquals(0, StashRules.depositAmount(574, 574, 10));
		assertEquals(0, StashRules.depositAmount(600, 574, 10));
	}
}

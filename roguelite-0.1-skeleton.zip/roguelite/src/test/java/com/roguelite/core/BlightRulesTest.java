package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BlightRulesTest {
	@Test
	void fullBarTakesSixtySeconds() {
		assertEquals(1200L, BlightRules.fullBarTicks());
	}

	@Test
	void healthIsLostOneUnitEveryThreeSeconds() {
		assertEquals(0, BlightRules.healthLostAfter(59));
		assertEquals(1, BlightRules.healthLostAfter(60));
		assertEquals(2, BlightRules.healthLostAfter(120));
	}

	@Test
	void lossNeverExceedsAFullBarOrGoesNegative() {
		assertEquals(20, BlightRules.healthLostAfter(100_000));
		assertEquals(0, BlightRules.healthLostAfter(-50));
	}
}

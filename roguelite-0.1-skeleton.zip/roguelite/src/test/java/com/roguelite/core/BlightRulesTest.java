package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BlightRulesTest {
	@Test
	void fullBarTakesSevenMinutesForty() {
		assertEquals(9200L, BlightRules.fullBarTicks());
		assertEquals(460, BlightRules.fullBarTicks() / 20);
	}

	@Test
	void healthIsLostOneUnitEveryTwentyThreeSeconds() {
		assertEquals(0, BlightRules.healthLostAfter(22 * 20));
		assertEquals(1, BlightRules.healthLostAfter(23 * 20));
		assertEquals(2, BlightRules.healthLostAfter(46 * 20));
	}

	@Test
	void lossNeverExceedsAFullBarOrGoesNegative() {
		assertEquals(20, BlightRules.healthLostAfter(100_000));
		assertEquals(0, BlightRules.healthLostAfter(-50));
	}

	@Test
	void ruinEdgeIsSixtyFourBlocks() {
		assertTrue(BlightRules.inRuin(64, 0, 0, 0));
		assertFalse(BlightRules.inRuin(65, 0, 0, 0));
		assertTrue(BlightRules.inRuin(45, 45, 0, 0));
		assertFalse(BlightRules.inRuin(46, 46, 0, 0));
	}
}

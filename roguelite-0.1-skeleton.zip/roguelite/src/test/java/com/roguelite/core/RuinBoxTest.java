package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RuinBoxTest {
	private static RunState runAt(long id, int x, int z) {
		RunState r = new RunState();
		r.runId = id;
		r.startX = x;
		r.startZ = z;
		return r;
	}

	@Test
	void untouchedRunLeavesAMarginAroundTheStart() {
		Ruin ruin = runAt(1, 20_000, 0).toRuin();
		assertEquals(19_984, ruin.minX());
		assertEquals(20_016, ruin.maxX());
		assertEquals(-16, ruin.minZ());
		assertEquals(16, ruin.maxZ());
	}

	@Test
	void exploringGrowsTheBoxAndKeepsTheMargin() {
		RunState r = runAt(1, 20_000, 0);
		r.explore(20_010, -30);
		Ruin ruin = r.toRuin();
		assertEquals(19_984, ruin.minX());
		assertEquals(20_026, ruin.maxX());
		assertEquals(-46, ruin.minZ());
		assertEquals(16, ruin.maxZ());
	}

	@Test
	void theBoxNeverGrowsPastTheMaximumSize() {
		RunState r = runAt(1, 20_000, 0);
		r.explore(90_000, 0);
		assertEquals(21_000, r.toRuin().maxX());
	}

	@Test
	void containsIsInclusiveAtTheEdges() {
		Ruin ruin = new Ruin(1, -10, 50, -10, 50);
		assertTrue(ruin.contains(-10, 50));
		assertTrue(ruin.contains(50, -10));
		assertFalse(ruin.contains(51, 0));
	}
}

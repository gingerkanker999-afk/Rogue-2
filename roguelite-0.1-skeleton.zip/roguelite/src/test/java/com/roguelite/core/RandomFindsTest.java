package com.roguelite.core;

import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RandomFindsTest {
	@Test
	void luckRaisesTheChance() {
		assertTrue(RandomFinds.chance(0.01, 8) > RandomFinds.chance(0.01, 0));
		assertEquals(0.01, RandomFinds.chance(0.01, 0), 1e-12);
	}

	@Test
	void chanceIsCappedAndNegativeLuckIsIgnored() {
		assertEquals(0.5, RandomFinds.chance(0.4, 100), 1e-12);
		assertEquals(0.01, RandomFinds.chance(0.01, -5), 1e-12);
	}

	@Test
	void observedRateMatchesTheChance() {
		Random rng = new Random(11);
		int hits = 0;
		int n = 400_000;
		for (int i = 0; i < n; i++) {
			if (RandomFinds.rolls(rng, 0.05, 0)) hits++;
		}
		double rate = hits / (double) n;
		assertTrue(Math.abs(rate - 0.05) < 0.003, "rate " + rate);
	}

	@Test
	void pityFiresExactlyAtTheThreshold() {
		assertFalse(RandomFinds.pityDue(5999, 0, 6000));
		assertTrue(RandomFinds.pityDue(6000, 0, 6000));
		assertTrue(RandomFinds.pityDue(9000, 0, 6000));
	}

	@Test
	void aFreshFindResetsThePityWindow() {
		long lastFind = 10_000;
		assertFalse(RandomFinds.pityDue(lastFind + 5999, lastFind, RandomFinds.PITY_TICKS));
	}
}

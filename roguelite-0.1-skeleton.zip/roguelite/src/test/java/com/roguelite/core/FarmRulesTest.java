package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FarmRulesTest {
	@Test
	void twoBreadPerDay() {
		assertEquals(2, FarmRules.accrue(0, 1));
		assertEquals(6, FarmRules.accrue(2, 2));
	}

	@Test
	void storageCapsAtEight() {
		assertEquals(8, FarmRules.accrue(0, 10));
		assertEquals(8, FarmRules.accrue(6, 1));
		assertEquals(8, FarmRules.accrue(8, 5));
	}

	@Test
	void noDaysNoChangeAndNegativeTimeIsIgnored() {
		assertEquals(3, FarmRules.accrue(3, 0));
		assertEquals(3, FarmRules.accrue(3, -5));
	}

	@Test
	void dayCountsFromWorldTime() {
		assertEquals(0, FarmRules.dayOf(23999));
		assertEquals(1, FarmRules.dayOf(24000));
		assertEquals(3, FarmRules.dayOf(3 * 24000 + 100));
	}
}

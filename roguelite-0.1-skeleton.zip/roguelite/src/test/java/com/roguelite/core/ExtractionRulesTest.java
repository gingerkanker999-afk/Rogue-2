package com.roguelite.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ExtractionRulesTest {
	@Test
	void deathKeepsTwentyFivePercentRoundingDown() {
		assertEquals(3, ExtractionRules.payout(13, ExtractionRules.DEATH_PERCENT));
		assertEquals(0, ExtractionRules.payout(3, ExtractionRules.DEATH_PERCENT));
	}

	@Test
	void emergencyBanksHalfAndFullBanksEverything() {
		assertEquals(3, ExtractionRules.payout(7, ExtractionRules.Mode.EMERGENCY.percent));
		assertEquals(20, ExtractionRules.payout(20, ExtractionRules.Mode.FULL.percent));
	}

	@Test
	void payoutNeverExceedsTheTotalOrGoesNegative() {
		assertEquals(0, ExtractionRules.payout(50, -10));
		assertEquals(50, ExtractionRules.payout(50, 500));
		assertEquals(0, ExtractionRules.payout(-5, 100));
	}

	@Test
	void fullExtractionIsSlowerAndStricterThanEmergency() {
		assertTrue(ExtractionRules.Mode.FULL.channelTicks > ExtractionRules.Mode.EMERGENCY.channelTicks);
		assertTrue(ExtractionRules.Mode.FULL.percent > ExtractionRules.Mode.EMERGENCY.percent);
		assertTrue(ExtractionRules.Mode.FULL.maxMove < ExtractionRules.Mode.EMERGENCY.maxMove);
	}

	@Test
	void damageAlwaysCancels() {
		assertTrue(ExtractionRules.shouldCancel(ExtractionRules.Mode.EMERGENCY, 0.0, true));
		assertTrue(ExtractionRules.shouldCancel(ExtractionRules.Mode.FULL, 0.0, true));
	}

	@Test
	void emergencyTolerateSmallDriftFullDoesNot() {
		assertFalse(ExtractionRules.shouldCancel(ExtractionRules.Mode.EMERGENCY, 1.5, false));
		assertTrue(ExtractionRules.shouldCancel(ExtractionRules.Mode.EMERGENCY, 3.0, false));
		assertTrue(ExtractionRules.shouldCancel(ExtractionRules.Mode.FULL, 0.5, false));
		assertFalse(ExtractionRules.shouldCancel(ExtractionRules.Mode.FULL, 0.0, false));
	}
}

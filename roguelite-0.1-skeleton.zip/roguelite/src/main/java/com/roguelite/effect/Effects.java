package com.roguelite.effect;

import com.roguelite.modifier.ModifierRegistry;
import com.roguelite.relic.RelicRegistry;

/**
 * The one place that attaches gameplay to modifier and relic ids. Anything not registered here is still a no-op,
 * so effects can be added one at a time and tested individually.
 * Insomniac has no effect object: its bed block is checked directly in RogueliteEvents.
 */
public final class Effects {
	private Effects() {}

	public static void registerAll() {
		RelicRegistry.registerEffect("moles_tooth", new MolesTooth());
		ModifierRegistry.registerEffect("daily_roll", new DailyRollEffect());
		ModifierRegistry.registerEffect("tradewinds", new TradewindsEffect());
		ModifierRegistry.registerEffect("heavy_metal", new HeavyMetalEffect());
	}
}

package com.roguelite.effect;

import com.roguelite.Roguelite;
import com.roguelite.core.RunState;
import com.roguelite.util.Debouncer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Mole's Tooth: mine faster underground, slower on the surface.
 *
 * "Underground" means there is no open sky above your head (a tunnel, a cave or a building counts; a valley does not).
 * It works by adding a temporary modifier to Minecraft's own block-break-speed attribute, re-evaluated twice a second
 * and debounced so standing at a cave mouth doesn't flicker.
 */
public final class MolesTooth implements RunEffect {
	private static final Identifier MODIFIER_ID = Identifier.of(Roguelite.MOD_ID, "moles_tooth_mining");

	/** +40% mining speed underground. */
	public static final double UNDERGROUND = 0.40;
	/** -30% mining speed on the surface. */
	public static final double SURFACE = -0.30;

	private static final int CHECK_EVERY_TICKS = 10;
	private static final int DEBOUNCE_SAMPLES = 3;

	private final Map<UUID, Debouncer> debouncers = new HashMap<>();
	private final Map<UUID, Boolean> applied = new HashMap<>();

	@Override
	public void onActivate(ServerPlayerEntity player, RunState run) {
		// Forget old state so the next tick applies the right modifier straight away.
		debouncers.remove(player.getUuid());
		applied.remove(player.getUuid());
	}

	@Override
	public void onDeactivate(ServerPlayerEntity player, RunState run) {
		debouncers.remove(player.getUuid());
		applied.remove(player.getUuid());
		EntityAttributeInstance attribute = player.getAttributeInstance(EntityAttributes.PLAYER_BLOCK_BREAK_SPEED);
		if (attribute != null) {
			attribute.removeModifier(MODIFIER_ID);
		}
	}

	@Override
	public void onPlayerTick(ServerPlayerEntity player, RunState run, ServerWorld world) {
		boolean first = !applied.containsKey(player.getUuid());
		if (!first && world.getTime() % CHECK_EVERY_TICKS != 0) return;

		boolean noSkyAbove = !world.isSkyVisible(player.getBlockPos().up());
		Debouncer debouncer = debouncers.computeIfAbsent(player.getUuid(), id -> new Debouncer(DEBOUNCE_SAMPLES));
		boolean underground = debouncer.update(noSkyAbove);

		Boolean last = applied.get(player.getUuid());
		if (last != null && last == underground) return;

		EntityAttributeInstance attribute = player.getAttributeInstance(EntityAttributes.PLAYER_BLOCK_BREAK_SPEED);
		if (attribute == null) return;
		attribute.removeModifier(MODIFIER_ID);
		attribute.addTemporaryModifier(new EntityAttributeModifier(
			MODIFIER_ID, underground ? UNDERGROUND : SURFACE, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
		applied.put(player.getUuid(), underground);
	}
}

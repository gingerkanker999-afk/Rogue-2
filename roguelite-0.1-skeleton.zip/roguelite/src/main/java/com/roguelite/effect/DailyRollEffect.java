package com.roguelite.effect;

import com.roguelite.Roguelite;
import com.roguelite.core.RunManager;
import com.roguelite.core.RunState;
import com.roguelite.modifier.DailyRoll;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Daily Roll (Luck): each new in-game day (every 24,000 ticks of world time) rolls a six-sided effect for the run.
 * It is applied through Minecraft's own attributes (mining speed, movement speed, attack damage) and re-checked
 * every second, so the day's effect survives leaving and rejoining the world.
 */
public final class DailyRollEffect implements RunEffect {
	private static final long TICKS_PER_DAY = 24000L;
	private static final int CHECK_EVERY_TICKS = 20;
	private static final Identifier MINING_ID = Identifier.of(Roguelite.MOD_ID, "daily_roll_mining");
	private static final Identifier MOVEMENT_ID = Identifier.of(Roguelite.MOD_ID, "daily_roll_movement");
	private static final Identifier ATTACK_ID = Identifier.of(Roguelite.MOD_ID, "daily_roll_attack");

	private final Map<UUID, Integer> applied = new HashMap<>();
	private final Random random = new Random();

	@Override
	public void onActivate(ServerPlayerEntity player, RunState run) {
		applied.remove(player.getUuid());
	}

	@Override
	public void onDeactivate(ServerPlayerEntity player, RunState run) {
		applied.remove(player.getUuid());
		apply(player.getAttributeInstance(EntityAttributes.BLOCK_BREAK_SPEED), MINING_ID, 0.0);
		apply(player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED), MOVEMENT_ID, 0.0);
		apply(player.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE), ATTACK_ID, 0.0);
	}

	@Override
	public void onPlayerTick(ServerPlayerEntity player, RunState run, ServerWorld world) {
		if (world.getTime() % CHECK_EVERY_TICKS != 0) return;

		long day = world.getTime() / TICKS_PER_DAY;
		if (run.dailyRollDay != day) {
			int face = DailyRoll.roll(random, run.luck);
			run.dailyRollDay = day;
			run.dailyRollFace = face;
			RunManager.saveRun();
			player.sendMessage(Text.literal("Daily Roll: " + DailyRoll.effect(face).name() + ".")
				.formatted(Formatting.GOLD), false);
		}
		if (run.dailyRollFace < 1) return;

		Integer current = applied.get(player.getUuid());
		if (current != null && current == run.dailyRollFace) return;

		DailyRoll.Effect effect = DailyRoll.effect(run.dailyRollFace);
		apply(player.getAttributeInstance(EntityAttributes.BLOCK_BREAK_SPEED), MINING_ID, effect.mining());
		apply(player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED), MOVEMENT_ID, effect.movement());
		apply(player.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE), ATTACK_ID, effect.attack());
		applied.put(player.getUuid(), run.dailyRollFace);
	}

	private static void apply(EntityAttributeInstance instance, Identifier id, double value) {
		if (instance == null) return;
		instance.removeModifier(id);
		if (value != 0.0) {
			instance.addTemporaryModifier(new EntityAttributeModifier(
				id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
		}
	}
}

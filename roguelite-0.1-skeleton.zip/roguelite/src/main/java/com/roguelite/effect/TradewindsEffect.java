package com.roguelite.effect;

import com.roguelite.Roguelite;
import com.roguelite.core.RunState;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/**
 * Tradewinds (Duality): +15% movement speed, and the same +15% to mining speed and attack damage.
 * This is a fixed bonus; the full design ties it to whatever movement speed the player actually has.
 */
public final class TradewindsEffect implements RunEffect {
	private static final double BONUS = 0.15;
	private static final Identifier MOVE_ID = Identifier.of(Roguelite.MOD_ID, "tradewinds_move");
	private static final Identifier MINING_ID = Identifier.of(Roguelite.MOD_ID, "tradewinds_mining");
	private static final Identifier ATTACK_ID = Identifier.of(Roguelite.MOD_ID, "tradewinds_attack");

	@Override
	public void onActivate(ServerPlayerEntity player, RunState run) {
		apply(player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED), MOVE_ID, BONUS);
		apply(player.getAttributeInstance(EntityAttributes.BLOCK_BREAK_SPEED), MINING_ID, BONUS);
		apply(player.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE), ATTACK_ID, BONUS);
	}

	@Override
	public void onDeactivate(ServerPlayerEntity player, RunState run) {
		apply(player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED), MOVE_ID, 0.0);
		apply(player.getAttributeInstance(EntityAttributes.BLOCK_BREAK_SPEED), MINING_ID, 0.0);
		apply(player.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE), ATTACK_ID, 0.0);
	}

	private static void apply(EntityAttributeInstance instance, Identifier id, double value) {
		if (instance == null) return;
		instance.removeModifier(id);
		if (value != 0.0) {
			instance.addTemporaryModifier(new EntityAttributeModifier(
				id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
		}
	}
}

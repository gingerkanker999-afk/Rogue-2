package com.roguelite.effect;

import com.roguelite.core.RunState;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * The single extension point for modifier and relic gameplay.
 *
 * The Run Manager only ever calls these lifecycle methods. Actual gameplay hooks (damage, mining speed,
 * healing, hunger...) are added later by registering Fabric events / mixins that ask
 * {@code RunManager.activeEffects()} what is currently active - so adding an effect never changes the Run Manager.
 *
 * {@link #onActivate} is called when a run starts, when a relic is obtained, and every time the run owner
 * joins a world with an ACTIVE run. Implementations must therefore be idempotent.
 */
public interface RunEffect {
	/** Does nothing. Every modifier/relic uses this until its real effect is implemented. */
	RunEffect NO_OP = new RunEffect() {};

	default void onActivate(ServerPlayerEntity player, RunState run) {}

	default void onDeactivate(ServerPlayerEntity player, RunState run) {}
}

package com.roguelite.effect;

import com.roguelite.Roguelite;
import com.roguelite.core.RunState;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Heavy Metal (Duality): each armour point slows you by 3% and adds 4% melee damage. Re-checked every second,
 * so putting on or taking off armour takes effect quickly.
 */
public final class HeavyMetalEffect implements RunEffect {
	private static final int CHECK_EVERY_TICKS = 20;
	private static final double SLOW_PER_ARMOR = -0.03;
	private static final double DAMAGE_PER_ARMOR = 0.04;
	private static final Identifier MOVE_ID = Identifier.of(Roguelite.MOD_ID, "heavy_metal_move");
	private static final Identifier ATTACK_ID = Identifier.of(Roguelite.MOD_ID, "heavy_metal_attack");

	private final Map<UUID, Integer> applied = new HashMap<>();

	@Override
	public void onActivate(ServerPlayerEntity player, RunState run) {
		applied.remove(player.getUuid());
	}

	@Override
	public void onDeactivate(ServerPlayerEntity player, RunState run) {
		applied.remove(player.getUuid());
		apply(player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED), MOVE_ID, 0.0);
		apply(player.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE), ATTACK_ID, 0.0);
	}

	@Override
	public void onPlayerTick(ServerPlayerEntity player, RunState run, ServerWorld world) {
		if (world.getTime() % CHECK_EVERY_TICKS != 0) return;

		int armor = player.getArmor();
		Integer last = applied.get(player.getUuid());
		if (last != null && last == armor) return;

		apply(player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED), MOVE_ID, SLOW_PER_ARMOR * armor);
		apply(player.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE), ATTACK_ID, DAMAGE_PER_ARMOR * armor);
		applied.put(player.getUuid(), armor);
	}

	private static void apply(EntityAttributeInstance instance, Identifier id, double value) {
		if (instance == null) return;
		instance.removeModifier(id);
		if (value != 0.0) {
			instance.addTemporaryModifier(new EntityAttributeModifier(
				id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
		}
	}
}

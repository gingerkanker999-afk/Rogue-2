package com.roguelite.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Small file helpers shared by the profile store and the per-world run store. */
public final class FileUtil {
	private FileUtil() {}

	/** Writes to a temp file next to the target, then moves it into place so a crash never leaves a half-written file. */
	public static void writeAtomic(Path target, String content) throws IOException {
		Path parent = target.toAbsolutePath().getParent();
		if (parent != null) {
			Files.createDirectories(parent);
		}
		Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
		Files.writeString(tmp, content, StandardCharsets.UTF_8);
		try {
			Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
		} catch (AtomicMoveNotSupportedException e) {
			Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
		}
	}

	/** Renames an unreadable file out of the way (keeps it for manual recovery). */
	public static Path quarantine(Path file) throws IOException {
		Path dest = file.resolveSibling(file.getFileName() + ".corrupt-" + System.currentTimeMillis());
		Files.move(file, dest, StandardCopyOption.REPLACE_EXISTING);
		return dest;
	}
}

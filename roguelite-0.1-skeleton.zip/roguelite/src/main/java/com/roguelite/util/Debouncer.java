package com.roguelite.util;

/**
 * Smooths a flickering yes/no signal. The first sample is taken as-is; after that the state only flips once the
 * opposite value has been seen {@code threshold} times in a row. Used so standing at a cave mouth or under a tree
 * doesn't flip an effect on and off every half second.
 */
public final class Debouncer {
	private final int threshold;
	private boolean initialized;
	private boolean state;
	private int streak;

	public Debouncer(int threshold) {
		if (threshold < 1) throw new IllegalArgumentException("threshold must be >= 1");
		this.threshold = threshold;
	}

	public boolean update(boolean sample) {
		if (!initialized) {
			initialized = true;
			state = sample;
			streak = 0;
			return state;
		}
		if (sample == state) {
			streak = 0;
			return state;
		}
		streak++;
		if (streak >= threshold) {
			state = sample;
			streak = 0;
		}
		return state;
	}

	public boolean current() {
		return state;
	}
}

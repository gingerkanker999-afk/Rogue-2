package com.roguelite;

import com.roguelite.command.RogueliteCommands;
import com.roguelite.economy.MetaEconomy;
import com.roguelite.modifier.ModifierRegistry;
import com.roguelite.net.Payloads;
import com.roguelite.net.ServerNetworking;
import com.roguelite.relic.RelicRegistry;
import com.roguelite.reward.RewardTable;
import com.roguelite.starter.StarterRegistry;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

public class Roguelite implements ModInitializer {
	public static final String MOD_ID = "roguelite";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/**
	 * Placeholder symbol for the meta currency. The planned emoji is outside Minecraft's default font and would
	 * render as a box, so this is a single constant to change later (or replace with a custom glyph).
	 */
	public static final String CURRENCY_SYMBOL = "\u25C6";

	@Override
	public void onInitialize() {
		Path configDir = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID);

		// Global profile (meta currency) - lives outside any world.
		MetaEconomy.init(configDir.resolve("profile.json"));

		// Data-driven definitions (JSON in the jar, overridable from config/roguelite/).
		ModifierRegistry.load();
		RelicRegistry.load();
		StarterRegistry.load();
		RewardTable.load();
		StarterRegistry.validate();

		Payloads.register();
		ServerNetworking.register();
		RogueliteEvents.register();
		RogueliteCommands.register();

		LOGGER.info("Roguelite initialized");
	}
}

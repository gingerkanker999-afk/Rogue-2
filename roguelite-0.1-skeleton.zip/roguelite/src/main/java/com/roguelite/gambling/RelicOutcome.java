package com.roguelite.gambling;

/** What happens to a wagered relic. NONE when the wager was chips. */
public enum RelicOutcome {
	NONE,
	/** Push or surrender: the relic is returned untouched. */
	KEPT,
	/** Win: keep the relic AND the caller offers a choice of one of two random new relics. */
	WON,
	/** Loss: the relic is permanently lost for this run. */
	LOST
}

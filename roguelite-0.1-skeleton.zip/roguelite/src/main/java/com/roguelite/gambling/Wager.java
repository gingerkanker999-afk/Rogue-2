package com.roguelite.gambling;

import java.util.Objects;

/** What the player puts up. The engine never touches inventories; the caller escrows and pays out. */
public sealed interface Wager permits Wager.ChipWager, Wager.RelicWager {

	record ChipWager(int amount) implements Wager {
		public ChipWager {
			if (amount < 1) throw new IllegalArgumentException("A chip wager must be at least 1");
		}
	}

	record RelicWager(String relicInstanceId) implements Wager {
		public RelicWager {
			Objects.requireNonNull(relicInstanceId, "relicInstanceId");
			if (relicInstanceId.isBlank()) throw new IllegalArgumentException("relicInstanceId is blank");
		}
	}
}

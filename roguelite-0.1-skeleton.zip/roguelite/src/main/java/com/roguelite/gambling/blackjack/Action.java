package com.roguelite.gambling.blackjack;

public enum Action {
	HIT,
	STAND,
	DOUBLE,
	/** Only available on the first action and only when the table allows it (Hollow Coin). */
	SURRENDER
}

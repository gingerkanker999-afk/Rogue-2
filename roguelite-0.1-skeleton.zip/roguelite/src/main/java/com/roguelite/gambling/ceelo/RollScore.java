package com.roguelite.gambling.ceelo;

/**
 * The meaning of a roll in Cee-lo.
 *
 * 4-5-6 = AUTO_WIN, 1-2-3 = AUTO_LOSS, three of a kind = TRIPLE (value = the die),
 * a pair plus an odd die = POINT (value = the odd die), anything else = NO_SCORE (roll again).
 */
public record RollScore(Kind kind, int value) {
	public enum Kind { NO_SCORE, AUTO_LOSS, POINT, TRIPLE, AUTO_WIN }

	public static RollScore of(DiceRoll roll) {
		int[] d = roll.sorted();
		if (d[0] == d[1] && d[1] == d[2]) {
			return new RollScore(Kind.TRIPLE, d[0]);
		}
		if (d[0] == 4 && d[1] == 5 && d[2] == 6) {
			return new RollScore(Kind.AUTO_WIN, 0);
		}
		if (d[0] == 1 && d[1] == 2 && d[2] == 3) {
			return new RollScore(Kind.AUTO_LOSS, 0);
		}
		if (d[0] == d[1]) {
			return new RollScore(Kind.POINT, d[2]);
		}
		if (d[1] == d[2]) {
			return new RollScore(Kind.POINT, d[0]);
		}
		return new RollScore(Kind.NO_SCORE, 0);
	}

	/** True if this roll settles things (anything except NO_SCORE). */
	public boolean isFinal() {
		return kind != Kind.NO_SCORE;
	}

	/** Higher beats lower: 1-2-3 (0) < points 1-6 < triples 1-6 (11-16) < 4-5-6 (20). NO_SCORE is -1. */
	public int strength() {
		return switch (kind) {
			case NO_SCORE -> -1;
			case AUTO_LOSS -> 0;
			case POINT -> value;
			case TRIPLE -> 10 + value;
			case AUTO_WIN -> 20;
		};
	}
}

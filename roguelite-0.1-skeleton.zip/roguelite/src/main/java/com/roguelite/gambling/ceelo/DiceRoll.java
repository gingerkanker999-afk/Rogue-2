package com.roguelite.gambling.ceelo;

import java.util.Arrays;

/** Three six-sided dice. Order does not matter for scoring. */
public record DiceRoll(int a, int b, int c) {
	public DiceRoll {
		check(a);
		check(b);
		check(c);
	}

	private static void check(int d) {
		if (d < 1 || d > 6) throw new IllegalArgumentException("A die must show 1-6, got " + d);
	}

	/** The three dice in ascending order. */
	public int[] sorted() {
		int[] dice = {a, b, c};
		Arrays.sort(dice);
		return dice;
	}

	@Override
	public String toString() {
		return a + "-" + b + "-" + c;
	}
}

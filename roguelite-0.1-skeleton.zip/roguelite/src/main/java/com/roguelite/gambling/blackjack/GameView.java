package com.roguelite.gambling.blackjack;

import com.roguelite.gambling.Wager;

import java.util.List;
import java.util.OptionalInt;

/**
 * What a client is allowed to see. While the player is still acting, the dealer's hole card is NOT in
 * {@code dealerCards} and {@code dealerTotal} is empty, so a modified client cannot peek at it.
 */
public record GameView(
	Phase phase,
	List<Card> playerCards,
	int playerTotal,
	boolean playerSoft,
	List<Card> dealerCards,
	boolean dealerHoleHidden,
	OptionalInt dealerTotal,
	Wager wager,
	int stake,
	Settlement settlement
) {}

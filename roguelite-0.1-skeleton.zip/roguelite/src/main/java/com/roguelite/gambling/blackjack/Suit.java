package com.roguelite.gambling.blackjack;

public enum Suit {
	CLUBS("C"),
	DIAMONDS("D"),
	HEARTS("H"),
	SPADES("S");

	public final String symbol;

	Suit(String symbol) {
		this.symbol = symbol;
	}
}

package com.roguelite.gambling.game;

import com.roguelite.core.RunManager;
import com.roguelite.gambling.session.GamblingSession;
import com.roguelite.gambling.session.ScreenModel;
import com.roguelite.net.GamblingScreenPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Connects Minecraft to the pure-Java GamblingSession: one session per player who has the Dealer's Deck open.
 * Server thread only. All the rules live in GamblingSession; this class moves screens, cleans up and logs rounds.
 */
public final class GamblingManager {
	private static final Map<UUID, GamblingSession> SESSIONS = new HashMap<>();
	private static final SecureRandom RANDOM = new SecureRandom();

	private GamblingManager() {}

	/** Right-click with the Dealer's Deck. Only works for the owner of an active run. */
	public static void open(ServerPlayerEntity player) {
		if (RunManager.activeRun() == null || !RunManager.isOwner(player)) {
			player.sendMessage(Text.literal("The Dealer's Deck only works during your own active run.").formatted(Formatting.RED), true);
			return;
		}
		GamblingSession session = SESSIONS.get(player.getUuid());
		if (session == null) {
			session = new GamblingSession(new InventoryChips(player), new RunRelics(player), RANDOM);
			SESSIONS.put(player.getUuid(), session);
			send(player, session.open());
		} else {
			send(player, session.currentScreen());
		}
	}

	public static void handle(ServerPlayerEntity player, String action, String arg, int amount) {
		GamblingSession session = SESSIONS.get(player.getUuid());
		if (session == null) {
			send(player, ScreenModel.closed());
			return;
		}
		if (RunManager.activeRun() == null || !RunManager.isOwner(player)) {
			SESSIONS.remove(player.getUuid());
			send(player, ScreenModel.closed());
			return;
		}
		int before = session.roundsSettled();
		ScreenModel model = session.handle(action, arg, amount);
		logIfSettled(player, session, before);
		if (model.close()) SESSIONS.remove(player.getUuid());
		send(player, model);
	}

	/** Disconnecting mid-round finishes the round for the player. It is never a refund. */
	public static void onDisconnect(ServerPlayerEntity player) {
		GamblingSession session = SESSIONS.remove(player.getUuid());
		if (session != null) {
			int before = session.roundsSettled();
			session.forceFinish();
			logIfSettled(player, session, before);
		}
	}

	/** The run is over (the owner died), so there is nothing left to settle. */
	public static void onPlayerDeath(ServerPlayerEntity player) {
		SESSIONS.remove(player.getUuid());
	}

	/** Must run before the Run Manager forgets the run, so relic outcomes can still be applied. */
	public static void onServerStopping() {
		List<GamblingSession> open = new ArrayList<>(SESSIONS.values());
		SESSIONS.clear();
		for (GamblingSession session : open) {
			session.forceFinish();
		}
	}

	private static void logIfSettled(ServerPlayerEntity player, GamblingSession session, int before) {
		if (session.roundsSettled() > before) {
			RunManager.recordGamble(player, session.lastNet(), session.lastWasRelic(), session.lastRelicOutcome());
		}
	}

	private static void send(ServerPlayerEntity player, ScreenModel model) {
		ServerPlayNetworking.send(player,
			new GamblingScreenPayload(model.title(), model.lines(), model.buttons(), model.close()));
	}
}

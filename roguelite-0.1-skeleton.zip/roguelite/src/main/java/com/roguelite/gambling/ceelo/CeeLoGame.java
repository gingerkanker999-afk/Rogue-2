package com.roguelite.gambling.ceelo;

import com.roguelite.gambling.RelicOutcome;
import com.roguelite.gambling.Wager;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * One round of Cee-lo against the dealer (the "banker"), as a small state machine:
 * BETTING -> AWAITING_ROLL -> SETTLED.
 *
 * Pure Java, no Minecraft types, no Luck input. Rules (traditional banker rules):
 * - The dealer rolls first, rerolling until the roll scores.
 *   Dealer 4-5-6 or a triple wins at once. Dealer 1-2-3 loses at once. Otherwise the dealer has a point (1-6).
 * - Then the player rolls, rerolling until the roll scores.
 *   Player 4-5-6 or a triple wins. Player 1-2-3 loses. Otherwise the higher point wins and equal points push.
 * - Pays 1:1. There is deliberately NO raising or doubling after the dealer's roll is shown: that would let the
 *   player bet big when the dealer has a low point, which turns the game from a ~0.93% house edge into a large
 *   player edge.
 *
 * Because a player who leaves after seeing the dealer's roll would be dodging a likely loss, the caller must
 * treat a disconnect / closed screen as an immediate {@link #rollPlayer()} (never as a refund).
 */
public final class CeeLoGame {
	public enum Phase { BETTING, AWAITING_ROLL, SETTLED }

	public enum Outcome { WIN, LOSE, PUSH }

	/** Safety net so a broken DiceSource can never hang the server. Real odds of reaching it are about 1 in 2^100. */
	private static final int MAX_ROLLS = 100;

	private final DiceSource dice;
	private final List<DiceRoll> dealerRolls = new ArrayList<>();
	private final List<DiceRoll> playerRolls = new ArrayList<>();

	private Phase phase = Phase.BETTING;
	private Wager wager;
	private int stake;
	private RollScore dealerScore;
	private RollScore playerScore;
	private CeeLoSettlement settlement;

	public CeeLoGame(DiceSource dice) {
		this.dice = Objects.requireNonNull(dice);
	}

	public Phase phase() {
		return phase;
	}

	public CeeLoSettlement settlement() {
		return settlement;
	}

	/** Places the bet and rolls the dealer's dice. May settle the round immediately. */
	public void start(Wager wager) {
		requirePhase(Phase.BETTING);
		this.wager = Objects.requireNonNull(wager);
		this.stake = wager instanceof Wager.ChipWager chips ? chips.amount() : 0;

		dealerScore = rollUntilScoring(dealerRolls);
		switch (dealerScore.kind()) {
			case AUTO_WIN, TRIPLE -> settle(Outcome.LOSE);
			case AUTO_LOSS -> settle(Outcome.WIN);
			default -> phase = Phase.AWAITING_ROLL;
		}
	}

	/** The player's only action: roll. */
	public void rollPlayer() {
		requirePhase(Phase.AWAITING_ROLL);
		playerScore = rollUntilScoring(playerRolls);
		switch (playerScore.kind()) {
			case AUTO_WIN, TRIPLE -> settle(Outcome.WIN);
			case AUTO_LOSS -> settle(Outcome.LOSE);
			default -> {
				if (playerScore.value() > dealerScore.value()) {
					settle(Outcome.WIN);
				} else if (playerScore.value() < dealerScore.value()) {
					settle(Outcome.LOSE);
				} else {
					settle(Outcome.PUSH);
				}
			}
		}
	}

	private RollScore rollUntilScoring(List<DiceRoll> history) {
		for (int i = 0; i < MAX_ROLLS; i++) {
			DiceRoll roll = dice.next();
			history.add(roll);
			RollScore score = RollScore.of(roll);
			if (score.isFinal()) return score;
		}
		throw new IllegalStateException("No scoring roll after " + MAX_ROLLS + " rolls");
	}

	private void settle(Outcome outcome) {
		int payout = 0;
		RelicOutcome relic = RelicOutcome.NONE;
		if (wager instanceof Wager.ChipWager) {
			payout = switch (outcome) {
				case WIN -> stake * 2;
				case PUSH -> stake;
				case LOSE -> 0;
			};
		} else {
			relic = switch (outcome) {
				case WIN -> RelicOutcome.WON;
				case PUSH -> RelicOutcome.KEPT;
				case LOSE -> RelicOutcome.LOST;
			};
		}
		settlement = new CeeLoSettlement(outcome, stake, payout, relic, dealerScore, playerScore);
		phase = Phase.SETTLED;
	}

	public CeeLoView view() {
		return new CeeLoView(
			phase,
			List.copyOf(dealerRolls),
			dealerScore,
			List.copyOf(playerRolls),
			playerScore,
			wager,
			stake,
			settlement);
	}

	private void requirePhase(Phase expected) {
		if (phase != expected) {
			throw new IllegalStateException("Expected phase " + expected + " but was " + phase);
		}
	}
}

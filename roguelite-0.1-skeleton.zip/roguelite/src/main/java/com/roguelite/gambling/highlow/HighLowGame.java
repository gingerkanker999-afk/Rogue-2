package com.roguelite.gambling.highlow;

import java.util.Objects;

/**
 * High-Low: a card is shown, you guess whether the next one is higher or lower. Each right guess grows the pot.
 * Ranks run 2-14 (ace high) and a tie loses. Each guess pays 95% of fair odds, so every step costs the house 5%
 * of the pot. There is no skill edge: the only real choice is when to cash out.
 */
public final class HighLowGame {
	public enum Phase { BETTING, GUESSING, SETTLED }

	public enum Guess { HIGHER, LOWER }

	public enum Outcome { CASH_OUT, LOSE }

	/** Supplies ranks 2-14 (ace = 14). Tests script it; the game uses a random generator. */
	@FunctionalInterface
	public interface RankSource {
		int next();
	}

	public static final int MIN_RANK = 2;
	public static final int MAX_RANK = 14;
	public static final int MAX_STEPS = 4;
	private static final int RANK_COUNT = 13;
	private static final long RETAIN_PERCENT = 95;

	private final RankSource ranks;
	private Phase phase = Phase.BETTING;
	private int stake;
	private int pot;
	private int current;
	private int steps;
	private Outcome outcome;
	private int payout;

	public HighLowGame(RankSource ranks) {
		this.ranks = Objects.requireNonNull(ranks, "ranks");
	}

	public Phase phase() { return phase; }
	public int stake() { return stake; }
	public int pot() { return pot; }
	public int current() { return current; }
	public int steps() { return steps; }
	public Outcome outcome() { return outcome; }
	public int payout() { return payout; }
	public int chipNet() { return payout - stake; }

	public void start(int stake) {
		if (phase != Phase.BETTING) throw new IllegalStateException("Round already started");
		if (stake < 1) throw new IllegalArgumentException("stake must be at least 1");
		this.stake = stake;
		this.pot = stake;
		this.current = checkRank(ranks.next());
		this.steps = 0;
		this.phase = Phase.GUESSING;
	}

	public boolean canGuess(Guess guess) {
		if (phase != Phase.GUESSING || steps >= MAX_STEPS) return false;
		return guess == Guess.HIGHER ? current < MAX_RANK : current > MIN_RANK;
	}

	/** How many of the 13 equally likely ranks win this guess. */
	public int winningCards(Guess guess) {
		return guess == Guess.HIGHER ? MAX_RANK - current : current - MIN_RANK;
	}

	public void guess(Guess guess) {
		if (!canGuess(guess)) throw new IllegalStateException("Illegal guess");
		int drawn = checkRank(ranks.next());
		boolean won = guess == Guess.HIGHER ? drawn > current : drawn < current;
		int wins = winningCards(guess);
		current = drawn;
		if (won) {
			pot = (int) Math.min(Integer.MAX_VALUE, (long) pot * RETAIN_PERCENT * RANK_COUNT / (100L * wins));
			steps++;
		} else {
			settle(Outcome.LOSE, 0);
		}
	}

	public void cashOut() {
		if (phase != Phase.GUESSING) throw new IllegalStateException("Nothing to cash out");
		settle(Outcome.CASH_OUT, pot);
	}

	private void settle(Outcome result, int amount) {
		this.outcome = result;
		this.payout = amount;
		this.phase = Phase.SETTLED;
	}

	private static int checkRank(int rank) {
		if (rank < MIN_RANK || rank > MAX_RANK) throw new IllegalArgumentException("rank out of range: " + rank);
		return rank;
	}
}

package com.roguelite.gambling.ceelo;

import com.roguelite.gambling.Wager;

import java.util.Objects;
import java.util.Optional;

/** One Cee-lo session at a table. Holds the dice source and the current round. */
public final class CeeLoTable {
	private final DiceSource dice;
	private int roundsPlayed;
	private CeeLoGame game;

	public CeeLoTable(DiceSource dice) {
		this.dice = Objects.requireNonNull(dice);
	}

	public int roundsPlayed() {
		return roundsPlayed;
	}

	public boolean roundInProgress() {
		return game != null && game.phase() != CeeLoGame.Phase.SETTLED;
	}

	public void startRound(Wager wager) {
		if (roundInProgress()) {
			throw new IllegalStateException("A round is already in progress");
		}
		game = new CeeLoGame(dice);
		game.start(wager);
		roundsPlayed++;
	}

	public void rollPlayer() {
		if (game == null) throw new IllegalStateException("No round has been started");
		game.rollPlayer();
	}

	public Optional<CeeLoView> view() {
		return game == null ? Optional.empty() : Optional.of(game.view());
	}
}

package com.roguelite.gambling.blackjack;

public enum Phase {
	BETTING,
	PLAYER_TURN,
	DEALER_TURN,
	SETTLED
}

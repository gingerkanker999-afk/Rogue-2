package com.roguelite.gambling.blackjack;

import com.roguelite.gambling.RelicOutcome;
import com.roguelite.gambling.Wager;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.OptionalInt;
import java.util.Set;

/**
 * One round of Blackjack as a state machine: BETTING -> PLAYER_TURN -> DEALER_TURN -> SETTLED.
 *
 * Pure Java - no Minecraft types, no Luck input of any kind. Rules: dealer stands on all 17s (including soft 17),
 * blackjack pays 3:2, actions are hit / stand / double (any first two cards) / surrender (only if allowed),
 * no splits, no insurance. The dealer checks for a natural immediately, so a dealer blackjack ends the round
 * before the player can act.
 */
public final class BlackjackGame {
	private final Shoe shoe;
	private final Hand player = new Hand();
	private final Hand dealer = new Hand();

	private Phase phase = Phase.BETTING;
	private Wager wager;
	private boolean surrenderAllowed;
	private int initialStake;
	private int stake;
	private boolean acted;
	private Settlement settlement;

	public BlackjackGame(Shoe shoe) {
		this.shoe = Objects.requireNonNull(shoe);
	}

	public Phase phase() {
		return phase;
	}

	public Settlement settlement() {
		return settlement;
	}

	/** Places the bet and deals: player, dealer (up), player, dealer (hole). */
	public void start(Wager wager, boolean surrenderAllowed) {
		requirePhase(Phase.BETTING);
		this.wager = Objects.requireNonNull(wager);
		this.surrenderAllowed = surrenderAllowed;
		this.initialStake = wager instanceof Wager.ChipWager chips ? chips.amount() : 0;
		this.stake = initialStake;

		player.add(shoe.draw());
		dealer.add(shoe.draw());
		player.add(shoe.draw());
		dealer.add(shoe.draw());

		if (dealer.isBlackjack()) {
			settle(player.isBlackjack() ? Outcome.PUSH : Outcome.LOSE);
		} else if (player.isBlackjack()) {
			settle(Outcome.PLAYER_BLACKJACK);
		} else {
			phase = Phase.PLAYER_TURN;
		}
	}

	/**
	 * @param spareChips chips the player holds beyond the stake right now (the caller re-reads this before every
	 *                   action). Doubling needs at least the original stake spare.
	 */
	public Set<Action> legalActions(int spareChips) {
		Set<Action> actions = EnumSet.noneOf(Action.class);
		if (phase != Phase.PLAYER_TURN) return actions;
		actions.add(Action.HIT);
		actions.add(Action.STAND);
		if (!acted) {
			if (wager instanceof Wager.ChipWager && spareChips >= initialStake) {
				actions.add(Action.DOUBLE);
			}
			if (surrenderAllowed) {
				actions.add(Action.SURRENDER);
			}
		}
		return actions;
	}

	public void act(Action action, int spareChips) {
		requirePhase(Phase.PLAYER_TURN);
		if (!legalActions(spareChips).contains(action)) {
			throw new IllegalStateException("Illegal action: " + action);
		}
		acted = true;
		switch (action) {
			case HIT -> {
				player.add(shoe.draw());
				if (player.isBust()) {
					settle(Outcome.LOSE);
				} else if (player.total() == 21) {
					playDealer();
				}
			}
			case STAND -> playDealer();
			case DOUBLE -> {
				stake += initialStake;
				player.add(shoe.draw());
				if (player.isBust()) {
					settle(Outcome.LOSE);
				} else {
					playDealer();
				}
			}
			case SURRENDER -> settle(Outcome.SURRENDER);
		}
	}

	private void playDealer() {
		phase = Phase.DEALER_TURN;
		while (dealer.total() < 17) {
			dealer.add(shoe.draw());
		}
		int p = player.total();
		int d = dealer.total();
		if (dealer.isBust() || p > d) {
			settle(Outcome.WIN);
		} else if (p == d) {
			settle(Outcome.PUSH);
		} else {
			settle(Outcome.LOSE);
		}
	}

	private void settle(Outcome outcome) {
		int finalStake = 0;
		int payout = 0;
		RelicOutcome relic = RelicOutcome.NONE;

		if (wager instanceof Wager.ChipWager) {
			finalStake = stake;
			payout = switch (outcome) {
				case PLAYER_BLACKJACK -> stake + (stake * 3) / 2;
				case WIN -> stake * 2;
				case PUSH, SURRENDER -> stake;
				case LOSE -> 0;
			};
		} else {
			relic = switch (outcome) {
				case PLAYER_BLACKJACK, WIN -> RelicOutcome.WON;
				case PUSH, SURRENDER -> RelicOutcome.KEPT;
				case LOSE -> RelicOutcome.LOST;
			};
		}

		settlement = new Settlement(outcome, finalStake, payout, relic, player.total(), dealer.total());
		phase = Phase.SETTLED;
	}

	/** Snapshot safe to send to the client. */
	public GameView view() {
		boolean hidden = phase == Phase.PLAYER_TURN;
		List<Card> dealerCards = new ArrayList<>(dealer.cards());
		if (hidden && dealerCards.size() > 1) {
			dealerCards = new ArrayList<>(dealerCards.subList(0, 1));
		}
		return new GameView(
			phase,
			List.copyOf(player.cards()),
			player.total(),
			player.isSoft(),
			List.copyOf(dealerCards),
			hidden,
			hidden ? OptionalInt.empty() : OptionalInt.of(dealer.total()),
			wager,
			stake,
			settlement);
	}

	private void requirePhase(Phase expected) {
		if (phase != expected) {
			throw new IllegalStateException("Expected phase " + expected + " but was " + phase);
		}
	}
}

package com.roguelite.gambling.blackjack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Hand {
	private final List<Card> cards = new ArrayList<>();

	public void add(Card card) {
		cards.add(card);
	}

	public List<Card> cards() {
		return Collections.unmodifiableList(cards);
	}

	/** Best total: aces count as 11 unless that would bust, then as 1. */
	public int total() {
		int sum = 0;
		int aces = 0;
		for (Card c : cards) {
			sum += c.rank().value;
			if (c.rank().isAce()) aces++;
		}
		while (sum > 21 && aces > 0) {
			sum -= 10;
			aces--;
		}
		return sum;
	}

	/** True if an ace is still being counted as 11. */
	public boolean isSoft() {
		int sum = 0;
		int aces = 0;
		for (Card c : cards) {
			sum += c.rank().value;
			if (c.rank().isAce()) aces++;
		}
		while (sum > 21 && aces > 0) {
			sum -= 10;
			aces--;
		}
		return aces > 0 && sum <= 21;
	}

	public boolean isBust() {
		return total() > 21;
	}

	/** A natural: exactly two cards totalling 21. */
	public boolean isBlackjack() {
		return cards.size() == 2 && total() == 21;
	}
}

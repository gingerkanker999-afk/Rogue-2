package com.roguelite.gambling.session;

import java.util.List;

/** The player's relics for the current run, as far as gambling needs them. */
public interface Relics {
	record Ref(String instanceId, String relicId, String name) {}

	record Option(String relicId, String name, String description) {}

	/** Relics that may be put up as a wager. */
	List<Ref> wagerable();

	/** Permanently removes this relic instance from the run. */
	void lose(String instanceId);

	/** Up to {@code count} distinct random relics the player does not already own. */
	List<Option> rollOptions(int count);

	void grant(String relicId);

	/** How many instances of this relic definition the player owns. */
	int countOf(String relicId);

	/** A per-run counter (for purchase caps). Zero by default. */
	default int counter(String key) { return 0; }

	/** Adds one to a per-run counter. */
	default void bump(String key) {}

	/** Name of tomorrow's Daily Roll, or null if the run's modifier has no Daily Roll. */
	default String upcomingDailyRoll() { return null; }
}

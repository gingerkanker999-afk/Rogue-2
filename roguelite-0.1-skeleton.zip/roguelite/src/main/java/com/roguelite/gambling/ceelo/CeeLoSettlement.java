package com.roguelite.gambling.ceelo;

import com.roguelite.gambling.RelicOutcome;

/**
 * Final result of a round. Chip wagers: the caller escrows {@code stake} up front and hands back
 * {@code chipPayout} (stake x2 on a win, the stake on a push, 0 on a loss). Relic wagers: stake and payout are 0 and
 * {@code relicOutcome} says what happens to the relic. {@code playerScore} is null if the dealer settled it
 * before the player rolled.
 */
public record CeeLoSettlement(
	CeeLoGame.Outcome outcome,
	int stake,
	int chipPayout,
	RelicOutcome relicOutcome,
	RollScore dealerScore,
	RollScore playerScore
) {
	public int chipNet() {
		return chipPayout - stake;
	}
}

package com.roguelite.gambling.blackjack;

import com.roguelite.gambling.RelicOutcome;

/**
 * The final result of a round.
 *
 * Chip wagers: the caller removes the stake from the player up front (escrow), and on SETTLED hands back
 * {@code chipPayout} chips (0 on a loss). If the player doubled, {@code finalStake} is the total that was at risk.
 * Blackjack pays 3:2 on the stake, rounded down (so a 1-chip stake gets 1 chip of profit).
 *
 * Relic wagers: finalStake and chipPayout are 0 and {@code relicOutcome} says what to do with the relic.
 */
public record Settlement(
	Outcome outcome,
	int finalStake,
	int chipPayout,
	RelicOutcome relicOutcome,
	int playerTotal,
	int dealerTotal
) {
	/** Net chips gained (positive) or lost (negative) compared with before the round. */
	public int chipNet() {
		return chipPayout - finalStake;
	}
}

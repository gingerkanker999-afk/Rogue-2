package com.roguelite.gambling.ceelo;

import com.roguelite.gambling.Wager;

import java.util.List;

/**
 * What the client may see. All dice shown are already rolled and public (the dealer rolls first, in the open);
 * the player's dice are only rolled when the server receives the roll request. Nullable fields: dealerScore /
 * playerScore / settlement are null until they exist.
 */
public record CeeLoView(
	CeeLoGame.Phase phase,
	List<DiceRoll> dealerRolls,
	RollScore dealerScore,
	List<DiceRoll> playerRolls,
	RollScore playerScore,
	Wager wager,
	int stake,
	CeeLoSettlement settlement
) {}

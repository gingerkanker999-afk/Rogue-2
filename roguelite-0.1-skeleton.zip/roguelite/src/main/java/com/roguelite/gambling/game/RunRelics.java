package com.roguelite.gambling.game;

import com.roguelite.core.RunManager;
import com.roguelite.core.RunState;
import com.roguelite.gambling.session.Relics;
import com.roguelite.relic.RelicDef;
import com.roguelite.relic.RelicInstance;
import com.roguelite.relic.RelicRegistry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** The relics of the player's active run, as the gambling session sees them. Null-safe if the run has ended. */
public final class RunRelics implements Relics {
	private final ServerPlayerEntity player;
	private final Random random = new Random();

	public RunRelics(ServerPlayerEntity player) {
		this.player = player;
	}

	@Override
	public List<Ref> wagerable() {
		RunState run = RunManager.activeRun();
		List<Ref> refs = new ArrayList<>();
		if (run == null) return refs;
		for (RelicInstance instance : run.relics) {
			RelicDef def = RelicRegistry.get(instance.relicId);
			if (def != null && def.wagerable) {
				refs.add(new Ref(instance.instanceId, instance.relicId, def.name));
			}
		}
		return refs;
	}

	@Override
	public void lose(String instanceId) {
		RunState run = RunManager.activeRun();
		if (run == null) return;
		RelicInstance found = null;
		for (RelicInstance instance : run.relics) {
			if (instance.instanceId.equals(instanceId)) found = instance;
		}
		if (found == null) return;
		run.relics.remove(found);
		RelicRegistry.effectFor(found.relicId).onDeactivate(player, run);
		RunManager.refreshRelicItems(player);
		RunManager.saveRun();
	}

	@Override
	public List<Option> rollOptions(int count) {
		List<Option> options = new ArrayList<>();
		RunState run = RunManager.activeRun();
		if (run == null) return options;
		Set<String> exclude = new HashSet<>();
		for (RelicInstance instance : run.relics) exclude.add(instance.relicId);
		for (int i = 0; i < count; i++) {
			RelicDef def = RelicRegistry.rollOne(random, exclude);
			if (def == null) break;
			exclude.add(def.id);
			options.add(new Option(def.id, def.name, def.description));
		}
		return options;
	}

	@Override
	public void grant(String relicId) {
		// found = false: relics won at the table do not pay the "relic found" run reward.
		if (RunManager.grantRelic(player, relicId, false)) {
			RelicDef def = RelicRegistry.get(relicId);
			if (def != null) {
				player.sendMessage(Text.literal("Relic gained: " + def.name + " - " + def.description).formatted(Formatting.AQUA), false);
			}
		}
	}

	@Override
	public int countOf(String relicId) {
		RunState run = RunManager.activeRun();
		if (run == null) return 0;
		int n = 0;
		for (RelicInstance instance : run.relics) {
			if (instance.relicId.equals(relicId)) n++;
		}
		return n;
	}
}

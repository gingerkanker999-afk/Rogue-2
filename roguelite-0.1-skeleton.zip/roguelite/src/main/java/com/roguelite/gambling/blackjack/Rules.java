package com.roguelite.gambling.blackjack;

/**
 * Table rules. The fixed rules (dealer stands on all 17s, blackjack pays 3:2, no splits, double on any first two
 * cards) are built into the engine; only shoe size is configurable.
 */
public record Rules(int decks, int reshuffleBelow) {
	public Rules {
		if (decks < 1) throw new IllegalArgumentException("decks must be >= 1");
		if (reshuffleBelow < 0) throw new IllegalArgumentException("reshuffleBelow must be >= 0");
	}

	/** 6 decks, reshuffled when fewer than 52 cards remain. */
	public static Rules standard() {
		return new Rules(6, 52);
	}
}

package com.roguelite.gambling.session;

/** One button on a gambling screen: what it says and which action (plus optional argument/amount) it sends back. */
public record ButtonSpec(String label, String action, String arg, int amount) {
	public static ButtonSpec of(String label, String action) {
		return new ButtonSpec(label, action, "", 0);
	}

	public static ButtonSpec of(String label, String action, String arg) {
		return new ButtonSpec(label, action, arg, 0);
	}

	public static ButtonSpec of(String label, String action, int amount) {
		return new ButtonSpec(label, action, "", amount);
	}
}

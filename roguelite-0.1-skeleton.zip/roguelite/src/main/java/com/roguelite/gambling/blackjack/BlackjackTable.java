package com.roguelite.gambling.blackjack;

import com.roguelite.gambling.Wager;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.random.RandomGenerator;

/**
 * A Blackjack session at one table: one shoe that persists across rounds, plus the number of free surrenders
 * the player has (Hollow Coin grants 1 per table). This is the object the server keeps per open table.
 */
public final class BlackjackTable {
	private final Rules rules;
	private final Shoe shoe;
	private int freeSurrendersLeft;
	private int roundsPlayed;
	private BlackjackGame game;

	public BlackjackTable(Rules rules, RandomGenerator rng, int freeSurrenders) {
		this(rules, new Shoe(rules.decks(), Objects.requireNonNull(rng)), freeSurrenders);
	}

	/** Public so tests (and the gambling session tests) can supply a stacked shoe. */
	public BlackjackTable(Rules rules, Shoe shoe, int freeSurrenders) {
		this.rules = Objects.requireNonNull(rules);
		this.shoe = Objects.requireNonNull(shoe);
		this.freeSurrendersLeft = Math.max(0, freeSurrenders);
	}

	public int freeSurrendersLeft() {
		return freeSurrendersLeft;
	}

	public int roundsPlayed() {
		return roundsPlayed;
	}

	public boolean roundInProgress() {
		return game != null && game.phase() != Phase.SETTLED;
	}

	public void startRound(Wager wager) {
		if (roundInProgress()) {
			throw new IllegalStateException("A round is already in progress");
		}
		if (shoe.remaining() < rules.reshuffleBelow()) {
			shoe.shuffle();
		}
		game = new BlackjackGame(shoe);
		game.start(wager, freeSurrendersLeft > 0);
		roundsPlayed++;
	}

	public Set<Action> legalActions(int spareChips) {
		return game == null ? Set.of() : game.legalActions(spareChips);
	}

	public void act(Action action, int spareChips) {
		if (game == null) throw new IllegalStateException("No round has been started");
		game.act(action, spareChips);
		if (action == Action.SURRENDER) {
			freeSurrendersLeft--;
		}
	}

	public Optional<GameView> view() {
		return game == null ? Optional.empty() : Optional.of(game.view());
	}
}

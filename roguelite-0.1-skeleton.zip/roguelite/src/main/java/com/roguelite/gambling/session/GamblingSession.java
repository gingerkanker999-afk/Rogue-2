package com.roguelite.gambling.session;

import com.roguelite.gambling.RelicOutcome;
import com.roguelite.gambling.Wager;
import com.roguelite.gambling.blackjack.Action;
import com.roguelite.gambling.blackjack.BlackjackTable;
import com.roguelite.gambling.blackjack.GameView;
import com.roguelite.gambling.blackjack.Rules;
import com.roguelite.gambling.blackjack.Settlement;
import com.roguelite.gambling.ceelo.CeeLoSettlement;
import com.roguelite.gambling.ceelo.CeeLoTable;
import com.roguelite.gambling.ceelo.CeeLoView;
import com.roguelite.gambling.ceelo.DiceSource;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.IntFunction;
import java.util.function.Supplier;
import java.util.random.RandomGenerator;

/**
 * One player's visit to the Dealer's Deck, driven entirely by string actions and answered with ScreenModels.
 * Pure Java: chips and relics come in through interfaces, so the whole flow is unit-tested without Minecraft.
 *
 * The server trusts nothing from the client: every action is checked against the current state, bets are range-checked
 * and escrowed (taken from the player up front), and {@link #forceFinish()} finishes a round in progress when the
 * player leaves or disconnects, so closing the screen is never a way to dodge a loss.
 */
public final class GamblingSession {
	public static final int MAX_BET = 100;
	private static final int[] BET_STEPS = {1, 5, 10, 25, 50};
	private static final String HOLLOW_COIN = "hollow_coin";

	private enum State { MENU, BET, IN_ROUND, RESULT, RELIC_CHOICE }

	private enum Game { BLACKJACK, CEELO }

	private final Chips chips;
	private final Relics relics;
	private final RandomGenerator rng;
	private final IntFunction<BlackjackTable> blackjackFactory;
	private final Supplier<DiceSource> diceFactory;

	private State state = State.MENU;
	private Game game = Game.BLACKJACK;
	private BlackjackTable blackjack;
	private CeeLoTable ceelo;

	private int escrow;
	private int initialStake;
	private String wageredInstanceId;
	private String wageredName;
	private List<Relics.Option> options = List.of();
	private List<String> resultLines = List.of();

	public GamblingSession(Chips chips, Relics relics, RandomGenerator rng) {
		this(chips, relics, rng,
			freeSurrenders -> new BlackjackTable(Rules.standard(), rng, freeSurrenders),
			() -> DiceSource.random(rng));
	}

	public GamblingSession(Chips chips, Relics relics, RandomGenerator rng,
						   IntFunction<BlackjackTable> blackjackFactory, Supplier<DiceSource> diceFactory) {
		this.chips = Objects.requireNonNull(chips);
		this.relics = Objects.requireNonNull(relics);
		this.rng = Objects.requireNonNull(rng);
		this.blackjackFactory = Objects.requireNonNull(blackjackFactory);
		this.diceFactory = Objects.requireNonNull(diceFactory);
	}

	/** Chips currently held in escrow for a round in progress (0 between rounds). */
	public int escrowedChips() {
		return escrow;
	}

	public ScreenModel open() {
		state = State.MENU;
		return currentScreen();
	}

	// ------------------------------------------------------------------------------------------ actions

	public ScreenModel handle(String action, String arg, int amount) {
		if (action == null) return invalid("Unknown action.");
		String a = arg == null ? "" : arg;
		try {
			return switch (action) {
				case "menu" -> toMenu();
				case "play" -> toBet(a);
				case "bet_chips" -> betChips(amount);
				case "bet_relic" -> betRelic(a);
				case "hit" -> blackjackAction(Action.HIT);
				case "stand" -> blackjackAction(Action.STAND);
				case "double" -> blackjackAction(Action.DOUBLE);
				case "surrender" -> blackjackAction(Action.SURRENDER);
				case "roll" -> ceeloRoll();
				case "choose_relic" -> chooseRelic(a);
				case "leave" -> forceFinish();
				default -> invalid("Unknown action.");
			};
		} catch (IllegalStateException | IllegalArgumentException e) {
			return invalid("That isn't possible right now.");
		}
	}

	private ScreenModel toMenu() {
		if (state != State.MENU && state != State.BET && state != State.RESULT) return invalid("Finish your round first.");
		state = State.MENU;
		return currentScreen();
	}

	private ScreenModel toBet(String which) {
		if (state != State.MENU && state != State.BET && state != State.RESULT) return invalid("Finish your round first.");
		if (which.equals("blackjack")) {
			game = Game.BLACKJACK;
		} else if (which.equals("ceelo")) {
			game = Game.CEELO;
		} else {
			return invalid("Unknown game.");
		}
		state = State.BET;
		return currentScreen();
	}

	private ScreenModel betChips(int amount) {
		if (state != State.BET) return invalid("You can't bet right now.");
		if (amount < 1 || amount > MAX_BET) return invalid("Bet between 1 and " + MAX_BET + " chips.");
		if (chips.count() < amount) return invalid("You don't have that many chips.");
		if (!chips.take(amount)) return invalid("You don't have that many chips.");
		escrow = amount;
		initialStake = amount;
		wageredInstanceId = null;
		wageredName = null;
		return startRound(new Wager.ChipWager(amount));
	}

	private ScreenModel betRelic(String instanceId) {
		if (state != State.BET) return invalid("You can't bet right now.");
		Relics.Ref ref = null;
		for (Relics.Ref r : relics.wagerable()) {
			if (r.instanceId().equals(instanceId)) ref = r;
		}
		if (ref == null) return invalid("You can't wager that relic.");
		escrow = 0;
		initialStake = 0;
		wageredInstanceId = ref.instanceId();
		wageredName = ref.name();
		return startRound(new Wager.RelicWager(ref.instanceId()));
	}

	private ScreenModel startRound(Wager wager) {
		try {
			if (game == Game.BLACKJACK) {
				blackjack().startRound(wager);
			} else {
				ceelo().startRound(wager);
			}
		} catch (RuntimeException e) {
			refundEscrow();
			throw e;
		}
		state = State.IN_ROUND;
		return afterAction();
	}

	private ScreenModel blackjackAction(Action action) {
		if (state != State.IN_ROUND || game != Game.BLACKJACK) return invalid("That isn't possible right now.");
		int spare = chips.count();
		if (!blackjack.legalActions(spare).contains(action)) return invalid("You can't do that right now.");
		if (action == Action.DOUBLE) {
			if (!chips.take(initialStake)) return invalid("You don't have enough chips to double.");
			escrow += initialStake;
			try {
				blackjack.act(action, spare);
			} catch (RuntimeException e) {
				chips.give(initialStake);
				escrow -= initialStake;
				throw e;
			}
		} else {
			blackjack.act(action, spare);
		}
		return afterAction();
	}

	private ScreenModel ceeloRoll() {
		if (state != State.IN_ROUND || game != Game.CEELO) return invalid("That isn't possible right now.");
		ceelo.rollPlayer();
		return afterAction();
	}

	private ScreenModel chooseRelic(String relicId) {
		if (state != State.RELIC_CHOICE) return invalid("There is nothing to choose.");
		Relics.Option chosen = null;
		for (Relics.Option o : options) {
			if (o.relicId().equals(relicId)) chosen = o;
		}
		if (chosen == null) return invalid("That relic wasn't offered.");
		relics.grant(chosen.relicId());
		List<String> lines = new ArrayList<>(resultLines);
		lines.add("You claimed " + chosen.name() + ".");
		resultLines = lines;
		options = List.of();
		state = State.RESULT;
		return currentScreen();
	}

	/**
	 * Finishes whatever is in progress and ends the session. A round in progress is played out for the player
	 * (Blackjack: stand, Cee-lo: roll), and an unclaimed relic reward is picked at random.
	 */
	public ScreenModel forceFinish() {
		if (state == State.IN_ROUND) {
			try {
				if (game == Game.BLACKJACK) {
					blackjack.act(Action.STAND, chips.count());
				} else {
					ceelo.rollPlayer();
				}
				settle();
			} catch (RuntimeException e) {
				refundEscrow();
				state = State.RESULT;
				return ScreenModel.closed();
			}
		}
		if (state == State.RELIC_CHOICE && !options.isEmpty()) {
			relics.grant(options.get(rng.nextInt(options.size())).relicId());
			options = List.of();
		}
		state = State.RESULT;
		return ScreenModel.closed();
	}

	// ------------------------------------------------------------------------------------------ settling

	private boolean roundInProgress() {
		return game == Game.BLACKJACK ? blackjack.roundInProgress() : ceelo.roundInProgress();
	}

	private ScreenModel afterAction() {
		if (roundInProgress()) return currentScreen();
		return settle();
	}

	private ScreenModel settle() {
		List<String> lines = new ArrayList<>();
		int payout;
		int net;
		RelicOutcome relicOutcome;
		String headline;

		if (game == Game.BLACKJACK) {
			GameView v = blackjack.view().orElseThrow();
			Settlement s = v.settlement();
			lines.addAll(TableText.blackjackLines(v));
			headline = TableText.blackjackHeadline(s.outcome());
			payout = s.chipPayout();
			net = s.chipNet();
			relicOutcome = s.relicOutcome();
		} else {
			CeeLoView v = ceelo.view().orElseThrow();
			CeeLoSettlement s = v.settlement();
			lines.addAll(TableText.ceeloLines(v));
			headline = TableText.ceeloHeadline(s.outcome());
			payout = s.chipPayout();
			net = s.chipNet();
			relicOutcome = s.relicOutcome();
		}

		if (payout > 0) chips.give(payout);
		escrow = 0;
		lines.add(headline);

		String name = wageredName == null ? "Your relic" : wageredName;
		options = List.of();
		switch (relicOutcome) {
			case NONE -> lines.add(TableText.chipLine(net));
			case KEPT -> lines.add(name + " is returned to you.");
			case LOST -> {
				relics.lose(wageredInstanceId);
				lines.add(name + " is gone for this run.");
			}
			case WON -> {
				options = relics.rollOptions(2);
				lines.add(options.isEmpty()
					? name + " is safe. There are no new relics left to offer."
					: name + " is safe, and you may claim a new relic!");
			}
		}
		wageredInstanceId = null;
		resultLines = lines;
		state = options.isEmpty() ? State.RESULT : State.RELIC_CHOICE;
		return currentScreen();
	}

	private void refundEscrow() {
		if (escrow > 0) chips.give(escrow);
		escrow = 0;
		wageredInstanceId = null;
	}

	// ------------------------------------------------------------------------------------------ tables

	private BlackjackTable blackjack() {
		if (blackjack == null) {
			blackjack = blackjackFactory.apply(relics.countOf(HOLLOW_COIN));
		}
		return blackjack;
	}

	private CeeLoTable ceelo() {
		if (ceelo == null) {
			ceelo = new CeeLoTable(diceFactory.get());
		}
		return ceelo;
	}

	// ------------------------------------------------------------------------------------------ screens

	public ScreenModel currentScreen() {
		return switch (state) {
			case MENU -> menuScreen();
			case BET -> betScreen();
			case IN_ROUND -> roundScreen();
			case RESULT -> resultScreen();
			case RELIC_CHOICE -> choiceScreen();
		};
	}

	private ScreenModel invalid(String message) {
		ScreenModel base = currentScreen();
		List<String> lines = new ArrayList<>();
		lines.add("! " + message);
		lines.addAll(base.lines());
		return new ScreenModel(base.title(), lines, base.buttons(), false);
	}

	private ScreenModel menuScreen() {
		return new ScreenModel("Dealer's Deck",
			List.of("Chips: " + chips.count(), "Relics you could wager: " + relics.wagerable().size()),
			List.of(
				ButtonSpec.of("Play Blackjack", "play", "blackjack"),
				ButtonSpec.of("Play Cee-lo", "play", "ceelo"),
				ButtonSpec.of("Leave the table", "leave")),
			false);
	}

	private ScreenModel betScreen() {
		boolean blackjackGame = game == Game.BLACKJACK;
		List<String> lines = new ArrayList<>();
		lines.add("Chips: " + chips.count());
		lines.add(blackjackGame
			? "Blackjack pays 3:2. Dealer stands on 17."
			: "4-5-6 and triples win, 1-2-3 loses, higher point wins. Pays 1:1.");
		lines.add("Pick your wager:");

		List<ButtonSpec> buttons = new ArrayList<>();
		int held = chips.count();
		for (int step : BET_STEPS) {
			if (step <= held) buttons.add(ButtonSpec.of("Bet " + step + (step == 1 ? " chip" : " chips"), "bet_chips", step));
		}
		for (Relics.Ref ref : relics.wagerable()) {
			buttons.add(ButtonSpec.of("Wager relic: " + ref.name(), "bet_relic", ref.instanceId()));
		}
		if (buttons.isEmpty()) lines.add("You have nothing to wager.");
		buttons.add(ButtonSpec.of("Back", "menu"));
		return new ScreenModel(blackjackGame ? "Blackjack" : "Cee-lo", lines, buttons, false);
	}

	private String wagerLine() {
		return wageredInstanceId != null ? "Wager: " + wageredName : "Stake: " + escrow + (escrow == 1 ? " chip" : " chips");
	}

	private ScreenModel roundScreen() {
		List<String> lines = new ArrayList<>();
		lines.add(wagerLine());
		List<ButtonSpec> buttons = new ArrayList<>();
		if (game == Game.BLACKJACK) {
			lines.addAll(TableText.blackjackLines(blackjack.view().orElseThrow()));
			Set<Action> legal = blackjack.legalActions(chips.count());
			buttons.add(ButtonSpec.of("Hit", "hit"));
			buttons.add(ButtonSpec.of("Stand", "stand"));
			if (legal.contains(Action.DOUBLE)) buttons.add(ButtonSpec.of("Double down", "double"));
			if (legal.contains(Action.SURRENDER)) buttons.add(ButtonSpec.of("Surrender (free)", "surrender"));
			return new ScreenModel("Blackjack", lines, buttons, false);
		}
		lines.addAll(TableText.ceeloLines(ceelo.view().orElseThrow()));
		lines.add("Your turn.");
		buttons.add(ButtonSpec.of("Roll the dice", "roll"));
		return new ScreenModel("Cee-lo", lines, buttons, false);
	}

	private ScreenModel resultScreen() {
		String which = game == Game.BLACKJACK ? "blackjack" : "ceelo";
		List<String> lines = new ArrayList<>(resultLines);
		lines.add("Chips: " + chips.count());
		return new ScreenModel(game == Game.BLACKJACK ? "Blackjack" : "Cee-lo", lines,
			List.of(
				ButtonSpec.of("Play again", "play", which),
				ButtonSpec.of("Back to the table", "menu"),
				ButtonSpec.of("Leave", "leave")),
			false);
	}

	private ScreenModel choiceScreen() {
		List<String> lines = new ArrayList<>(resultLines);
		lines.add("Choose one:");
		List<ButtonSpec> buttons = new ArrayList<>();
		for (Relics.Option o : options) {
			lines.add(o.name() + ": " + o.description());
			buttons.add(ButtonSpec.of("Take " + o.name(), "choose_relic", o.relicId()));
		}
		return new ScreenModel("Claim a relic", lines, buttons, false);
	}
}

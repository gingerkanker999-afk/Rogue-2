package com.roguelite.gambling.blackjack;

import java.util.ArrayList;
import java.util.List;
import java.util.random.RandomGenerator;

/**
 * The card source. Shuffling is a plain Fisher-Yates driven only by the RandomGenerator it is given:
 * there is deliberately no way to bias it (Luck must never influence Blackjack).
 */
public final class Shoe {
	private final List<Card> cards = new ArrayList<>();
	private final int decks;
	private final RandomGenerator rng;
	private int position;

	public Shoe(int decks, RandomGenerator rng) {
		if (decks < 1) throw new IllegalArgumentException("decks must be >= 1");
		this.decks = decks;
		this.rng = rng;
		shuffle();
	}

	private Shoe(List<Card> stacked) {
		this.decks = 0;
		this.rng = null;
		this.cards.addAll(stacked);
	}

	/** A shoe that deals exactly these cards in order and cannot reshuffle. For tests. */
	public static Shoe stacked(Card... order) {
		return new Shoe(List.of(order));
	}

	/** Rebuilds all decks and shuffles them (every dealt card returns to the shoe). */
	public void shuffle() {
		if (rng == null) throw new IllegalStateException("A stacked shoe cannot be reshuffled");
		cards.clear();
		for (int d = 0; d < decks; d++) {
			for (Suit suit : Suit.values()) {
				for (Rank rank : Rank.values()) {
					cards.add(new Card(rank, suit));
				}
			}
		}
		for (int i = cards.size() - 1; i > 0; i--) {
			int j = rng.nextInt(i + 1);
			Card tmp = cards.get(i);
			cards.set(i, cards.get(j));
			cards.set(j, tmp);
		}
		position = 0;
	}

	public Card draw() {
		if (position >= cards.size()) {
			throw new IllegalStateException("The shoe is empty");
		}
		return cards.get(position++);
	}

	public int remaining() {
		return cards.size() - position;
	}
}

package com.roguelite.gambling.game;

import com.roguelite.gambling.session.Chips;
import com.roguelite.item.RogueliteItems;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

/** The player's gambling chips = every chip item in their inventory. */
public final class InventoryChips implements Chips {
	private static final int STACK = 64;

	private final ServerPlayerEntity player;

	public InventoryChips(ServerPlayerEntity player) {
		this.player = player;
	}

	@Override
	public int count() {
		PlayerInventory inv = player.getInventory();
		int total = 0;
		for (int i = 0; i < inv.size(); i++) {
			ItemStack stack = inv.getStack(i);
			if (RogueliteItems.isChip(stack)) total += stack.getCount();
		}
		return total;
	}

	@Override
	public boolean take(int amount) {
		if (amount <= 0 || count() < amount) return false;
		PlayerInventory inv = player.getInventory();
		int left = amount;
		for (int i = 0; i < inv.size() && left > 0; i++) {
			ItemStack stack = inv.getStack(i);
			if (!RogueliteItems.isChip(stack)) continue;
			int taken = Math.min(left, stack.getCount());
			stack.decrement(taken);
			left -= taken;
			if (stack.isEmpty()) inv.setStack(i, ItemStack.EMPTY);
		}
		return true;
	}

	@Override
	public void give(int amount) {
		int left = amount;
		while (left > 0) {
			int n = Math.min(left, STACK);
			ItemStack stack = RogueliteItems.create(RogueliteItems.CHIP_ID, n);
			if (!stack.isEmpty()) player.getInventory().offerOrDrop(stack);
			left -= n;
		}
	}
}

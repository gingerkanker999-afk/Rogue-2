package com.roguelite.gambling.ceelo;

import java.util.Objects;
import java.util.random.RandomGenerator;

/** Where dice come from. Tests use a scripted source; the game uses {@link #random}. Never takes Luck. */
public interface DiceSource {
	DiceRoll next();

	static DiceSource random(RandomGenerator rng) {
		Objects.requireNonNull(rng);
		return () -> new DiceRoll(rng.nextInt(6) + 1, rng.nextInt(6) + 1, rng.nextInt(6) + 1);
	}
}

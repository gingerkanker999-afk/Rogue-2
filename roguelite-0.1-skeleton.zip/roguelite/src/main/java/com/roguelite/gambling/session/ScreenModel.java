package com.roguelite.gambling.session;

import java.util.List;

/**
 * Everything the client needs to draw a gambling screen: a title, text lines and buttons.
 * The server builds it; the client is a dumb renderer. {@code close} tells the client to close the screen.
 */
public record ScreenModel(String title, List<String> lines, List<ButtonSpec> buttons, boolean close) {
	public static ScreenModel closed() {
		return new ScreenModel("", List.of(), List.of(), true);
	}

	public boolean hasAction(String action) {
		return buttons.stream().anyMatch(b -> b.action().equals(action));
	}
}

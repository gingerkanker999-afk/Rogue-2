package com.roguelite.gambling.blackjack;

public enum Rank {
	TWO("2", 2), THREE("3", 3), FOUR("4", 4), FIVE("5", 5), SIX("6", 6), SEVEN("7", 7),
	EIGHT("8", 8), NINE("9", 9), TEN("10", 10), JACK("J", 10), QUEEN("Q", 10), KING("K", 10),
	/** Counted as 11 here; Hand reduces it to 1 when needed. */
	ACE("A", 11);

	public final String symbol;
	public final int value;

	Rank(String symbol, int value) {
		this.symbol = symbol;
		this.value = value;
	}

	public boolean isAce() {
		return this == ACE;
	}
}

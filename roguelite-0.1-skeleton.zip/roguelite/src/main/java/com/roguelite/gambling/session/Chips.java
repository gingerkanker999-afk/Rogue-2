package com.roguelite.gambling.session;

/** The player's gambling chips. In-game this is backed by the inventory; tests use a fake. */
public interface Chips {
	int count();

	/** Removes exactly n chips; returns false (and removes nothing) if the player has fewer. */
	boolean take(int n);

	void give(int n);
}

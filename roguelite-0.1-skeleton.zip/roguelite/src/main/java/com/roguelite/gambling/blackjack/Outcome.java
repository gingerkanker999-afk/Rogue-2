package com.roguelite.gambling.blackjack;

public enum Outcome {
	PLAYER_BLACKJACK,
	WIN,
	PUSH,
	LOSE,
	SURRENDER
}

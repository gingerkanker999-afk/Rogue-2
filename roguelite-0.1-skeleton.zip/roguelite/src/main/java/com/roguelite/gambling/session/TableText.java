package com.roguelite.gambling.session;

import com.roguelite.gambling.blackjack.Card;
import com.roguelite.gambling.blackjack.GameView;
import com.roguelite.gambling.blackjack.Outcome;
import com.roguelite.gambling.ceelo.CeeLoGame;
import com.roguelite.gambling.ceelo.CeeLoView;
import com.roguelite.gambling.ceelo.DiceRoll;
import com.roguelite.gambling.ceelo.RollScore;

import java.util.ArrayList;
import java.util.List;

/** Turns engine views into plain text lines. Pure formatting, easy to test. */
public final class TableText {
	private static final String SPADES = "\u2660";
	private static final String HEARTS = "\u2665";
	private static final String DIAMONDS = "\u2666";
	private static final String CLUBS = "\u2663";

	private TableText() {}

	public static String card(Card card) {
		String suit = switch (card.suit()) {
			case SPADES -> SPADES;
			case HEARTS -> HEARTS;
			case DIAMONDS -> DIAMONDS;
			case CLUBS -> CLUBS;
		};
		return card.rank().symbol + suit;
	}

	private static String cards(List<Card> cards) {
		List<String> parts = new ArrayList<>();
		for (Card c : cards) parts.add(card(c));
		return String.join(" ", parts);
	}

	public static List<String> blackjackLines(GameView v) {
		List<String> lines = new ArrayList<>();
		String dealer = cards(v.dealerCards());
		if (v.dealerHoleHidden()) {
			lines.add("Dealer: " + dealer + " [?]");
		} else {
			lines.add("Dealer: " + dealer + "  =  " + v.dealerTotal().getAsInt());
		}
		lines.add("You: " + cards(v.playerCards()) + "  =  " + v.playerTotal() + (v.playerSoft() ? " (soft)" : ""));
		return lines;
	}

	public static String blackjackHeadline(Outcome outcome) {
		return switch (outcome) {
			case PLAYER_BLACKJACK -> "BLACKJACK!";
			case WIN -> "You win!";
			case PUSH -> "Push.";
			case LOSE -> "You lose.";
			case SURRENDER -> "You surrendered.";
		};
	}

	public static String scoreText(RollScore s) {
		return switch (s.kind()) {
			case AUTO_WIN -> "4-5-6!";
			case AUTO_LOSS -> "1-2-3";
			case TRIPLE -> "triple " + s.value() + "s";
			case POINT -> "point " + s.value();
			case NO_SCORE -> "no score";
		};
	}

	private static String rolls(List<DiceRoll> rolls) {
		List<String> parts = new ArrayList<>();
		for (DiceRoll r : rolls) {
			parts.add(r + " (" + scoreText(RollScore.of(r)) + ")");
		}
		return String.join("  >  ", parts);
	}

	public static List<String> ceeloLines(CeeLoView v) {
		List<String> lines = new ArrayList<>();
		if (!v.dealerRolls().isEmpty()) lines.add("Dealer: " + rolls(v.dealerRolls()));
		if (!v.playerRolls().isEmpty()) lines.add("You: " + rolls(v.playerRolls()));
		return lines;
	}

	public static String ceeloHeadline(CeeLoGame.Outcome outcome) {
		return switch (outcome) {
			case WIN -> "You win!";
			case LOSE -> "You lose.";
			case PUSH -> "Push.";
		};
	}

	public static String chipLine(int net) {
		if (net > 0) return "+" + net + " chips";
		if (net < 0) return "-" + (-net) + " chips";
		return "Your chips are returned.";
	}
}

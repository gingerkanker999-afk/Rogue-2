package com.roguelite.item;

import com.roguelite.Roguelite;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

/**
 * The mod's real items. Registered during mod init, before the registries freeze. The chip is a gambling currency,
 * craftable from gold and iron. The ward is a placeholder until its design is ready.
 */
public final class ModItems {
	public static final Item GAMBLING_CHIP = register("gambling_chip");
	public static final Item WARD = register("ward");

	private ModItems() {}

	private static Item register(String name) {
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(Roguelite.MOD_ID, name));
		return Registry.register(Registries.ITEM, key, new Item(new Item.Settings().registryKey(key)));
	}

	/** Called from mod init so the static fields above are created in time. */
	public static void register() {}
}

package com.roguelite.item;

import com.roguelite.Roguelite;
import com.roguelite.relic.RelicDef;
import com.roguelite.relic.RelicInstance;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

/**
 * Creates the mod's items from data ids.
 *
 * Chips and the Dealer's Deck are renamed vanilla items tagged with custom data. Relics are real items too: one
 * unstackable item per relic instance, named after the relic, with its description as lore. The run state is the
 * source of truth; the items are just their physical form, kept in sync by {@link #syncRelics}.
 */
public final class RogueliteItems {
	public static final String CHIP_ID = "roguelite:gambling_chip";
	public static final String DECK_ID = "roguelite:dealers_deck";

	public static final String CHIP_KEY = "roguelite_chip";
	public static final String DECK_KEY = "roguelite_deck";
	public static final String RELIC_KEY = "roguelite_relic";
	public static final String RELIC_INSTANCE_KEY = "roguelite_relic_instance";

	private RogueliteItems() {}

	/** Returns the stack for an item id, or ItemStack.EMPTY (and logs) if the id is unknown. */
	public static ItemStack create(String itemId, int count) {
		if (itemId == null || count <= 0) return ItemStack.EMPTY;

		if (CHIP_ID.equals(itemId)) {
			return new ItemStack(ModItems.GAMBLING_CHIP, count);
		}
		if (DECK_ID.equals(itemId)) {
			return tagged(new ItemStack(Items.PAPER, count), DECK_KEY,
				Text.literal("Dealer's Deck").formatted(Formatting.RED));
		}

		Identifier id = Identifier.tryParse(itemId);
		if (id == null || !Registries.ITEM.containsId(id)) {
			Roguelite.LOGGER.warn("Unknown kit item '{}' - skipped", itemId);
			return ItemStack.EMPTY;
		}
		Item item = Registries.ITEM.get(id);
		if (item == Items.AIR) {
			Roguelite.LOGGER.warn("Kit item '{}' resolved to air - skipped", itemId);
			return ItemStack.EMPTY;
		}
		return new ItemStack(item, count);
	}

	// ------------------------------------------------------------------ chips and the deck

	public static boolean isChip(ItemStack stack) {
		return stack != null && stack.isOf(ModItems.GAMBLING_CHIP);
	}

	public static boolean isDealersDeck(ItemStack stack) {
		return hasKey(stack, DECK_KEY);
	}

	private static boolean hasKey(ItemStack stack, String key) {
		if (stack == null || stack.isEmpty()) return false;
		NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
		return data != null && data.copyNbt().contains(key);
	}

	private static ItemStack tagged(ItemStack stack, String key, Text name) {
		NbtCompound tag = new NbtCompound();
		tag.putBoolean(key, true);
		stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
		stack.set(DataComponentTypes.CUSTOM_NAME, name);
		return stack;
	}

	// ------------------------------------------------------------------ relics

	/** A relic item: one per instance, never stacks, so each copy can be wagered or lost on its own. */
	public static ItemStack createRelic(RelicInstance instance, RelicDef def) {
		ItemStack stack = new ItemStack(relicBase(def.id), 1);
		NbtCompound tag = new NbtCompound();
		tag.putString(RELIC_KEY, def.id);
		tag.putString(RELIC_INSTANCE_KEY, instance.instanceId);
		stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
		stack.set(DataComponentTypes.MAX_STACK_SIZE, 1);
		stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(def.name).formatted(Formatting.AQUA));
		List<Text> lore = new ArrayList<>();
		lore.add(Text.literal(def.description).formatted(Formatting.GRAY));
		lore.add(Text.literal("Relic. Lasts for this run.").formatted(Formatting.DARK_GRAY));
		stack.set(DataComponentTypes.LORE, new LoreComponent(lore));
		return stack;
	}

	/** A distinct vanilla item per relic so they look different in the inventory. */
	private static Item relicBase(String relicId) {
		return switch (relicId) {
			case "moles_tooth" -> Items.BONE;
			case "magpies_eye" -> Items.SPYGLASS;
			case "cartographers_thumb" -> Items.COMPASS;
			case "gluttons_spoon" -> Items.GOLDEN_CARROT;
			case "black_cats_paw" -> Items.PHANTOM_MEMBRANE;
			case "hollow_coin" -> Items.COPPER_INGOT;
			case "lamplighters_lantern" -> Items.LANTERN;
			case "homing_stone" -> Items.ECHO_SHARD;
			case "slow_bleed" -> Items.GHAST_TEAR;
			case "jesters_die" -> Items.AMETHYST_SHARD;
			default -> Items.PRISMARINE_SHARD;
		};
	}

	public static String relicId(ItemStack stack) {
		return readString(stack, RELIC_KEY);
	}

	public static boolean isRelic(ItemStack stack) {
		return relicInstanceId(stack) != null;
	}

	public static String relicInstanceId(ItemStack stack) {
		return readString(stack, RELIC_INSTANCE_KEY);
	}

	private static String readString(ItemStack stack, String key) {
		if (stack == null || stack.isEmpty()) return null;
		NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
		if (data == null) return null;
		NbtCompound nbt = data.copyNbt();
		if (!nbt.contains(key)) return null;
		String value = nbt.getString(key, "");
		return value.isEmpty() ? null : value;
	}

	/**
	 * Makes the inventory match the run: keeps one item per expected relic instance, removes duplicates and items of
	 * relics that are no longer in the run, and gives items for any expected relic that is missing.
	 */
	public static void syncRelics(PlayerInventory inventory, List<RelicInstance> expected,
								  Function<String, RelicDef> defs) {
		Set<String> wanted = new HashSet<>();
		for (RelicInstance instance : expected) wanted.add(instance.instanceId);

		Set<String> kept = new HashSet<>();
		for (int i = 0; i < inventory.size(); i++) {
			String instanceId = relicInstanceId(inventory.getStack(i));
			if (instanceId == null) continue;
			if (wanted.contains(instanceId) && kept.add(instanceId)) continue;
			inventory.setStack(i, ItemStack.EMPTY);
		}

		for (RelicInstance instance : expected) {
			if (kept.contains(instance.instanceId)) continue;
			RelicDef def = defs.apply(instance.relicId);
			if (def != null) {
				inventory.offerOrDrop(createRelic(instance, def));
			}
		}
	}
}

package com.roguelite.item;

import com.roguelite.Roguelite;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

/**
 * Creates kit items from data ids.
 *
 * PLACEHOLDER IMPLEMENTATION: the gambling chip and Dealer's Deck are renamed vanilla items tagged with custom data
 * (data component), not registered custom items. They are created in exactly one place (here), so swapping in
 * real registered items later does not touch starters or the Run Manager.
 */
public final class RogueliteItems {
	public static final String CHIP_ID = "roguelite:gambling_chip";
	public static final String DECK_ID = "roguelite:dealers_deck";
	public static final String TAG_KEY = "roguelite_item";

	private RogueliteItems() {}

	/** Returns the stack for an item id, or ItemStack.EMPTY (and logs) if the id is unknown. */
	public static ItemStack create(String itemId, int count) {
		if (itemId == null || count <= 0) return ItemStack.EMPTY;

		if (CHIP_ID.equals(itemId)) {
			return tagged(new ItemStack(Items.GOLD_NUGGET, count), "gambling_chip",
				Text.literal("Gambling Chip").formatted(Formatting.GOLD));
		}
		if (DECK_ID.equals(itemId)) {
			return tagged(new ItemStack(Items.PAPER, count), "dealers_deck",
				Text.literal("Dealer's Deck").formatted(Formatting.RED));
		}

		Identifier id = Identifier.tryParse(itemId);
		if (id == null || !Registries.ITEM.containsId(id)) {
			Roguelite.LOGGER.warn("Unknown kit item '{}' - skipped", itemId);
			return ItemStack.EMPTY;
		}
		Item item = Registries.ITEM.get(id);
		if (item == Items.AIR) {
			Roguelite.LOGGER.warn("Kit item '{}' resolved to air - skipped", itemId);
			return ItemStack.EMPTY;
		}
		return new ItemStack(item, count);
	}

	private static ItemStack tagged(ItemStack stack, String tagValue, Text name) {
		NbtCompound tag = new NbtCompound();
		tag.putString(TAG_KEY, tagValue);
		stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
		stack.set(DataComponentTypes.CUSTOM_NAME, name);
		return stack;
	}
}

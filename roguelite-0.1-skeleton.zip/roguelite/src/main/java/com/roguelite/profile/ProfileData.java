package com.roguelite.profile;

import java.util.ArrayList;
import java.util.List;

/** Everything stored in the global profile file. It deliberately knows nothing about any Minecraft world. */
public class ProfileData {
	public int schemaVersion = 1;
	/** Meta currency balance. */
	public int balance;
	/** Last allocated run id; next run gets counter + 1. */
	public long runIdCounter = 0;
	/** Run ids whose reward has already been paid. This is what stops a copied world from paying out twice. */
	public List<Long> bankedRunIds = new ArrayList<>();
	/** A starter bought at the outpost, waiting for the next new world. Null if none. */
	public String pendingStarter;
	/** Stash contents: allowed item id to count. */
	public java.util.Map<String, Integer> stash = new java.util.HashMap<>();
	/** How many stash upgrades have been bought. */
	public int stashLevel;
	/** Position key of the farm's composter, or null if no farm is owned. */
	public String farmPlotKey;
	/** Food waiting on the plot, and the game day it was last settled. */
	public int farmStored;
	public long farmLastDay;
}

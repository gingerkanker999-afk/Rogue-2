package com.roguelite.profile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.roguelite.Roguelite;
import com.roguelite.util.FileUtil;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Loads and atomically saves the global profile JSON. All game rules live in MetaEconomy, not here. */
public final class ProfileStore {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private final Path file;
	private ProfileData data;

	public ProfileStore(Path file) {
		this.file = file;
	}

	public Path file() {
		return file;
	}

	public ProfileData data() {
		return data;
	}

	/** Loads the profile, creating a seeded one if none exists. A corrupt file is quarantined, never silently deleted. */
	public synchronized void load(int startingBalance) {
		if (Files.isRegularFile(file)) {
			try {
				String json = Files.readString(file, StandardCharsets.UTF_8);
				ProfileData loaded = GSON.fromJson(json, ProfileData.class);
				if (loaded != null) {
					if (loaded.bankedRunIds == null) loaded.bankedRunIds = new java.util.ArrayList<>();
					data = loaded;
					return;
				}
			} catch (Exception e) {
				Roguelite.LOGGER.error("Profile file {} is unreadable", file, e);
			}
			try {
				Path moved = FileUtil.quarantine(file);
				Roguelite.LOGGER.error("Moved the unreadable profile to {} and starting a new one", moved);
			} catch (IOException e) {
				Roguelite.LOGGER.error("Could not move the unreadable profile out of the way", e);
			}
		}

		data = new ProfileData();
		data.balance = startingBalance;
		try {
			save();
		} catch (IOException e) {
			Roguelite.LOGGER.error("Could not write the new profile", e);
		}
	}

	public synchronized void save() throws IOException {
		FileUtil.writeAtomic(file, GSON.toJson(data));
	}
}

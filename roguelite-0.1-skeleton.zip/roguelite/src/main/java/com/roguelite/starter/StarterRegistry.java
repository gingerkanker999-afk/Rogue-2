package com.roguelite.starter;

import com.google.gson.reflect.TypeToken;
import com.roguelite.Roguelite;
import com.roguelite.data.DefinitionLoader;
import com.roguelite.modifier.ModifierRegistry;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class StarterRegistry {
	private static final Map<String, StarterDef> DEFS = new LinkedHashMap<>();

	private StarterRegistry() {}

	public static void load() {
		DEFS.clear();
		List<StarterDef> list = DefinitionLoader.loadList("starters.json", new TypeToken<List<StarterDef>>() {}.getType());
		for (StarterDef def : list) {
			if (def == null || def.id == null || def.id.isBlank()) {
				Roguelite.LOGGER.warn("Skipping starter with no id");
				continue;
			}
			if (def.cost < 0) {
				Roguelite.LOGGER.warn("Starter '{}' has a negative cost; clamping to 0", def.id);
				def.cost = 0;
			}
			if (def.name == null) def.name = def.id;
			if (def.description == null) def.description = "";
			if (DEFS.putIfAbsent(def.id, def) != null) {
				Roguelite.LOGGER.warn("Duplicate starter id '{}' ignored", def.id);
			}
		}
		Roguelite.LOGGER.info("Loaded {} starters", DEFS.size());
	}

	/** Call after the modifier registry is loaded: warns about starters pointing at an empty/unknown modifier pool. */
	public static void validate() {
		for (StarterDef def : DEFS.values()) {
			if (def.modifierPool != null && !ModifierRegistry.hasPool(def.modifierPool)) {
				Roguelite.LOGGER.warn("Starter '{}' uses modifier pool '{}' which has no modifiers", def.id, def.modifierPool);
			}
		}
	}

	/** The cheapest starter (first one wins a tie). Used for the "broke" safety net. Null if there are no starters. */
	public static StarterDef cheapest() {
		StarterDef best = null;
		for (StarterDef def : DEFS.values()) {
			if (best == null || def.cost < best.cost) best = def;
		}
		return best;
	}

	public static StarterDef get(String id) {
		return id == null ? null : DEFS.get(id);
	}

	public static Collection<StarterDef> all() {
		return DEFS.values();
	}
}

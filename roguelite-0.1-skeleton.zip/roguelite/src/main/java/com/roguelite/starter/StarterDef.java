package com.roguelite.starter;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/** Data definition of a starter (loaded from starters.json). Kit contents are pure data - edit the JSON, not code. */
public class StarterDef {
	public String id;
	public String name;
	public String description;
	/** Meta currency price. */
	public int cost;
	/** Modifier pool this starter rolls from: basic, good_bad, duality or luck. */
	@SerializedName("modifier_pool")
	public String modifierPool;
	/** Starting run Luck. Placeholder scale for 0.1. */
	public int luck;
	/** How many random relics are granted at run start (not counted as "found" for rewards). */
	@SerializedName("random_relics")
	public int randomRelics;
	public List<KitItem> items = new ArrayList<>();

	public static class KitItem {
		/** Vanilla item id ("minecraft:bread") or a roguelite item id ("roguelite:gambling_chip"). */
		public String item;
		public int count = 1;
	}
}

package com.roguelite.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.roguelite.Roguelite;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Loads a JSON list definition file.
 * Lookup order: config/roguelite/<file> (user override, for balancing) then the jar's /data/roguelite/defs/<file>.
 */
public final class DefinitionLoader {
	private static final Gson GSON = new GsonBuilder().create();
	private static final String CLASSPATH_DIR = "/data/roguelite/defs/";

	private DefinitionLoader() {}

	public static <T> List<T> loadList(String fileName, Type listType) {
		Path override = FabricLoader.getInstance().getConfigDir().resolve(Roguelite.MOD_ID).resolve(fileName);
		if (Files.isRegularFile(override)) {
			try (Reader reader = Files.newBufferedReader(override, StandardCharsets.UTF_8)) {
				List<T> result = GSON.fromJson(reader, listType);
				Roguelite.LOGGER.info("Loaded {} from config override {}", fileName, override);
				return result == null ? List.of() : result;
			} catch (Exception e) {
				Roguelite.LOGGER.error("Could not read override {} - falling back to built-in defaults", override, e);
			}
		}
		try (InputStream in = DefinitionLoader.class.getResourceAsStream(CLASSPATH_DIR + fileName)) {
			if (in == null) {
				throw new IllegalStateException("Missing built-in definition file " + CLASSPATH_DIR + fileName);
			}
			try (Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
				List<T> result = GSON.fromJson(reader, listType);
				return result == null ? List.of() : result;
			}
		} catch (IOException e) {
			throw new IllegalStateException("Could not read built-in definition file " + fileName, e);
		}
	}
}

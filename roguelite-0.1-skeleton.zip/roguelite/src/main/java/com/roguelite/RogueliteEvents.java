package com.roguelite;

import com.roguelite.core.RunManager;
import com.roguelite.gambling.game.GamblingManager;
import com.roguelite.item.RogueliteItems;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.world.World;

/** Wires Fabric events to the Run Manager. Keep this file thin: decisions belong in RunManager. */
public final class RogueliteEvents {
	private RogueliteEvents() {}

	public static void register() {
		// Gambling must settle open rounds before the Run Manager forgets the run, so register it first.
		ServerLifecycleEvents.SERVER_STARTED.register(RunManager::onServerStarted);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> GamblingManager.onServerStopping());
		ServerLifecycleEvents.SERVER_STOPPING.register(RunManager::onServerStopping);
		ServerTickEvents.END_SERVER_TICK.register(RunManager::onTick);
		ServerTickEvents.END_WORLD_TICK.register(RunManager::onWorldTick);

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> RunManager.onPlayerJoin(handler.getPlayer()));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> GamblingManager.onDisconnect(handler.getPlayer()));

		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (entity instanceof ServerPlayerEntity player) {
				GamblingManager.onPlayerDeath(player);
				RunManager.onPlayerDeath(player, source);
			} else if (source.getAttacker() instanceof ServerPlayerEntity killer) {
				RunManager.onMobKilled(entity.getType(), killer);
			}
		});

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			if (!alive) {
				RunManager.onPlayerRespawn(newPlayer);
			}
		});

		ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
			if (destination.getRegistryKey() == World.NETHER) {
				RunManager.onEnteredNether(player);
			} else if (destination.getRegistryKey() == World.END) {
				RunManager.onEnteredEnd(player);
			}
		});

		// Right-clicking the Dealer's Deck opens the table; right-clicking Jester's Die rerolls the modifier.
		UseItemCallback.EVENT.register((player, world, hand) -> {
			if (!(player instanceof ServerPlayerEntity serverPlayer)) return ActionResult.PASS;
			ItemStack held = player.getStackInHand(hand);
			if (RogueliteItems.isDealersDeck(held)) {
				GamblingManager.open(serverPlayer);
				return ActionResult.SUCCESS;
			}
			if ("jesters_die".equals(RogueliteItems.relicId(held))) {
				return RunManager.useJestersDie(serverPlayer) ? ActionResult.SUCCESS : ActionResult.FAIL;
			}
			return ActionResult.PASS;
		});
	}
}

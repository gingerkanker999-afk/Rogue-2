package com.roguelite;

import com.roguelite.core.RunManager;
import com.roguelite.gambling.game.GamblingManager;
import com.roguelite.item.RogueliteItems;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.world.World;

/** Wires Fabric events to the Run Manager. Keep this file thin: decisions belong in RunManager. */
public final class RogueliteEvents {
	private RogueliteEvents() {}

	public static void register() {
		ServerLifecycleEvents.SERVER_STARTED.register(RunManager::onServerStarted);
		// Gambling must settle open rounds before the Run Manager forgets the run, so register it first.
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> GamblingManager.onServerStopping());
		ServerLifecycleEvents.SERVER_STOPPING.register(RunManager::onServerStopping);
		ServerTickEvents.END_SERVER_TICK.register(RunManager::onTick);
		ServerTickEvents.END_WORLD_TICK.register(RunManager::onWorldTick);

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> RunManager.onPlayerJoin(handler.getPlayer()));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> GamblingManager.onDisconnect(handler.getPlayer()));

		// Right-clicking the Dealer's Deck opens the table.
		UseItemCallback.EVENT.register((player, world, hand) -> {
			if (player instanceof ServerPlayerEntity serverPlayer && RogueliteItems.isDealersDeck(player.getStackInHand(hand))) {
				GamblingManager.open(serverPlayer);
				return ActionResult.SUCCESS;
			}
			return ActionResult.PASS;
		});

		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (entity instanceof ServerPlayerEntity player) {
				GamblingManager.onPlayerDeath(player);
				RunManager.onPlayerDeath(player, source);
			} else if (entity.getType() == EntityType.ENDER_DRAGON || entity.getType() == EntityType.WITHER) {
				RunManager.onBossKilled();
			}
		});

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			if (!alive) {
				RunManager.onPlayerRespawn(newPlayer);
			}
		});

		ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
			if (destination.getRegistryKey() == World.NETHER) {
				RunManager.onEnteredNether(player);
			}
		});
	}
}

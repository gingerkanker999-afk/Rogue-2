package com.roguelite;

import com.roguelite.core.RunManager;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.World;

/** Wires Fabric events to the Run Manager. Keep this file thin: decisions belong in RunManager. */
public final class RogueliteEvents {
	private RogueliteEvents() {}

	public static void register() {
		ServerLifecycleEvents.SERVER_STARTED.register(RunManager::onServerStarted);
		ServerLifecycleEvents.SERVER_STOPPING.register(RunManager::onServerStopping);
		ServerTickEvents.END_SERVER_TICK.register(RunManager::onTick);

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> RunManager.onPlayerJoin(handler.getPlayer()));

		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (entity instanceof ServerPlayerEntity player) {
				RunManager.onPlayerDeath(player, source);
			} else if (entity.getType() == EntityType.ENDER_DRAGON || entity.getType() == EntityType.WITHER) {
				RunManager.onBossKilled();
			}
		});

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			if (!alive) {
				RunManager.onPlayerRespawn(newPlayer);
			}
		});

		ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
			if (destination.getRegistryKey() == World.NETHER) {
				RunManager.onEnteredNether(player);
			}
		});
	}
}

package com.roguelite.economy;

import com.roguelite.profile.ProfileData;
import com.roguelite.profile.ProfileStore;

import java.io.IOException;
import java.nio.file.Path;
import com.roguelite.core.StashRules;
import java.util.HashMap;
import java.util.Map;
import java.util.OptionalLong;

/**
 * The meta currency rules. Every change is applied, saved, and rolled back in memory if the save fails,
 * so the in-memory balance never disagrees with the file.
 */
public final class MetaEconomy {
	/** A brand-new profile starts with exactly enough for one Barebones run. */
	public static final int STARTING_BALANCE = 5;

	public enum BankResult { BANKED, ALREADY_BANKED }

	private static ProfileStore store;

	private MetaEconomy() {}

	public static synchronized void init(Path profileFile) {
		store = new ProfileStore(profileFile);
		store.load(STARTING_BALANCE);
	}

	public static synchronized int balance() {
		return store.data().balance;
	}

	public static synchronized boolean canAfford(int cost) {
		return store.data().balance >= cost;
	}

	/**
	 * Atomically spends {@code cost} and allocates the next run id.
	 * @return the new run id, or empty if the balance is too low
	 * @throws IOException if the profile could not be saved (nothing is changed in that case)
	 */
	public static synchronized OptionalLong spendAndAllocateRunId(int cost) throws IOException {
		ProfileData d = store.data();
		if (cost < 0 || d.balance < cost) {
			return OptionalLong.empty();
		}
		d.balance -= cost;
		d.runIdCounter += 1;
		try {
			store.save();
		} catch (IOException e) {
			d.balance += cost;
			d.runIdCounter -= 1;
			throw e;
		}
		return OptionalLong.of(d.runIdCounter);
	}

	/** Gives money back (used only if a run could not be created after paying). */
	public static synchronized void refund(int amount) throws IOException {
		if (amount <= 0) return;
		ProfileData d = store.data();
		d.balance += amount;
		try {
			store.save();
		} catch (IOException e) {
			d.balance -= amount;
			throw e;
		}
	}

	/**
	 * Pays out a finished run's reward exactly once per run id.
	 * A second call for the same run id (e.g. a copied world) pays nothing and returns ALREADY_BANKED.
	 */
	public static synchronized BankResult bankRun(long runId, int amount) throws IOException {
		ProfileData d = store.data();
		if (d.bankedRunIds.contains(runId)) {
			return BankResult.ALREADY_BANKED;
		}
		int safeAmount = Math.max(0, amount);
		d.bankedRunIds.add(runId);
		d.balance += safeAmount;
		try {
			store.save();
		} catch (IOException e) {
			d.bankedRunIds.remove(runId);
			d.balance -= safeAmount;
			throw e;
		}
		return BankResult.BANKED;
	}

	/** The starter waiting to be started, or null. */
	public static synchronized String pendingStarter() {
		return store.data().pendingStarter;
	}

	/** Charges for a starter and parks it as pending. Only one starter can wait at a time. */
	public static synchronized boolean buyPending(String starterId, int cost) throws IOException {
		ProfileData d = store.data();
		if (d.pendingStarter != null || cost < 0 || d.balance < cost) return false;
		d.balance -= cost;
		d.pendingStarter = starterId;
		try {
			store.save();
		} catch (IOException e) {
			d.balance += cost;
			d.pendingStarter = null;
			throw e;
		}
		return true;
	}

	/** Takes the pending starter and allocates its run id in one save. Empty if nothing is pending. */
	public static synchronized OptionalLong consumePending() throws IOException {
		ProfileData d = store.data();
		if (d.pendingStarter == null) return OptionalLong.empty();
		String old = d.pendingStarter;
		d.pendingStarter = null;
		d.runIdCounter += 1;
		try {
			store.save();
		} catch (IOException e) {
			d.pendingStarter = old;
			d.runIdCounter -= 1;
			throw e;
		}
		return OptionalLong.of(d.runIdCounter);
	}

	/** Puts a starter back into the pending slot (used if a run could not be saved after taking it). */
	public static synchronized void restorePending(String starterId) throws IOException {
		ProfileData d = store.data();
		d.pendingStarter = starterId;
		store.save();
	}

	public static synchronized int stashUsed() {
		return store.data().stash.values().stream().mapToInt(Integer::intValue).sum();
	}

	public static synchronized int stashCapacity() {
		return StashRules.capacityItems(store.data().stashLevel);
	}

	/** Adds up to {@code amount} of an item to the stash. Returns how many actually fit. */
	public static synchronized int stashDeposit(String itemId, int amount) throws IOException {
		ProfileData d = store.data();
		int add = StashRules.depositAmount(stashUsed(), StashRules.capacityItems(d.stashLevel), amount);
		if (add <= 0) return 0;
		Integer previous = d.stash.get(itemId);
		d.stash.put(itemId, (previous == null ? 0 : previous) + add);
		try {
			store.save();
		} catch (IOException e) {
			if (previous == null) d.stash.remove(itemId); else d.stash.put(itemId, previous);
			throw e;
		}
		return add;
	}

	/** Empties the stash and returns what was in it. */
	public static synchronized Map<String, Integer> stashWithdrawAll() throws IOException {
		ProfileData d = store.data();
		if (d.stash.isEmpty()) return new HashMap<>();
		Map<String, Integer> taken = new HashMap<>(d.stash);
		d.stash.clear();
		try {
			store.save();
		} catch (IOException e) {
			d.stash.putAll(taken);
			throw e;
		}
		return taken;
	}

	/** Buys the next stash upgrade if the level allows and the balance covers it. */
	public static synchronized boolean buyStashUpgrade() throws IOException {
		ProfileData d = store.data();
		int cost = StashRules.upgradeCost(d.stashLevel);
		if (cost < 0 || d.balance < cost) return false;
		d.balance -= cost;
		d.stashLevel += 1;
		try {
			store.save();
		} catch (IOException e) {
			d.balance += cost;
			d.stashLevel -= 1;
			throw e;
		}
		return true;
	}

	/** Debug only: adds currency without touching banked run ids. */
	public static synchronized void debugGrant(int amount) throws IOException {
		ProfileData d = store.data();
		d.balance += amount;
		try {
			store.save();
		} catch (IOException e) {
			d.balance -= amount;
			throw e;
		}
	}
}

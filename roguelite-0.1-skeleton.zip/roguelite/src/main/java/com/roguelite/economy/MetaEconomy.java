package com.roguelite.economy;

import com.roguelite.profile.ProfileData;
import com.roguelite.profile.ProfileStore;

import java.io.IOException;
import java.nio.file.Path;
import java.util.OptionalLong;

/**
 * The meta currency rules. Every change is applied, saved, and rolled back in memory if the save fails,
 * so the in-memory balance never disagrees with the file.
 */
public final class MetaEconomy {
	/** A brand-new profile starts with exactly enough for one Barebones run. */
	public static final int STARTING_BALANCE = 5;

	public enum BankResult { BANKED, ALREADY_BANKED }

	private static ProfileStore store;

	private MetaEconomy() {}

	public static synchronized void init(Path profileFile) {
		store = new ProfileStore(profileFile);
		store.load(STARTING_BALANCE);
	}

	public static synchronized int balance() {
		return store.data().balance;
	}

	public static synchronized boolean canAfford(int cost) {
		return store.data().balance >= cost;
	}

	/**
	 * Atomically spends {@code cost} and allocates the next run id.
	 * @return the new run id, or empty if the balance is too low
	 * @throws IOException if the profile could not be saved (nothing is changed in that case)
	 */
	public static synchronized OptionalLong spendAndAllocateRunId(int cost) throws IOException {
		ProfileData d = store.data();
		if (cost < 0 || d.balance < cost) {
			return OptionalLong.empty();
		}
		d.balance -= cost;
		d.runIdCounter += 1;
		try {
			store.save();
		} catch (IOException e) {
			d.balance += cost;
			d.runIdCounter -= 1;
			throw e;
		}
		return OptionalLong.of(d.runIdCounter);
	}

	/** Gives money back (used only if a run could not be created after paying). */
	public static synchronized void refund(int amount) throws IOException {
		if (amount <= 0) return;
		ProfileData d = store.data();
		d.balance += amount;
		try {
			store.save();
		} catch (IOException e) {
			d.balance -= amount;
			throw e;
		}
	}

	/**
	 * Pays out a finished run's reward exactly once per run id.
	 * A second call for the same run id (e.g. a copied world) pays nothing and returns ALREADY_BANKED.
	 */
	public static synchronized BankResult bankRun(long runId, int amount) throws IOException {
		ProfileData d = store.data();
		if (d.bankedRunIds.contains(runId)) {
			return BankResult.ALREADY_BANKED;
		}
		int safeAmount = Math.max(0, amount);
		d.bankedRunIds.add(runId);
		d.balance += safeAmount;
		try {
			store.save();
		} catch (IOException e) {
			d.bankedRunIds.remove(runId);
			d.balance -= safeAmount;
			throw e;
		}
		return BankResult.BANKED;
	}

	/** Debug only: adds currency without touching banked run ids. */
	public static synchronized void debugGrant(int amount) throws IOException {
		ProfileData d = store.data();
		d.balance += amount;
		try {
			store.save();
		} catch (IOException e) {
			d.balance -= amount;
			throw e;
		}
	}
}

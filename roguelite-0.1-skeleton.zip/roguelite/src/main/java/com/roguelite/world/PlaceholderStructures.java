package com.roguelite.world;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

/**
 * Code-built placeholder layouts from vanilla blocks. Geometry only: no gameplay rules live here, so real NBT templates
 * can replace these methods later without touching the cache logic.
 * Coordinates are relative to a base position, which is the floor centre.
 */
public final class PlaceholderStructures {
	public record Layout(BlockPos mainChest, List<BlockPos> stationChests) {}

	private PlaceholderStructures() {}

	/** Sealed 7x7x5 deepslate room: central chest on the floor, four station chests in the corners. */
	public static Layout buildVault(World world, BlockPos base) {
		if (!clear(world, base, -3, 3, 0, 4, -3, 3)) return null;
		fill(world, base, -3, 3, 0, 0, -3, 3, Blocks.POLISHED_DEEPSLATE.getDefaultState());
		fill(world, base, -3, 3, 1, 4, -3, 3, Blocks.DEEPSLATE_BRICKS.getDefaultState());
		fill(world, base, -2, 2, 1, 3, -2, 2, Blocks.AIR.getDefaultState());

		BlockPos main = base.up();
		world.setBlockState(main, Blocks.CHEST.getDefaultState());
		List<BlockPos> stations = List.of(
			base.add(-2, 1, -2), base.add(2, 1, -2), base.add(-2, 1, 2), base.add(2, 1, 2));
		for (BlockPos station : stations) {
			world.setBlockState(station, Blocks.CHEST.getDefaultState());
		}
		return new Layout(main, stations);
	}

	/** Raised 5x5 stone-brick platform with corner pillars and one central chest. */
	public static Layout buildCache(World world, BlockPos base) {
		if (!clear(world, base, -2, 2, 0, 3, -2, 2)) return null;
		fill(world, base, -2, 2, 0, 0, -2, 2, Blocks.STONE_BRICKS.getDefaultState());
		fill(world, base, -2, 2, 1, 3, -2, 2, Blocks.AIR.getDefaultState());
		for (int dx = -2; dx <= 2; dx += 4) {
			for (int dz = -2; dz <= 2; dz += 4) {
				fill(world, base, dx, dx, 1, 2, dz, dz, Blocks.STONE_BRICK_WALL.getDefaultState());
			}
		}

		BlockPos main = base.up();
		world.setBlockState(main, Blocks.CHEST.getDefaultState());
		return new Layout(main, List.of());
	}

	/** True if the box holds no water or lava, so it is safe to build into. */
	private static boolean clear(World world, BlockPos base, int x1, int x2, int y1, int y2, int z1, int z2) {
		for (int x = x1; x <= x2; x++) {
			for (int y = y1; y <= y2; y++) {
				for (int z = z1; z <= z2; z++) {
					if (!world.getFluidState(base.add(x, y, z)).isEmpty()) return false;
				}
			}
		}
		return true;
	}

	private static void fill(World world, BlockPos base, int x1, int x2, int y1, int y2, int z1, int z2, BlockState state) {
		for (int x = x1; x <= x2; x++) {
			for (int y = y1; y <= y2; y++) {
				for (int z = z1; z <= z2; z++) {
					world.setBlockState(base.add(x, y, z), state);
				}
			}
		}
	}
}

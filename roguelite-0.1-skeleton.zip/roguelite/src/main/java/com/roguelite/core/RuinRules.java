package com.roguelite.core;

import java.util.List;

/** Looks up which ruin, if any, a point is inside. Pure Java. */
public final class RuinRules {
	private RuinRules() {}

	/** The first ruin containing this point, or null if the point is clear of all ruins. */
	public static Ruin ruinAt(List<Ruin> ruins, double x, double z) {
		for (Ruin ruin : ruins) {
			if (ruin.contains(x, z)) return ruin;
		}
		return null;
	}
}

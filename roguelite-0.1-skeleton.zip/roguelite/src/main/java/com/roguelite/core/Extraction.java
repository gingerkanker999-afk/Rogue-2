package com.roguelite.core;

import com.roguelite.item.RogueliteItems;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Extraction shrines: a placeholder shrine (a lodestone on a polished deepslate plinth) that ends your run safely.
 * Right-click starts an emergency channel (banks 50%); shift + right-click starts a full channel (banks 100%).
 * Taking damage cancels any channel, and a full channel also cancels if you move. The server does everything;
 * the client only sends the click.
 */
public final class Extraction {
	private static final Map<UUID, Channel> CHANNELS = new HashMap<>();

	private static final class Channel {
		final ExtractionRules.Mode mode;
		final long startTick;
		final double x;
		final double z;
		float lastHealth;

		Channel(ExtractionRules.Mode mode, long startTick, double x, double z, float health) {
			this.mode = mode;
			this.startTick = startTick;
			this.x = x;
			this.z = z;
			this.lastHealth = health;
		}
	}

	private Extraction() {}

	static String key(BlockPos pos) {
		return pos.getX() + "," + pos.getY() + "," + pos.getZ();
	}

	/** True if this block is a shrine belonging to the player's active run. */
	public static boolean isOwnedShrine(ServerPlayerEntity player, BlockPos pos) {
		RunState run = RunManager.activeRun();
		return run != null && RunManager.isOwner(player) && run.shrines.contains(key(pos));
	}

	/** Starts a channel. Each player can only have one. Called by the server after a shrine click. */
	public static void onShrineUse(ServerPlayerEntity player) {
		if (RunManager.activeRun() == null || !RunManager.isOwner(player)) return;
		if (CHANNELS.containsKey(player.getUuid())) {
			player.sendMessage(Text.literal("Already extracting. Stay still.").formatted(Formatting.YELLOW), true);
			return;
		}
		ExtractionRules.Mode mode = player.isSneaking() ? ExtractionRules.Mode.FULL : ExtractionRules.Mode.EMERGENCY;
		long now = player.getServerWorld().getTime();
		CHANNELS.put(player.getUuid(), new Channel(mode, now, player.getX(), player.getZ(), player.getHealth()));
		player.sendMessage(Text.literal(describe(mode)).formatted(Formatting.GOLD), false);
	}

	private static String describe(ExtractionRules.Mode mode) {
		return switch (mode) {
			case EMERGENCY -> "Emergency extraction: bank " + mode.percent + "% of your run score after "
				+ mode.channelTicks / 20 + " seconds. Taking damage cancels it. Shift + right-click for full extraction.";
			case FULL -> "Full extraction: bank " + mode.percent + "% of your run score after "
				+ mode.channelTicks / 20 + " seconds. Taking damage or moving cancels it.";
		};
	}

	/** Advances all channels. Runs once per server tick. */
	public static void tick(MinecraftServer server) {
		if (CHANNELS.isEmpty()) return;
		Iterator<Map.Entry<UUID, Channel>> it = CHANNELS.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, Channel> entry = it.next();
			Channel channel = entry.getValue();
			ServerPlayerEntity player = server.getPlayerManager().getPlayer(entry.getKey());
			if (player == null || RunManager.activeRun() == null || !RunManager.isOwner(player)) {
				it.remove();
				continue;
			}

			double moved = Math.hypot(player.getX() - channel.x, player.getZ() - channel.z);
			boolean hurt = player.getHealth() < channel.lastHealth;
			if (ExtractionRules.shouldCancel(channel.mode, moved, hurt)) {
				it.remove();
				player.sendMessage(Text.literal("Extraction cancelled.").formatted(Formatting.RED), true);
				continue;
			}
			channel.lastHealth = player.getHealth();

			long elapsed = player.getServerWorld().getTime() - channel.startTick;
			if (elapsed >= channel.mode.channelTicks) {
				it.remove();
				RunManager.extract(player, channel.mode);
			} else if (elapsed % 20 == 0) {
				long secondsLeft = (channel.mode.channelTicks - elapsed + 19) / 20;
				player.sendMessage(Text.literal("Extracting... " + secondsLeft + "s").formatted(Formatting.GOLD), true);
			}
		}
	}

	/**
	 * Builds a placeholder shrine four blocks in front of the player: a 3x3 polished deepslate plinth, a lodestone at the
	 * centre, and corner pillars. It clears two blocks of headroom and refuses to build into water or lava.
	 * Returns a message for the player.
	 */
	public static String placeShrine(ServerPlayerEntity player) {
		RunState run = RunManager.activeRun();
		if (run == null || !RunManager.isOwner(player)) return "Start a run first.";

		ServerWorld world = player.getServerWorld();
		BlockPos center = player.getBlockPos().offset(player.getHorizontalFacing(), 4);
		BlockPos base = center.down();

		if (run.shrines.contains(key(center)) || world.getBlockState(center).isOf(Blocks.LODESTONE)) {
			return "There is already a shrine there.";
		}
		for (int dx = -1; dx <= 1; dx++) {
			for (int dz = -1; dz <= 1; dz++) {
				BlockPos p = base.add(dx, 0, dz);
				if (!world.getFluidState(p).isEmpty() || !world.getFluidState(p.up()).isEmpty()) {
					return "Not placed: water or lava is in the way.";
				}
			}
		}

		for (int dx = -1; dx <= 1; dx++) {
			for (int dz = -1; dz <= 1; dz++) {
				world.setBlockState(base.add(dx, 0, dz), Blocks.POLISHED_DEEPSLATE.getDefaultState());
				world.setBlockState(base.add(dx, 1, dz), Blocks.AIR.getDefaultState());
				world.setBlockState(base.add(dx, 2, dz), Blocks.AIR.getDefaultState());
			}
		}
		for (int dx = -1; dx <= 1; dx += 2) {
			for (int dz = -1; dz <= 1; dz += 2) {
				world.setBlockState(base.add(dx, 1, dz), Blocks.POLISHED_DEEPSLATE_WALL.getDefaultState());
			}
		}
		world.setBlockState(center, Blocks.LODESTONE.getDefaultState());

		run.shrines.add(key(center));
		RunManager.saveRun();
		return "Shrine placed at " + key(center) + ".";
	}
}

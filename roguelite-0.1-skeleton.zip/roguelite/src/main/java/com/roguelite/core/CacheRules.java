package com.roguelite.core;

/**
 * Cache kinds and the ids that connect them to loot tables and rewards. Pure Java, unit-tested.
 * Loot contents live in data/roguelite/loot_table/*.json, so balance is a JSON edit, not a code change.
 */
public final class CacheRules {
	public enum Kind {
		/** Underground sealed room: central cache plus four station chests. */
		VAULT("vault", "roguelite:vault", "vault_opened"),
		/** Raised stone platform on a mountain: one central cache. */
		CACHE("cache", "roguelite:cache", "cache_opened");

		public final String id;
		public final String lootTable;
		public final String rewardId;

		Kind(String id, String lootTable, String rewardId) {
			this.id = id;
			this.lootTable = lootTable;
			this.rewardId = rewardId;
		}

		public static Kind fromId(String id) {
			for (Kind kind : values()) {
				if (kind.id.equals(id)) return kind;
			}
			return null;
		}
	}

	/** Loot for the smaller station chests inside a vault. */
	public static final String STATION_LOOT = "roguelite:station";

	private CacheRules() {}

	/** Run-state entry for a cache: "kind@x,y,z". */
	public static String entry(Kind kind, String key) {
		return kind.id + "@" + key;
	}

	/** The kind encoded in an entry, or null if it is malformed. */
	public static Kind kindOf(String entry) {
		int at = entry.indexOf('@');
		return at < 0 ? null : Kind.fromId(entry.substring(0, at));
	}
}

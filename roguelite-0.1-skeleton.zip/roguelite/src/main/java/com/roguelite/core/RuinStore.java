package com.roguelite.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Ruins saved in a world's roguelite folder. They persist across sessions and never expire on their own. */
public final class RuinStore {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private RuinStore() {}

	/** JSON shape: plain fields so the format is easy to read and edit by hand. */
	public static final class Entry {
		public long runId;
		public int x;
		public int z;
	}

	private static final class File {
		public List<Entry> ruins = new ArrayList<>();
	}

	public static List<Ruin> load(Path file) {
		List<Ruin> out = new ArrayList<>();
		if (!Files.isRegularFile(file)) return out;
		try {
			File data = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), File.class);
			if (data != null && data.ruins != null) {
				for (Entry e : data.ruins) out.add(new Ruin(e.runId, e.x, e.z));
			}
		} catch (Exception e) {
			// An unreadable ruin file is treated as empty; it is never overwritten until a new ruin is added.
			return out;
		}
		return out;
	}

	/** Adds a ruin and rewrites the file atomically. Ruins are only ever added, never removed here. */
	public static void add(Path file, Ruin ruin) throws IOException {
		File data = new File();
		for (Ruin r : load(file)) {
			Entry e = new Entry();
			e.runId = r.runId();
			e.x = r.centreX();
			e.z = r.centreZ();
			data.ruins.add(e);
		}
		Entry added = new Entry();
		added.runId = ruin.runId();
		added.x = ruin.centreX();
		added.z = ruin.centreZ();
		data.ruins.add(added);
		Files.createDirectories(file.getParent());
		Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
		Files.writeString(tmp, GSON.toJson(data), StandardCharsets.UTF_8);
		Files.move(tmp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
	}
}

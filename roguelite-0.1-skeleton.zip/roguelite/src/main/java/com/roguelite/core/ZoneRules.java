package com.roguelite.core;

/**
 * Run zones in the shared world. The hub (outpost) sits at the origin; run N starts at X = N x SPACING.
 * Spacing is far larger than a ruin's radius, so one ruin never touches another run's zone. Pure Java.
 */
public final class ZoneRules {
	public static final int SPACING = 20_000;

	private ZoneRules() {}

	public static int centreX(long runId) {
		return (int) (runId * SPACING);
	}

	public static int centreZ(long runId) {
		return 0;
	}
}

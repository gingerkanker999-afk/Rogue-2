package com.roguelite.core;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.WorldSavePath;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Applies blight to players inside ruins: magic damage on a timer, and healing reverted while inside.
 * Ruins are reloaded from the world's file every 10 seconds, so new ruins appear without a restart.
 */
public final class Blight {
	private static final int RELOAD_TICKS = 200;
	private static final BlightTracker TRACKER = new BlightTracker();
	private static List<Ruin> ruins = new ArrayList<>();

	private Blight() {}

	public static void tick(MinecraftServer server) {
		if (server.getTicks() % RELOAD_TICKS == 0) {
			ruins = RuinStore.load(ruinFile(server));
		}
		if (ruins.isEmpty()) return;

		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			if (player.isSpectator() || player.isCreative()) continue;
			boolean inside = RuinRules.ruinAt(ruins, player.getX(), player.getZ()) != null;
			BlightTracker.Step step = TRACKER.step(player.getUuidAsString(), inside, player.getHealth());
			if (step.restoreTo() >= 0) {
				player.setHealth((float) step.restoreTo());
			}
			if (step.damage() > 0) {
				player.damage(server.getOverworld(),
					server.getOverworld().getDamageSources().magic(), step.damage());
			}
		}
	}

	private static Path ruinFile(MinecraftServer server) {
		return server.getSavePath(WorldSavePath.ROOT).resolve("roguelite").resolve("ruins-v2.json");
	}
}

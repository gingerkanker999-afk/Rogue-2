package com.roguelite.core;

import com.roguelite.world.PlaceholderStructures;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Places development caches and pays the first open of each one. The chest's loot comes from a vanilla loot table,
 * which Minecraft fills once on first open and then keeps, so reopening or reloading cannot duplicate items.
 * The reward is recorded per run, so re-clicking an opened cache pays nothing.
 */
public final class Caches {
	private Caches() {}

	/** Development command: builds a cache in front of the player. */
	public static String place(ServerPlayerEntity player, World world, CacheRules.Kind kind) {
		RunState run = RunManager.activeRun();
		if (run == null || !RunManager.isOwner(player)) return "Start a run first.";

		BlockPos base = player.getBlockPos().offset(player.getHorizontalFacing(), 6).down();
		PlaceholderStructures.Layout layout = kind == CacheRules.Kind.VAULT
			? PlaceholderStructures.buildVault(world, base)
			: PlaceholderStructures.buildCache(world, base);
		if (layout == null) return "Not placed: water or lava is in the way.";

		setLoot(world, layout.mainChest(), kind.lootTable);
		for (BlockPos station : layout.stationChests()) {
			setLoot(world, station, CacheRules.STATION_LOOT);
		}
		String key = Extraction.key(layout.mainChest());
		run.caches.add(CacheRules.entry(kind, key));
		RunManager.saveRun();
		return kind.id + " placed at " + key + ".";
	}

	/** Called on every block right-click. Pays the first open of an owned cache; the chest itself opens normally. */
	public static void onInteract(ServerPlayerEntity player, BlockPos pos) {
		RunState run = RunManager.activeRun();
		if (run == null || !RunManager.isOwner(player)) return;

		String suffix = "@" + Extraction.key(pos);
		for (String entry : run.caches) {
			if (!entry.endsWith(suffix)) continue;
			if (run.openedCaches.contains(entry)) return;
			CacheRules.Kind kind = CacheRules.kindOf(entry);
			if (kind == null) return;
			run.openedCaches.add(entry);
			RunManager.award(kind.rewardId);
			return;
		}
	}

	private static void setLoot(World world, BlockPos pos, String lootId) {
		BlockEntity entity = world.getBlockEntity(pos);
		if (entity instanceof LootableContainerBlockEntity lootable) {
			Identifier id = Identifier.of(lootId);
			lootable.setLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, id), pos.asLong());
		}
	}
}

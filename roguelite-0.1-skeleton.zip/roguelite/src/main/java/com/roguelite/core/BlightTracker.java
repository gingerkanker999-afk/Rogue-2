package com.roguelite.core;

import java.util.HashMap;
import java.util.Map;

/**
 * Per-player blight state. Each tick, tell it whether the player is inside a ruin and how much health they have.
 * It returns how much blight damage to apply, and whether healing should be undone this tick. Leaving a ruin resets
 * the exposure timer. Pure Java, so the rules are unit-tested without Minecraft.
 */
public final class BlightTracker {
	/** Damage to apply this tick, and the health to restore to (negative means no restore). */
	public record Step(int damage, double restoreTo) {}

	private static final class State {
		long exposureTicks;
		int dealt;
		double baseline;
	}

	private final Map<String, State> states = new HashMap<>();

	public Step step(String playerKey, boolean inRuin, double health) {
		if (!inRuin) {
			states.remove(playerKey);
			return new Step(0, -1);
		}
		State s = states.computeIfAbsent(playerKey, k -> {
			State fresh = new State();
			fresh.baseline = health;
			return fresh;
		});

		// Damage from anything else lowers the baseline, so it isn't counted twice.
		s.baseline = Math.min(s.baseline, health);
		double before = s.baseline;
		double restore = health > before ? before : -1;

		s.exposureTicks++;
		int target = BlightRules.healthLostAfter(s.exposureTicks);
		int newDamage = target - s.dealt;
		s.dealt = target;
		s.baseline = before - newDamage;
		return new Step(newDamage, restore);
	}
}

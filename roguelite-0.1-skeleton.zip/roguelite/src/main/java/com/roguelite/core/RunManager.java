package com.roguelite.core;

import com.roguelite.Roguelite;
import com.roguelite.economy.MetaEconomy;
import com.roguelite.effect.RunEffect;
import com.roguelite.item.RogueliteItems;
import com.roguelite.modifier.ModifierDef;
import com.roguelite.modifier.ModifierRegistry;
import com.roguelite.net.OpenStarterScreenPayload;
import com.roguelite.net.RunSummaryPayload;
import com.roguelite.relic.RelicDef;
import com.roguelite.relic.RelicInstance;
import com.roguelite.relic.RelicRegistry;
import com.roguelite.reward.RewardCalculator;
import com.roguelite.reward.RewardDef;
import com.roguelite.reward.RewardTable;
import com.roguelite.starter.StarterDef;
import com.roguelite.starter.StarterRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.OptionalLong;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Owns the run lifecycle for the currently loaded world:
 * NO RUN -> (buy starter) -> ACTIVE -> (owner dies) -> ENDED.
 *
 * All methods must be called on the server thread. Modifier/relic gameplay is NOT here: effects plug in
 * through {@link RunEffect} and read {@link #activeRun()} / {@link #activeEffects()}.
 */
public final class RunManager {
	/** Ticks to wait after join/respawn before opening a screen, so it is not wiped by the terrain-loading screen. */
	private static final int SCREEN_DELAY_TICKS = 30;
	private static final int DIAMOND_CHECK_INTERVAL = 40;

	private enum ScreenKind { STARTER, SUMMARY }

	private static final class Pending {
		final ScreenKind kind;
		int ticksLeft;

		Pending(ScreenKind kind, int ticksLeft) {
			this.kind = kind;
			this.ticksLeft = ticksLeft;
		}
	}

	private static MinecraftServer server;
	private static RunState run;
	private static Path runFile;
	private static final Map<UUID, Pending> PENDING = new HashMap<>();

	private RunManager() {}

	// ---------------------------------------------------------------- lifecycle of the loaded world

	public static void onServerStarted(MinecraftServer s) {
		server = s;
		runFile = s.getSavePath(WorldSavePath.ROOT).resolve("roguelite").resolve("run.json").normalize();
		run = WorldRunStore.load(runFile);
		PENDING.clear();
		Roguelite.LOGGER.info("World run state: {}", run == null ? "no run yet" : "run #" + run.runId + " (" + run.status + ")");
	}

	public static void onServerStopping(MinecraftServer s) {
		if (run != null) {
			save();
		}
		run = null;
		server = null;
		runFile = null;
		PENDING.clear();
	}

	// ---------------------------------------------------------------- queries

	/** The run if one exists in this world (active or ended), else null. */
	public static RunState currentRun() {
		return run;
	}

	/** The run only if it is currently ACTIVE, else null. Effect hooks should use this. */
	public static RunState activeRun() {
		return run != null && run.isActive() ? run : null;
	}

	/** The effects (modifier + relics) of the active run. Empty if no run is active. */
	public static List<RunEffect> activeEffects() {
		List<RunEffect> effects = new ArrayList<>();
		if (activeRun() == null) return effects;
		if (run.modifierId != null) {
			effects.add(ModifierRegistry.effectFor(run.modifierId));
		}
		for (RelicInstance relic : run.relics) {
			effects.add(RelicRegistry.effectFor(relic.relicId));
		}
		return effects;
	}

	public static boolean isOwner(ServerPlayerEntity player) {
		return run != null && run.ownerUuid != null && run.ownerUuid.equals(player.getUuidAsString());
	}

	public static List<String> statusLines() {
		List<String> lines = new ArrayList<>();
		String sym = Roguelite.CURRENCY_SYMBOL;
		lines.add("Meta balance: " + MetaEconomy.balance() + " " + sym);
		if (run == null) {
			lines.add("This world has no run yet. Type /roguelite start.");
			return lines;
		}
		StarterDef starter = StarterRegistry.get(run.starterId);
		ModifierDef mod = ModifierRegistry.get(run.modifierId);
		lines.add(String.format("Run #%06d - %s", run.runId, run.status));
		lines.add("Starter: " + (starter != null ? starter.name : run.starterId) + "  Luck: " + run.luck);
		lines.add("Modifier: " + (mod != null ? mod.name : "none"));
		List<String> relicNames = new ArrayList<>();
		for (RelicInstance r : run.relics) {
			RelicDef def = RelicRegistry.get(r.relicId);
			relicNames.add(def != null ? def.name : r.relicId);
		}
		lines.add("Relics: " + (relicNames.isEmpty() ? "none" : String.join(", ", relicNames)));
		if (run.balanceBeforeRun >= 0) {
			lines.add("Balance before this run: " + run.balanceBeforeRun + " " + sym
				+ (run.starterCost >= 0 ? "  (starter cost " + run.starterCost + ")" : ""));
		}

		List<RunState.RewardLine> rewardLines;
		int total;
		if (run.isActive() && server != null) {
			RewardCalculator.Result preview = RewardCalculator.preview(run, server.getOverworld().getTime());
			rewardLines = preview.lines();
			total = preview.total();
			lines.add("Run score so far: " + total + " " + sym + " (paid when the run ends)");
		} else {
			rewardLines = run.rewardLines;
			total = run.rewardTotal;
			lines.add("Ended: " + run.endReason);
			lines.add("Run score: " + total + " " + sym + " (paid " + run.rewardPaid + ")");
		}
		for (RunState.RewardLine line : rewardLines) {
			lines.add("  +" + line.points + " " + sym + "  " + line.label);
		}
		return lines;
	}

	// ---------------------------------------------------------------- player events

	public static void onPlayerJoin(ServerPlayerEntity player) {
		if (server == null) return;
		if (run == null) {
			queue(player, ScreenKind.STARTER);
			return;
		}
		if (!isOwner(player)) return;

		refreshRelicItems(player);

		if (run.isActive()) {
			activateEffects(player);
		} else {
			retryBank();
			player.changeGameMode(GameMode.SPECTATOR);
			queue(player, ScreenKind.SUMMARY);
		}
	}

	public static void onPlayerRespawn(ServerPlayerEntity player) {
		if (run != null && !run.isActive() && isOwner(player)) {
			player.changeGameMode(GameMode.SPECTATOR);
			queue(player, ScreenKind.SUMMARY);
		}
	}

	/** Vanilla death happens first; this only runs afterwards and decides what it means for the run. */
	public static void onPlayerDeath(ServerPlayerEntity player, DamageSource source) {
		if (run == null || !run.isActive() || !isOwner(player)) return;
		run.deaths++;
		String reason;
		try {
			reason = source.getDeathMessage(player).getString();
		} catch (Exception e) {
			reason = "Died";
		}
		finishRun(player, reason);
	}

	public static void onBossKilled() {
		award("kill_boss");
	}

	public static void onEnteredNether(ServerPlayerEntity player) {
		if (run != null && run.isActive() && isOwner(player)) {
			award("enter_nether");
		}
	}

	/** Gives every active effect its per-tick hook, for the run owner only, in the world they are standing in. */
	public static void onWorldTick(ServerWorld world) {
		if (run == null || !run.isActive()) return;
		for (ServerPlayerEntity player : world.getPlayers()) {
			if (!isOwner(player)) continue;
			for (RunEffect effect : activeEffects()) {
				effect.onPlayerTick(player, run, world);
			}
		}
	}

	public static void onTick(MinecraftServer s) {
		tickObjectives(s);
		if (!PENDING.isEmpty()) {
			Iterator<Map.Entry<UUID, Pending>> it = PENDING.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<UUID, Pending> entry = it.next();
				Pending pending = entry.getValue();
				pending.ticksLeft--;
				if (pending.ticksLeft <= 0) {
					it.remove();
					ServerPlayerEntity player = s.getPlayerManager().getPlayer(entry.getKey());
					if (player != null) {
						sendScreen(player, pending.kind);
					}
				}
			}
		}

		if (run != null && run.isActive() && s.getTicks() % DIAMOND_CHECK_INTERVAL == 0
			&& !run.achievements.contains("find_diamond")) {
			ServerPlayerEntity owner = findOwner();
			if (owner != null && owner.getInventory().count(Items.DIAMOND) > 0) {
				award("find_diamond");
			}
		}
	}

	// ---------------------------------------------------------------- starting a run

	/**
	 * What a starter really costs right now. Safety net so nobody is ever locked out of playing: if you cannot afford
	 * even the cheapest starter, the cheapest one is free.
	 */
	public static int effectiveCost(StarterDef def) {
		if (def == StarterRegistry.cheapest() && MetaEconomy.balance() < def.cost) {
			return 0;
		}
		return def.cost;
	}

	/** Opens the starter screen right now (used by /roguelite start when the player closed it). */
	public static boolean openStarterScreen(ServerPlayerEntity player) {
		if (server == null || run != null) return false;
		sendScreen(player, ScreenKind.STARTER);
		return true;
	}

	/** Validates a start request, charges the profile, creates the run, hands out the kit. */
	public static StartResult startRun(ServerPlayerEntity player, String starterId) {
		if (server == null) {
			return StartResult.fail("The server is not ready.");
		}
		if (run != null) {
			return StartResult.fail("This world already has a run.");
		}
		StarterDef def = StarterRegistry.get(starterId);
		if (def == null) {
			return StartResult.fail("Unknown starter.");
		}

		int cost = effectiveCost(def);
		boolean charity = cost == 0 && def.cost > 0;

		int balanceBefore = MetaEconomy.balance();

		OptionalLong runId;
		try {
			runId = MetaEconomy.spendAndAllocateRunId(cost);
		} catch (IOException e) {
			Roguelite.LOGGER.error("Could not save profile while starting a run", e);
			return StartResult.fail("Could not save your profile. Nothing was spent.");
		}
		if (runId.isEmpty()) {
			return StartResult.fail("Not enough " + Roguelite.CURRENCY_SYMBOL + " for " + def.name + ".");
		}

		Random random = new Random();
		RunState state = new RunState();
		state.runId = runId.getAsLong();
		state.status = RunStatus.ACTIVE;
		state.ownerUuid = player.getUuidAsString();
		state.starterId = def.id;
		state.luck = def.luck;
		state.balanceBeforeRun = balanceBefore;
		state.starterCost = cost;
		state.startTick = server.getOverworld().getTime();
		BlockPos pos = player.getBlockPos();
		state.startX = pos.getX();
		state.startY = pos.getY();
		state.startZ = pos.getZ();

		ModifierDef modifier = ModifierRegistry.roll(def.modifierPool, random);
		if (modifier != null) {
			state.modifierId = modifier.id;
		} else {
			Roguelite.LOGGER.warn("Starter '{}' rolled no modifier (pool '{}' is empty)", def.id, def.modifierPool);
		}

		Set<String> owned = new HashSet<>();
		for (int i = 0; i < def.randomRelics; i++) {
			RelicDef relic = RelicRegistry.rollOne(random, owned);
			if (relic == null) break;
			owned.add(relic.id);
			state.relics.add(new RelicInstance(UUID.randomUUID().toString(), relic.id));
		}

		try {
			WorldRunStore.save(runFile, state);
		} catch (IOException e) {
			Roguelite.LOGGER.error("Could not save the run file; refunding", e);
			try {
				MetaEconomy.refund(cost);
			} catch (IOException refundError) {
				Roguelite.LOGGER.error("Refund also failed", refundError);
			}
			return StartResult.fail("Could not save the run to this world. You were refunded.");
		}

		run = state;
		giveKit(player, def);
		refreshRelicItems(player);
		activateEffects(player);
		if (charity) {
			player.sendMessage(Text.literal(def.name + " is on the house because you could not afford a starter.")
				.formatted(Formatting.GRAY), false);
		}
		announce(player, def, modifier);
		return StartResult.success();
	}

	private static void giveKit(ServerPlayerEntity player, StarterDef def) {
		for (StarterDef.KitItem kit : def.items) {
			ItemStack stack = RogueliteItems.create(kit.item, kit.count);
			if (!stack.isEmpty()) {
				player.getInventory().offerOrDrop(stack);
			}
		}
	}

	private static void announce(ServerPlayerEntity player, StarterDef def, ModifierDef modifier) {
		player.sendMessage(Text.literal(String.format("Run #%06d started: %s", run.runId, def.name)).formatted(Formatting.GOLD), false);
		if (modifier != null) {
			player.sendMessage(Text.literal("Modifier: " + modifier.name + " - " + modifier.description).formatted(Formatting.YELLOW), false);
		}
		for (RelicInstance r : run.relics) {
			RelicDef relic = RelicRegistry.get(r.relicId);
			if (relic != null) {
				player.sendMessage(Text.literal("Relic: " + relic.name + " - " + relic.description).formatted(Formatting.AQUA), false);
			}
		}
	}

	// ---------------------------------------------------------------- relics and rewards

	/**
	 * Gives the run a relic. {@code found} is true for relics obtained during play (pays the "relic found" reward)
	 * and false for starter grants.
	 */
	public static boolean grantRelic(ServerPlayerEntity player, String relicId, boolean found) {
		if (run == null || !run.isActive()) return false;
		RelicDef def = RelicRegistry.get(relicId);
		if (def == null) return false;
		run.relics.add(new RelicInstance(UUID.randomUUID().toString(), relicId));
		RelicRegistry.effectFor(relicId).onActivate(player, run);
		refreshRelicItems(player);
		save();
		if (found) {
			award("find_relic");
		}
		return true;
	}

	/** Records a reward event (achievement or counter tick) for the active run. */
	public static void award(String rewardId) {
		if (run == null || !run.isActive()) return;
		RewardDef def = RewardTable.get(rewardId);
		if (def == null) {
			Roguelite.LOGGER.warn("Unknown reward id '{}'", rewardId);
			return;
		}
		boolean granted;
		if (def.repeatable) {
			run.addCounter(rewardId, 1);
			granted = true;
		} else {
			granted = run.achievements.add(rewardId);
		}
		if (!granted) return;
		save();
		ServerPlayerEntity owner = findOwner();
		if (owner != null) {
			Text message = Text.literal("+" + def.points + " " + Roguelite.CURRENCY_SYMBOL + "  " + def.label
				+ "  (paid when the run ends)").formatted(Formatting.GREEN, Formatting.BOLD);
			owner.sendMessage(message, false);
			owner.sendMessage(message, true);
			owner.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 1.4f);
		}
	}

	// ---------------------------------------------------------------- ending a run

	// ---------------------------------------------------------------- objectives

	private static final int OBJECTIVE_CHECK_INTERVAL = 40;
	private static final int DEEP_Y = -40;
	private static final int HIGH_Y = 200;
	private static final Map<String, Item> ITEM_OBJECTIVES = Map.of(
		"find_iron", Items.IRON_INGOT,
		"find_emerald", Items.EMERALD,
		"find_netherite", Items.NETHERITE_INGOT);

	private static void tickObjectives(MinecraftServer s) {
		if (run == null || !run.isActive() || s.getTicks() % OBJECTIVE_CHECK_INTERVAL != 0) return;
		ServerPlayerEntity owner = findOwner();
		if (owner != null) checkObjectives(owner);
	}

	private static void checkObjectives(ServerPlayerEntity owner) {
		for (Map.Entry<String, Item> entry : ITEM_OBJECTIVES.entrySet()) {
			if (owner.getInventory().count(entry.getValue()) > 0) award(entry.getKey());
		}
		int y = owner.getBlockY();
		if (y <= DEEP_Y) award("reach_deep");
		if (y >= HIGH_Y) award("reach_high");
	}

	/** Mob kills by the run owner. Each boss and rare mob pays once per run, so respawning a boss does not farm it. */
	public static void onMobKilled(EntityType<?> type, ServerPlayerEntity killer) {
		if (run == null || !run.isActive() || !isOwner(killer)) return;
		if (type == EntityType.ENDER_DRAGON || type == EntityType.WITHER) {
			award("kill_boss");
		} else if (type == EntityType.WARDEN) {
			award("kill_warden");
		} else if (type == EntityType.ELDER_GUARDIAN) {
			award("kill_elder_guardian");
		}
	}

	public static void onEnteredEnd(ServerPlayerEntity player) {
		if (run != null && run.isActive() && isOwner(player)) {
			award("enter_end");
		}
	}

	/**
	 * Jester's Die: once per run, reroll the active modifier within the starter's pool (never the same one),
	 * then consume the die. Returns false if there is no die, no run, or nothing new to roll.
	 */
	public static boolean useJestersDie(ServerPlayerEntity player) {
		if (run == null || !run.isActive() || !isOwner(player)) return false;
		RelicInstance die = null;
		for (RelicInstance r : run.relics) {
			if ("jesters_die".equals(r.relicId)) {
				die = r;
				break;
			}
		}
		if (die == null) return false;

		StarterDef starter = StarterRegistry.get(run.starterId);
		String pool = starter != null ? starter.modifierPool : null;
		List<ModifierDef> options = new ArrayList<>();
		for (ModifierDef m : ModifierRegistry.all()) {
			if (pool != null && pool.equals(m.category) && !m.id.equals(run.modifierId)) options.add(m);
		}
		if (options.isEmpty()) {
			player.sendMessage(Text.literal("The die finds nothing new to roll.").formatted(Formatting.RED), false);
			return false;
		}

		ModifierDef next = options.get(new Random().nextInt(options.size()));
		ModifierRegistry.effectFor(run.modifierId).onDeactivate(player, run);
		run.modifierId = next.id;
		ModifierRegistry.effectFor(next.id).onActivate(player, run);
		run.relics.remove(die);
		refreshRelicItems(player);
		save();
		player.sendMessage(Text.literal("Jester's Die: new modifier - " + next.name + " (" + next.description + ")")
			.formatted(Formatting.YELLOW), false);
		return true;
	}

	/** Debug helper: swaps the run's modifier, switching the old effect off and the new one on. */
	public static boolean debugSetModifier(ServerPlayerEntity player, String modifierId) {
		if (run == null || !run.isActive() || !isOwner(player)) return false;
		if (ModifierRegistry.get(modifierId) == null) return false;
		ModifierRegistry.effectFor(run.modifierId).onDeactivate(player, run);
		run.modifierId = modifierId;
		ModifierRegistry.effectFor(modifierId).onActivate(player, run);
		save();
		return true;
	}

	/** Debug helper: ends the run as if the owner died, without killing the player. */
	public static boolean debugEndRun(ServerPlayerEntity player) {
		if (run == null || !run.isActive() || !isOwner(player)) return false;
		finishRun(player, "Ended by debug command");
		player.changeGameMode(GameMode.SPECTATOR);
		queue(player, ScreenKind.SUMMARY);
		return true;
	}

	private static void finishRun(ServerPlayerEntity player, String reason) {
		deactivateEffects(player);
		run.status = RunStatus.ENDED;
		refreshRelicItems(player);
		run.endTick = server.getOverworld().getTime();
		run.endReason = reason;
		RewardCalculator.calculate(run, run.endTick);
		bankReward();
		save();
	}

	/** Pays the reward once. If the profile cannot be saved, rewardBanked stays false and it is retried on next join. */
	private static void bankReward() {
		if (run.rewardBanked) return;
		try {
			MetaEconomy.BankResult result = MetaEconomy.bankRun(run.runId, run.rewardTotal);
			run.rewardBanked = true;
			run.rewardPaid = result == MetaEconomy.BankResult.BANKED ? run.rewardTotal : 0;
			if (result == MetaEconomy.BankResult.ALREADY_BANKED) {
				Roguelite.LOGGER.warn("Run #{} was already banked in this profile (copied world?) - nothing paid", run.runId);
			}
		} catch (IOException e) {
			Roguelite.LOGGER.error("Could not bank the reward for run #{}; will retry", run.runId, e);
		}
	}

	private static void retryBank() {
		if (run != null && !run.isActive() && !run.rewardBanked) {
			bankReward();
			save();
		}
	}

	// ---------------------------------------------------------------- effects

	private static void activateEffects(ServerPlayerEntity player) {
		for (RunEffect effect : activeEffects()) {
			effect.onActivate(player, run);
		}
	}

	private static void deactivateEffects(ServerPlayerEntity player) {
		for (RunEffect effect : activeEffects()) {
			effect.onDeactivate(player, run);
		}
	}

	// ---------------------------------------------------------------- screens

	private static void queue(ServerPlayerEntity player, ScreenKind kind) {
		PENDING.put(player.getUuid(), new Pending(kind, SCREEN_DELAY_TICKS));
	}

	private static void sendScreen(ServerPlayerEntity player, ScreenKind kind) {
		if (kind == ScreenKind.STARTER) {
			if (run != null) return;
			List<OpenStarterScreenPayload.StarterEntry> entries = new ArrayList<>();
			for (StarterDef def : StarterRegistry.all()) {
				int cost = effectiveCost(def);
				String description = def.description;
				if (cost == 0 && def.cost > 0) {
					description += " FREE: you cannot afford a starter, so this one is on the house.";
				}
				entries.add(new OpenStarterScreenPayload.StarterEntry(
					def.id, def.name, description, cost, ModifierRegistry.poolLabel(def.modifierPool)));
			}
			ServerPlayNetworking.send(player, new OpenStarterScreenPayload(MetaEconomy.balance(), entries));
		} else if (run != null && !run.isActive()) {
			ServerPlayNetworking.send(player, buildSummary());
		}
	}

	private static RunSummaryPayload buildSummary() {
		StarterDef starter = StarterRegistry.get(run.starterId);
		ModifierDef modifier = ModifierRegistry.get(run.modifierId);
		List<RunSummaryPayload.SummaryLine> lines = new ArrayList<>();
		for (RunState.RewardLine line : run.rewardLines) {
			lines.add(new RunSummaryPayload.SummaryLine(line.label, line.points));
		}
		return new RunSummaryPayload(
			run.runId,
			starter != null ? starter.name : String.valueOf(run.starterId),
			modifier != null ? modifier.name : "None",
			run.endReason == null ? "Run ended" : run.endReason,
			lines,
			run.rewardTotal,
			run.rewardPaid,
			MetaEconomy.balance(),
			run.balanceBeforeRun,
			run.starterCost);
	}

	/** Makes the player's relic items match the run. Relics live in the run; the items are their physical form. */
	public static void refreshRelicItems(ServerPlayerEntity player) {
		List<RelicInstance> expected = (run != null && run.isActive()) ? run.relics : List.of();
		RogueliteItems.syncRelics(player.getInventory(), expected, RelicRegistry::get);
	}

	// ---------------------------------------------------------------- helpers

	private static ServerPlayerEntity findOwner() {
		if (server == null || run == null || run.ownerUuid == null) return null;
		try {
			return server.getPlayerManager().getPlayer(UUID.fromString(run.ownerUuid));
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	/** Saves the run file now (used when something outside the Run Manager changes the run, e.g. gambling). */
	public static void saveRun() {
		save();
	}

	private static void save() {
		if (run == null || runFile == null) return;
		try {
			WorldRunStore.save(runFile, run);
		} catch (IOException e) {
			Roguelite.LOGGER.error("Could not save the run file {}", runFile, e);
		}
	}
}

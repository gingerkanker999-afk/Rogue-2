package com.roguelite.core;

public enum RunStatus {
	ACTIVE,
	ENDED
}

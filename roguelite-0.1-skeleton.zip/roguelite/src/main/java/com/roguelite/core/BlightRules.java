package com.roguelite.core;

/**
 * Ruin blight is a stay limit: standing inside a ruin drains health, and leaving resets the exposure timer.
 * A full 20-health bar drains in 60 seconds (3 seconds per health point). Healing and natural regeneration are
 * blocked inside a ruin, so the timer can't be out-healed. Pure Java, unit-tested.
 */
public final class BlightRules {
	public static final int SECONDS_PER_HEALTH = 3;
	public static final int FULL_BAR_HEALTH = 20;
	/** Extra blocks added around the explored area, so the ruin covers the edges of what you found. */
	public static final int RUIN_MARGIN = 16;
	/** Largest a ruin can grow from its start point in any direction, in blocks. */
	public static final int MAX_RUIN_HALF_SIZE = 1000;
	private static final long TICKS_PER_SECOND = 20L;

	private BlightRules() {}

	/** Ticks to drain a full health bar: 1,200 ticks, which is 60 seconds. */
	public static long fullBarTicks() {
		return (long) FULL_BAR_HEALTH * SECONDS_PER_HEALTH * TICKS_PER_SECOND;
	}

	/** Total health lost after {@code exposureTicks} inside a ruin, capped at a full bar. */
	public static int healthLostAfter(long exposureTicks) {
		long perHealth = (long) SECONDS_PER_HEALTH * TICKS_PER_SECOND;
		long lost = Math.max(0L, exposureTicks) / perHealth;
		return (int) Math.min(FULL_BAR_HEALTH, lost);
	}
}

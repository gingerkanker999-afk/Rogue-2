package com.roguelite.core;

/**
 * Ruin blight: standing inside a ruin drains health over time. Pure Java, unit-tested.
 * A full 20-health bar drains in 7 minutes 40 seconds (23 seconds per health point), just under 8 minutes.
 * Natural regeneration is meant to be blocked inside a ruin, so blight can't be out-healed.
 */
public final class BlightRules {
	/** Ruin radius in blocks, measured horizontally from the ruin's centre. */
	public static final int RUIN_RADIUS = 64;
	public static final int SECONDS_PER_HEALTH = 23;
	public static final int FULL_BAR_HEALTH = 20;
	private static final long TICKS_PER_SECOND = 20L;

	private BlightRules() {}

	/** Ticks to drain a full health bar: 9,200 ticks, which is 7m40s. */
	public static long fullBarTicks() {
		return (long) FULL_BAR_HEALTH * SECONDS_PER_HEALTH * TICKS_PER_SECOND;
	}

	/** Total health lost after {@code exposureTicks} inside a ruin, capped at a full bar. */
	public static int healthLostAfter(long exposureTicks) {
		long perHealth = (long) SECONDS_PER_HEALTH * TICKS_PER_SECOND;
		long lost = Math.max(0L, exposureTicks) / perHealth;
		return (int) Math.min(FULL_BAR_HEALTH, lost);
	}

	/** True if the point is within the ruin's radius (horizontal distance). */
	public static boolean inRuin(double x, double z, double centreX, double centreZ) {
		double dx = x - centreX;
		double dz = z - centreZ;
		return dx * dx + dz * dz <= (double) RUIN_RADIUS * RUIN_RADIUS;
	}
}

package com.roguelite.core;

import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Moves players between the hub and run zones in the shared world. Arriving in a zone teleports you above the
 * spot, then a platform is built under you after a short delay, so the chunks have time to load.
 * Teleport and chunk-loading calls are the parts that most need checking in-game.
 */
public final class Travel {
	/** Top of the landing platform. The player stands one block above it. */
	private static final int PLATFORM_TOP = 100;
	/** Used only if the ground can't be found (for example, the chunk never loaded). */
	private static final int FALLBACK_TOP = 100;
	private static final int SCAN_TOP = 200;
	private static final int SCAN_BOTTOM = -60;
	private static final int BUILD_DELAY_TICKS = 40;

	private static final class Pending {
		final long runId;
		int ticks;

		Pending(long runId, int ticks) {
			this.runId = runId;
			this.ticks = ticks;
		}
	}

	private static final Map<UUID, Pending> PENDING = new HashMap<>();

	private Travel() {}

	/** Sends the player to the run's zone, then builds a landing platform there after a short delay. */
	public static void toZone(MinecraftServer server, ServerPlayerEntity player, long runId) {
		ServerWorld world = server.getOverworld();
		player.changeGameMode(GameMode.SPECTATOR);
		double x = ZoneRules.centreX(runId) + 0.5;
		double z = ZoneRules.centreZ(runId) + 0.5;
		player.teleport(world, x, PLATFORM_TOP + 1, z, Set.of(), player.getYaw(), player.getPitch(), false);
		PENDING.put(player.getUuid(), new Pending(runId, BUILD_DELAY_TICKS));
	}

	/** Sends the player back to the hub. Returns false if no hub has been recorded. */
	public static boolean toHub(MinecraftServer server, ServerPlayerEntity player) {
		int[] hub = Outpost.readHub(server);
		PENDING.remove(player.getUuid());
		if (hub == null) return false;
		player.teleport(server.getOverworld(), hub[0] + 0.5, hub[1], hub[2] + 0.5, Set.of(),
			player.getYaw(), player.getPitch(), false);
		return true;
	}

	/** Counts down pending platform builds. Runs once per server tick. */
	public static void tick(MinecraftServer server) {
		if (PENDING.isEmpty()) return;
		Iterator<Map.Entry<UUID, Pending>> it = PENDING.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, Pending> entry = it.next();
			Pending pending = entry.getValue();
			ServerPlayerEntity player = server.getPlayerManager().getPlayer(entry.getKey());
			if (player == null) {
				it.remove();
				continue;
			}
			pending.ticks--;
			if (pending.ticks > 0) continue;
			it.remove();
			ServerWorld world = server.getOverworld();
			int cx = ZoneRules.centreX(pending.runId);
			int cz = ZoneRules.centreZ(pending.runId);
			int top = landingHeight(world, cx, cz);
			buildPlatform(world, cx, top, cz);
			player.teleport(world, cx + 0.5, top + 1, cz + 0.5, Set.of(),
				player.getYaw(), player.getPitch(), false);
			player.changeGameMode(GameMode.SURVIVAL);
		}
	}

	/**
	 * Height for the landing platform: just above the ground, or just above the water surface if the spot is ocean.
	 * Falls back to a fixed height if no ground is found.
	 */
	private static int landingHeight(ServerWorld world, int cx, int cz) {
		int ground = Integer.MIN_VALUE;
		for (int y = SCAN_TOP; y > SCAN_BOTTOM; y--) {
			BlockPos p = new BlockPos(cx, y, cz);
			if (!world.getBlockState(p).isAir() && world.getFluidState(p).isEmpty()) {
				ground = y;
				break;
			}
		}
		if (ground == Integer.MIN_VALUE) return FALLBACK_TOP;
		int top = ground + 1;
		while (top < 320 && !world.getFluidState(new BlockPos(cx, top, cz)).isEmpty()) {
			top++;
		}
		return top;
	}

	/** A 3x3 stone-brick platform with its headroom cleared. */
	private static void buildPlatform(ServerWorld world, int cx, int top, int cz) {
		for (int dx = -1; dx <= 1; dx++) {
			for (int dz = -1; dz <= 1; dz++) {
				world.setBlockState(new BlockPos(cx + dx, top, cz + dz), Blocks.STONE_BRICKS.getDefaultState());
				for (int dy = 1; dy <= 3; dy++) {
					world.setBlockState(new BlockPos(cx + dx, top + dy, cz + dz), Blocks.AIR.getDefaultState());
				}
			}
		}
	}
}

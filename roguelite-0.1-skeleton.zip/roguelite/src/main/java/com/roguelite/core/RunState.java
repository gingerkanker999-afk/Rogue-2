package com.roguelite.core;

import com.roguelite.relic.RelicInstance;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Everything the world knows about its run. Stored as JSON inside the world folder
 * (roguelite/run.json) - it never holds the meta balance, which belongs to the global profile.
 */
public class RunState {
	public int schemaVersion = 1;
	public long runId;
	public RunStatus status = RunStatus.ACTIVE;
	/** UUID of the player who owns the run (the one who bought the starter). */
	public String ownerUuid;
	public String starterId;
	public String modifierId;
	public List<RelicInstance> relics = new ArrayList<>();
	/** Run Luck stat. Affects roguelite rolls only, never Blackjack odds. */
	public int luck;

	/** Overworld game time when the run started. */
	public long startTick;
	/** Original run spawn (used later by Homing Stone). */
	public String startDimension = "minecraft:overworld";
	public int startX;
	public int startY;
	public int startZ;

	/** Meta balance just before the starter was bought (-1 if unknown, e.g. an older save). */
	public int balanceBeforeRun = -1;
	/** What the starter actually cost (-1 if unknown). */
	public int starterCost = -1;

	/** Daily Roll: the game day (world time / 24000) the current roll belongs to, and its face (0 = not rolled yet). */
	public long dailyRollDay = -1;
	public int dailyRollFace;

	/** Extraction shrines placed in this run's world, as "x,y,z" keys. */
	public java.util.List<String> shrines = new java.util.ArrayList<>();
	/** Development caches in this run's world, as "kind@x,y,z" entries. */
	public java.util.List<String> caches = new java.util.ArrayList<>();
	/** Caches whose first open has already been paid. */
	public java.util.List<String> openedCaches = new java.util.ArrayList<>();
	/** Share of the run score banked when the run ends (death 25%, emergency 50%, full 100%). */
	public int payoutPercent = 100;

	public long endTick;
	public String endReason;
	public int deaths;

	public Set<String> achievements = new LinkedHashSet<>();
	public Map<String, Long> counters = new LinkedHashMap<>();

	public List<RewardLine> rewardLines = new ArrayList<>();
	/** Total Run Score calculated at the end of the run. */
	public int rewardTotal;
	/** True once this run's reward has been processed against the profile (paid or already paid). */
	public boolean rewardBanked;
	/** Amount actually added to the profile (0 if the run id had already been banked elsewhere). */
	public int rewardPaid;

	public static class RewardLine {
		public String label;
		public int points;
	}

	public boolean isActive() {
		return status == RunStatus.ACTIVE;
	}

	public void addCounter(String id, long amount) {
		counters.merge(id, amount, Long::sum);
	}
}

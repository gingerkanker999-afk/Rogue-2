package com.roguelite.core;

import java.util.Set;

/**
 * Stash rules: what may be carried from a run to the outpost, and how big the stash is. Pure Java, unit-tested.
 * Testing allow-list is a single food; expand ALLOWED_FOODS when the loop feels right.
 */
public final class StashRules {
	public static final Set<String> ALLOWED_FOODS = Set.of("minecraft:bread");

	public static final int BASE_SLOTS = 9;
	public static final int SLOTS_PER_UPGRADE = 9;
	public static final int ITEMS_PER_SLOT = 64;
	/** Cost of upgrade 1, 2 and 3 in meta. Upgrade 1 goes 9 to 18 slots, and so on. */
	private static final int[] UPGRADE_COSTS = {15, 25, 35};

	private StashRules() {}

	public static boolean allowed(String itemId) {
		return ALLOWED_FOODS.contains(itemId);
	}

	/** Cost of the next upgrade from this level, or -1 if the stash is already maxed. */
	public static int upgradeCost(int level) {
		return level < 0 || level >= UPGRADE_COSTS.length ? -1 : UPGRADE_COSTS[level];
	}

	public static int slots(int level) {
		int clamped = Math.max(0, Math.min(UPGRADE_COSTS.length, level));
		return BASE_SLOTS + SLOTS_PER_UPGRADE * clamped;
	}

	public static int capacityItems(int level) {
		return slots(level) * ITEMS_PER_SLOT;
	}

	/** How many of {@code wanted} fit in the space left. Never negative. */
	public static int depositAmount(int used, int capacity, int wanted) {
		return Math.max(0, Math.min(wanted, capacity - used));
	}
}

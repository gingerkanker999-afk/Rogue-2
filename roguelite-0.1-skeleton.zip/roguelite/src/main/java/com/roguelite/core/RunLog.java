package com.roguelite.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * One CSV file for balancing data: a row per finished run and per outpost purchase. Pure Java, so the formatting is
 * tested without Minecraft. If an older log with a different header is found, it is renamed, never overwritten.
 */
public final class RunLog {
	public static final String HEADER =
		"timestamp,event,run_id,starter,modifier,minutes,end_reason,rewards,total,paid,balance_after,"
			+ "finds_roll,finds_pity,gamble_rounds,chips_net,relic_wagers,relic_won,relic_lost,relic_pulls,previews";

	private static final int BLANK_RUN_COLUMNS = 9;

	private RunLog() {}

	/** CSV-escapes a field: quotes it if it has a comma, quote or newline. */
	public static String escape(String value) {
		String v = value == null ? "" : value;
		if (v.contains(",") || v.contains("\"") || v.contains("\n")) {
			return "\"" + v.replace("\"", "\"\"") + "\"";
		}
		return v;
	}

	/** A finished run. Rewards are listed as "Label +points; Label +points". */
	public static String runRow(String timestamp, RunState run, long durationTicks, int balanceAfter) {
		StringBuilder rewards = new StringBuilder();
		for (RunState.RewardLine line : run.rewardLines) {
			if (rewards.length() > 0) rewards.append("; ");
			rewards.append(line.label).append(" +").append(line.points);
		}
		List<String> cols = new ArrayList<>();
		cols.add(escape(timestamp));
		cols.add("run");
		cols.add(String.valueOf(run.runId));
		cols.add(escape(run.starterId));
		cols.add(escape(run.modifierId));
		cols.add(String.format(Locale.ROOT, "%.1f", durationTicks / 1200.0));
		cols.add(escape(run.endReason));
		cols.add(escape(rewards.toString()));
		cols.add(String.valueOf(run.rewardTotal));
		cols.add(String.valueOf(run.rewardPaid));
		cols.add(String.valueOf(balanceAfter));
		cols.add(counter(run, "roll_finds"));
		cols.add(counter(run, "pity_finds"));
		cols.add(counter(run, "gamble_rounds"));
		cols.add(counter(run, "chips_net"));
		cols.add(counter(run, "relic_wagers"));
		cols.add(counter(run, "relic_won"));
		cols.add(counter(run, "relic_lost"));
		cols.add(counter(run, "relic_pulls"));
		cols.add(counter(run, "previews"));
		return String.join(",", cols);
	}

	private static String counter(RunState run, String key) {
		return String.valueOf(run.counters.getOrDefault(key, 0L));
	}

	/** An outpost purchase. The cost is recorded as a negative "paid" amount. */
	public static String buyRow(String timestamp, String starterId, int cost, int balanceAfter) {
		List<String> cols = new ArrayList<>();
		cols.add(escape(timestamp));
		cols.add("buy");
		cols.add("");
		cols.add(escape(starterId));
		cols.add("");
		cols.add("");
		cols.add("");
		cols.add("");
		cols.add("");
		cols.add(String.valueOf(-cost));
		cols.add(String.valueOf(balanceAfter));
		for (int i = 0; i < BLANK_RUN_COLUMNS; i++) cols.add("");
		return String.join(",", cols);
	}

	/**
	 * Appends a row, writing the header first if the file is new. If the file exists with an older header, it is
	 * renamed to runs-old-<time>.csv first so columns never mix.
	 */
	public static void append(Path file, String row) throws IOException {
		if (file.getParent() != null) Files.createDirectories(file.getParent());
		if (Files.exists(file) && !HEADER.equals(firstLine(file))) {
			Path old = file.resolveSibling("runs-old-" + System.currentTimeMillis() + ".csv");
			Files.move(file, old);
		}
		StringBuilder out = new StringBuilder();
		if (!Files.exists(file)) out.append(HEADER).append('\n');
		out.append(row).append('\n');
		Files.writeString(file, out.toString(), StandardCharsets.UTF_8,
			StandardOpenOption.CREATE, StandardOpenOption.APPEND);
	}

	private static String firstLine(Path file) throws IOException {
		try (Stream<String> lines = Files.lines(file, StandardCharsets.UTF_8)) {
			return lines.findFirst().orElse("");
		}
	}
}

package com.roguelite.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Locale;

/**
 * One CSV file for balancing data: a row per finished run and per outpost purchase. Pure Java, so the
 * formatting is tested without Minecraft. Tuning means reading this file, not guessing.
 */
public final class RunLog {
	public static final String HEADER =
		"timestamp,event,run_id,starter,modifier,minutes,end_reason,rewards,total,paid,balance_after";

	private RunLog() {}

	/** CSV-escapes a field: quotes it if it has a comma, quote or newline. */
	public static String escape(String value) {
		String v = value == null ? "" : value;
		if (v.contains(",") || v.contains("\"") || v.contains("\n")) {
			return "\"" + v.replace("\"", "\"\"") + "\"";
		}
		return v;
	}

	/** A finished run. Rewards are listed as "Label +points; Label +points". */
	public static String runRow(String timestamp, RunState run, long durationTicks, int balanceAfter) {
		StringBuilder rewards = new StringBuilder();
		for (RunState.RewardLine line : run.rewardLines) {
			if (rewards.length() > 0) rewards.append("; ");
			rewards.append(line.label).append(" +").append(line.points);
		}
		String minutes = String.format(Locale.ROOT, "%.1f", durationTicks / 1200.0);
		return String.join(",",
			escape(timestamp),
			"run",
			String.valueOf(run.runId),
			escape(run.starterId),
			escape(run.modifierId),
			minutes,
			escape(run.endReason),
			escape(rewards.toString()),
			String.valueOf(run.rewardTotal),
			String.valueOf(run.rewardPaid),
			String.valueOf(balanceAfter));
	}

	/** An outpost purchase. The cost is recorded as a negative "paid" amount. */
	public static String buyRow(String timestamp, String starterId, int cost, int balanceAfter) {
		return String.join(",",
			escape(timestamp), "buy", "", escape(starterId), "", "", "", "", "", String.valueOf(-cost),
			String.valueOf(balanceAfter));
	}

	/** Appends a row, writing the header first if the file is new. */
	public static void append(Path file, String row) throws IOException {
		if (file.getParent() != null) Files.createDirectories(file.getParent());
		StringBuilder out = new StringBuilder();
		if (!Files.exists(file)) out.append(HEADER).append('\n');
		out.append(row).append('\n');
		Files.writeString(file, out.toString(), StandardCharsets.UTF_8,
			StandardOpenOption.CREATE, StandardOpenOption.APPEND);
	}
}

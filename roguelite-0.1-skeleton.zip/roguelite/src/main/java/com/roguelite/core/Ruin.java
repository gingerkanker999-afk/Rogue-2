package com.roguelite.core;

/** A persistent ruin left behind by a finished run, at that run's start point. */
public record Ruin(long runId, int centreX, int centreZ) {}

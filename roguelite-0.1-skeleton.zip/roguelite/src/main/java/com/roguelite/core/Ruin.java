package com.roguelite.core;

/** A persistent ruin: the box a finished run explored, plus a margin. Edges are inclusive. */
public record Ruin(long runId, int minX, int maxX, int minZ, int maxZ) {
	public boolean contains(double x, double z) {
		return x >= minX && x <= maxX && z >= minZ && z <= maxZ;
	}
}

package com.roguelite.core;

/** Farm plot rules: 2 bread per in-game day, stored up to 8. Pure Java, unit-tested. */
public final class FarmRules {
	public static final long TICKS_PER_DAY = 24000L;
	public static final int COST = 25;
	public static final int PER_DAY = 2;
	public static final int CAP = 8;

	private FarmRules() {}

	public static long dayOf(long ticks) {
		return ticks / TICKS_PER_DAY;
	}

	/** Food stored after {@code daysElapsed} more days, never above the cap and never negative. */
	public static int accrue(int stored, long daysElapsed) {
		long days = Math.max(0L, daysElapsed);
		long total = stored + (long) PER_DAY * days;
		return (int) Math.min(CAP, Math.max(0L, total));
	}
}

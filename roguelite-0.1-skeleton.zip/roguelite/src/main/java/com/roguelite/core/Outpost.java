package com.roguelite.core;

import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Identifies the outpost world and whether it is also the shared hub. The outpost is an ordinary world you create by
 * hand; marking it writes small files into that world's roguelite folder. Run worlds never have them.
 */
public final class Outpost {
	private Outpost() {}

	private static Path dir(MinecraftServer server) {
		return server.getSavePath(WorldSavePath.ROOT).resolve("roguelite");
	}

	public static boolean isOutpost(MinecraftServer server) {
		return server != null && Files.isRegularFile(dir(server).resolve("outpost"));
	}

	public static void mark(MinecraftServer server) throws IOException {
		Path file = dir(server).resolve("outpost");
		Files.createDirectories(file.getParent());
		Files.writeString(file, "outpost\n", StandardCharsets.UTF_8);
	}

	/** Shared mode: runs happen in zones inside this same world, and the hub is where you come back to. */
	public static boolean isShared(MinecraftServer server) {
		return server != null && Files.isRegularFile(dir(server).resolve("shared"));
	}

	public static void enableShared(MinecraftServer server, int x, int y, int z) throws IOException {
		mark(server);
		Path hub = dir(server).resolve("hub");
		Files.writeString(hub, x + " " + y + " " + z + "\n", StandardCharsets.UTF_8);
		Files.writeString(dir(server).resolve("shared"), "shared\n", StandardCharsets.UTF_8);
	}

	/** The hub position as {x, y, z}, or null if none has been recorded. */
	public static int[] readHub(MinecraftServer server) {
		Path hub = dir(server).resolve("hub");
		if (!Files.isRegularFile(hub)) return null;
		try {
			String[] parts = Files.readString(hub, StandardCharsets.UTF_8).trim().split("\\s+");
			if (parts.length != 3) return null;
			return new int[] {Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2])};
		} catch (IOException | NumberFormatException e) {
			return null;
		}
	}
}

package com.roguelite.core;

import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Identifies the outpost world. The outpost is an ordinary world you create by hand; marking it writes a small file
 * into that world's roguelite folder. Run worlds never have the file, so they never act as the outpost.
 */
public final class Outpost {
	private Outpost() {}

	private static Path marker(MinecraftServer server) {
		return server.getSavePath(WorldSavePath.ROOT).resolve("roguelite").resolve("outpost");
	}

	public static boolean isOutpost(MinecraftServer server) {
		return server != null && Files.isRegularFile(marker(server));
	}

	public static void mark(MinecraftServer server) throws IOException {
		Path file = marker(server);
		Files.createDirectories(file.getParent());
		Files.writeString(file, "outpost\n");
	}
}

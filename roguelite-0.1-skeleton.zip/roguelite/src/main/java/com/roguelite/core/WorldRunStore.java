package com.roguelite.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.roguelite.Roguelite;
import com.roguelite.util.FileUtil;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Reads and writes the run file inside a world folder. */
public final class WorldRunStore {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private WorldRunStore() {}

	/** Returns the saved run, or null if there is none (or the file is unreadable, in which case it is quarantined). */
	public static RunState load(Path file) {
		if (!Files.isRegularFile(file)) return null;
		try {
			RunState state = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), RunState.class);
			if (state != null) {
				if (state.relics == null) state.relics = new java.util.ArrayList<>();
				if (state.achievements == null) state.achievements = new java.util.LinkedHashSet<>();
				if (state.counters == null) state.counters = new java.util.LinkedHashMap<>();
				if (state.rewardLines == null) state.rewardLines = new java.util.ArrayList<>();
				if (state.status == null) state.status = RunStatus.ACTIVE;
				return state;
			}
		} catch (Exception e) {
			Roguelite.LOGGER.error("Run file {} is unreadable", file, e);
		}
		try {
			Path moved = FileUtil.quarantine(file);
			Roguelite.LOGGER.error("Moved the unreadable run file to {}; this world now has no run", moved);
		} catch (IOException e) {
			Roguelite.LOGGER.error("Could not move the unreadable run file out of the way", e);
		}
		return null;
	}

	public static void save(Path file, RunState state) throws IOException {
		FileUtil.writeAtomic(file, GSON.toJson(state));
	}
}

package com.roguelite.core;

/**
 * Extraction and death payout rules. Pure Java, so they are unit-tested without Minecraft.
 * These are provisional balance values, kept here so they are easy to change.
 */
public final class ExtractionRules {
	/** Share of the run score kept when you die. */
	public static final int DEATH_PERCENT = 25;

	public enum Mode {
		/** Quick exit: short channel, small moves allowed, banks half. */
		EMERGENCY("emergency", 50, 60, 2.0),
		/** Full exit: long channel, must stay still, banks everything. */
		FULL("full", 100, 200, 0.3);

		public final String label;
		public final int percent;
		/** Ticks the player must stay in range. */
		public final int channelTicks;
		/** Horizontal blocks the player may drift from the shrine's start point. */
		public final double maxMove;

		Mode(String label, int percent, int channelTicks, double maxMove) {
			this.label = label;
			this.percent = percent;
			this.channelTicks = channelTicks;
			this.maxMove = maxMove;
		}
	}

	private ExtractionRules() {}

	/** Floor of total x percent. Percent is clamped to 0-100. */
	public static int payout(int total, int percent) {
		int clamped = Math.max(0, Math.min(100, percent));
		return (int) ((long) Math.max(0, total) * clamped / 100L);
	}

	/** Any damage cancels a channel. Moving further than the mode allows cancels it too. */
	public static boolean shouldCancel(Mode mode, double horizontalMove, boolean tookDamage) {
		return tookDamage || horizontalMove > mode.maxMove;
	}
}

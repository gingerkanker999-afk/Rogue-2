package com.roguelite.core;

/** Outcome of a start-run request. */
public record StartResult(boolean ok, String message) {
	public static StartResult success() {
		return new StartResult(true, "");
	}

	public static StartResult fail(String message) {
		return new StartResult(false, message);
	}
}

package com.roguelite.core;

import java.util.random.RandomGenerator;

/**
 * Random finds: small, frequent, Luck-weighted rewards on common actions, plus a pity timer so a quiet stretch
 * always ends with a small payout. Pure Java, unit-tested. All numbers are provisional, pending the run log.
 */
public final class RandomFinds {
	/** Ticks (20 per second) without a find before the next eligible action pays. 6000 = 5 minutes. */
	public static final long PITY_TICKS = 6000L;
	/** Chance per block broken, before Luck. */
	public static final double BLOCK_CHANCE = 0.005;
	/** Chance per mob killed, before Luck. */
	public static final double KILL_CHANCE = 0.05;

	private static final double LUCK_STEP = 0.05;
	private static final double MAX_CHANCE = 0.5;

	private RandomFinds() {}

	/** Base chance raised by 5% per Luck point, capped so Luck can't make finds routine. */
	public static double chance(double base, int luck) {
		int clamped = Math.max(0, luck);
		return Math.min(MAX_CHANCE, base * (1.0 + LUCK_STEP * clamped));
	}

	public static boolean rolls(RandomGenerator rng, double base, int luck) {
		return rng.nextDouble() < chance(base, luck);
	}

	/** True once at least {@code threshold} ticks have passed since the last find. */
	public static boolean pityDue(long now, long lastFind, long threshold) {
		return now - lastFind >= threshold;
	}
}

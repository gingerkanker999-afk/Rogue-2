package com.roguelite.reward;

/** One line of the Run Score table (loaded from rewards.json). */
public class RewardDef {
	public String id;
	public String label;
	/** Meta currency per occurrence. */
	public int points;
	/** Repeatable rewards pay per counter value (e.g. per day survived); others pay once. */
	public boolean repeatable;
}

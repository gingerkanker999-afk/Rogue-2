package com.roguelite.reward;

import com.google.gson.reflect.TypeToken;
import com.roguelite.Roguelite;
import com.roguelite.data.DefinitionLoader;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class RewardTable {
	private static final Map<String, RewardDef> DEFS = new LinkedHashMap<>();

	private RewardTable() {}

	public static void load() {
		DEFS.clear();
		List<RewardDef> list = DefinitionLoader.loadList("rewards.json", new TypeToken<List<RewardDef>>() {}.getType());
		for (RewardDef def : list) {
			if (def == null || def.id == null || def.id.isBlank()) {
				Roguelite.LOGGER.warn("Skipping reward with no id");
				continue;
			}
			if (DEFS.putIfAbsent(def.id, def) != null) {
				Roguelite.LOGGER.warn("Duplicate reward id '{}' ignored", def.id);
			}
		}
		Roguelite.LOGGER.info("Loaded {} reward entries", DEFS.size());
	}

	public static RewardDef get(String id) {
		return id == null ? null : DEFS.get(id);
	}

	public static Collection<RewardDef> all() {
		return DEFS.values();
	}
}

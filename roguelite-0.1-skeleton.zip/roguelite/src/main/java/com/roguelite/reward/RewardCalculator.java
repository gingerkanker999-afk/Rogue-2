package com.roguelite.reward;

import com.roguelite.core.RunState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Turns a run's achievements/counters into Run Score (= meta currency). Pure logic, no Minecraft types. */
public final class RewardCalculator {
	public static final long TICKS_PER_DAY = 24000L;
	public static final String SURVIVE_DAY = "survive_day";

	/** The score breakdown for a run at a given moment. */
	public record Result(List<RunState.RewardLine> lines, int total, long days) {}

	private RewardCalculator() {}

	/** Computes the score so far WITHOUT changing the run. Used by the status command. */
	public static Result preview(RunState run, long nowTick) {
		return preview(run, nowTick, RewardTable.all());
	}

	/** Same, with an explicit reward table (used by tests). */
	public static Result preview(RunState run, long nowTick, java.util.Collection<RewardDef> defs) {
		long days = Math.max(0L, (nowTick - run.startTick) / TICKS_PER_DAY);
		Map<String, Long> counters = new HashMap<>(run.counters);
		counters.put(SURVIVE_DAY, days);

		List<RunState.RewardLine> lines = new ArrayList<>();
		int total = 0;
		for (RewardDef def : defs) {
			long n;
			if (def.repeatable) {
				n = counters.getOrDefault(def.id, 0L);
			} else {
				n = run.achievements.contains(def.id) ? 1L : 0L;
			}
			if (n <= 0 || def.points == 0) continue;

			long points = n * (long) def.points;
			RunState.RewardLine line = new RunState.RewardLine();
			line.label = n > 1 ? def.label + " x" + n : def.label;
			line.points = (int) Math.min(points, Integer.MAX_VALUE);
			lines.add(line);
			total += line.points;
		}
		return new Result(lines, total, days);
	}

	/** Fills run.rewardLines and run.rewardTotal. Safe to call more than once; it recomputes from scratch. */
	public static void calculate(RunState run, long nowTick) {
		calculate(run, nowTick, RewardTable.all());
	}

	public static void calculate(RunState run, long nowTick, java.util.Collection<RewardDef> defs) {
		Result result = preview(run, nowTick, defs);
		run.counters.put(SURVIVE_DAY, result.days());
		run.rewardLines.clear();
		run.rewardLines.addAll(result.lines());
		run.rewardTotal = result.total();
	}
}

package com.roguelite.reward;

import com.roguelite.core.RunState;

/** Turns a finished run's achievements/counters into Run Score (= meta currency). Pure logic, no Minecraft types. */
public final class RewardCalculator {
	public static final long TICKS_PER_DAY = 24000L;
	public static final String SURVIVE_DAY = "survive_day";

	private RewardCalculator() {}

	/** Fills run.rewardLines and run.rewardTotal. Safe to call more than once; it recomputes from scratch. */
	public static void calculate(RunState run, long nowTick) {
		long days = Math.max(0L, (nowTick - run.startTick) / TICKS_PER_DAY);
		run.counters.put(SURVIVE_DAY, days);

		run.rewardLines.clear();
		int total = 0;
		for (RewardDef def : RewardTable.all()) {
			long n;
			if (def.repeatable) {
				n = run.counters.getOrDefault(def.id, 0L);
			} else {
				n = run.achievements.contains(def.id) ? 1L : 0L;
			}
			if (n <= 0 || def.points == 0) continue;

			long points = n * (long) def.points;
			RunState.RewardLine line = new RunState.RewardLine();
			line.label = n > 1 ? def.label + " x" + n : def.label;
			line.points = (int) Math.min(points, Integer.MAX_VALUE);
			run.rewardLines.add(line);
			total += line.points;
		}
		run.rewardTotal = total;
	}
}

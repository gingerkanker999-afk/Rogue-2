package com.roguelite.net;

import com.roguelite.Roguelite;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: "buy this starter and start the run". The server re-validates everything. */
public record StartRunRequestPayload(String starterId) implements CustomPayload {
	public static final Id<StartRunRequestPayload> ID =
		new Id<>(Identifier.of(Roguelite.MOD_ID, "start_run_request"));

	public static final PacketCodec<RegistryByteBuf, StartRunRequestPayload> CODEC = new PacketCodec<>() {
		@Override
		public StartRunRequestPayload decode(RegistryByteBuf buf) {
			return new StartRunRequestPayload(buf.readString());
		}

		@Override
		public void encode(RegistryByteBuf buf, StartRunRequestPayload value) {
			buf.writeString(value.starterId());
		}
	};

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}

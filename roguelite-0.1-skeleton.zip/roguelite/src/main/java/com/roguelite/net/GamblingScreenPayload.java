package com.roguelite.net;

import com.roguelite.Roguelite;
import com.roguelite.gambling.session.ButtonSpec;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Server -> client: the gambling screen to show (title, lines, buttons), or a request to close it. */
public record GamblingScreenPayload(String title, List<String> lines, List<ButtonSpec> buttons, boolean close)
	implements CustomPayload {
	public static final Id<GamblingScreenPayload> ID =
		new Id<>(Identifier.of(Roguelite.MOD_ID, "gambling_screen"));

	public static final PacketCodec<RegistryByteBuf, GamblingScreenPayload> CODEC = new PacketCodec<>() {
		@Override
		public GamblingScreenPayload decode(RegistryByteBuf buf) {
			String title = buf.readString();
			int lineCount = buf.readVarInt();
			List<String> lines = new ArrayList<>(lineCount);
			for (int i = 0; i < lineCount; i++) lines.add(buf.readString());
			int buttonCount = buf.readVarInt();
			List<ButtonSpec> buttons = new ArrayList<>(buttonCount);
			for (int i = 0; i < buttonCount; i++) {
				buttons.add(new ButtonSpec(buf.readString(), buf.readString(), buf.readString(), buf.readVarInt()));
			}
			return new GamblingScreenPayload(title, lines, buttons, buf.readBoolean());
		}

		@Override
		public void encode(RegistryByteBuf buf, GamblingScreenPayload value) {
			buf.writeString(value.title());
			buf.writeVarInt(value.lines().size());
			for (String line : value.lines()) buf.writeString(line);
			buf.writeVarInt(value.buttons().size());
			for (ButtonSpec b : value.buttons()) {
				buf.writeString(b.label());
				buf.writeString(b.action());
				buf.writeString(b.arg());
				buf.writeVarInt(b.amount());
			}
			buf.writeBoolean(value.close());
		}
	};

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}

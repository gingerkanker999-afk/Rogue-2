package com.roguelite.net;

import com.roguelite.Roguelite;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> client: result of a start-run request (ok closes the screen, otherwise the message is shown). */
public record StartResultPayload(boolean ok, String message) implements CustomPayload {
	public static final Id<StartResultPayload> ID =
		new Id<>(Identifier.of(Roguelite.MOD_ID, "start_result"));

	public static final PacketCodec<RegistryByteBuf, StartResultPayload> CODEC = new PacketCodec<>() {
		@Override
		public StartResultPayload decode(RegistryByteBuf buf) {
			return new StartResultPayload(buf.readBoolean(), buf.readString());
		}

		@Override
		public void encode(RegistryByteBuf buf, StartResultPayload value) {
			buf.writeBoolean(value.ok());
			buf.writeString(value.message());
		}
	};

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}

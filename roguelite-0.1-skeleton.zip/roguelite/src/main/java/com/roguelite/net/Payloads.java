package com.roguelite.net;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

/** Registers the packet types. Must run on both client and server (it is called from the common entrypoint). */
public final class Payloads {
	private Payloads() {}

	public static void register() {
		PayloadTypeRegistry.playS2C().register(OpenStarterScreenPayload.ID, OpenStarterScreenPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(StartResultPayload.ID, StartResultPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(RunSummaryPayload.ID, RunSummaryPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(StartRunRequestPayload.ID, StartRunRequestPayload.CODEC);
	}
}

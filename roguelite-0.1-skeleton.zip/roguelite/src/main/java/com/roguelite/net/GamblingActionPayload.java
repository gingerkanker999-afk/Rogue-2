package com.roguelite.net;

import com.roguelite.Roguelite;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: a button was pressed. The server validates the action against the session's state. */
public record GamblingActionPayload(String action, String arg, int amount) implements CustomPayload {
	public static final Id<GamblingActionPayload> ID =
		new Id<>(Identifier.of(Roguelite.MOD_ID, "gambling_action"));

	public static final PacketCodec<RegistryByteBuf, GamblingActionPayload> CODEC = new PacketCodec<>() {
		@Override
		public GamblingActionPayload decode(RegistryByteBuf buf) {
			return new GamblingActionPayload(buf.readString(64), buf.readString(64), buf.readVarInt());
		}

		@Override
		public void encode(RegistryByteBuf buf, GamblingActionPayload value) {
			buf.writeString(value.action());
			buf.writeString(value.arg());
			buf.writeVarInt(value.amount());
		}
	};

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}

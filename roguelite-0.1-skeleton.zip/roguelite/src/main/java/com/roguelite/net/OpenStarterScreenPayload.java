package com.roguelite.net;

import com.roguelite.Roguelite;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Server -> client: open the starter selection screen. */
public record OpenStarterScreenPayload(int balance, List<StarterEntry> starters) implements CustomPayload {
	public static final Id<OpenStarterScreenPayload> ID =
		new Id<>(Identifier.of(Roguelite.MOD_ID, "open_starter_screen"));

	public record StarterEntry(String id, String name, String description, int cost, String poolLabel) {}

	public static final PacketCodec<RegistryByteBuf, OpenStarterScreenPayload> CODEC = new PacketCodec<>() {
		@Override
		public OpenStarterScreenPayload decode(RegistryByteBuf buf) {
			int balance = buf.readVarInt();
			int count = buf.readVarInt();
			List<StarterEntry> list = new ArrayList<>(count);
			for (int i = 0; i < count; i++) {
				list.add(new StarterEntry(buf.readString(), buf.readString(), buf.readString(), buf.readVarInt(), buf.readString()));
			}
			return new OpenStarterScreenPayload(balance, list);
		}

		@Override
		public void encode(RegistryByteBuf buf, OpenStarterScreenPayload value) {
			buf.writeVarInt(value.balance());
			buf.writeVarInt(value.starters().size());
			for (StarterEntry e : value.starters()) {
				buf.writeString(e.id());
				buf.writeString(e.name());
				buf.writeString(e.description());
				buf.writeVarInt(e.cost());
				buf.writeString(e.poolLabel());
			}
		}
	};

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}

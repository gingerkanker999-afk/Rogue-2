package com.roguelite.net;

import com.roguelite.Roguelite;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Server -> client: show the end-of-run summary screen. */
public record RunSummaryPayload(
	long runId,
	String starterName,
	String modifierName,
	String endReason,
	List<SummaryLine> lines,
	int total,
	int paid,
	int balance
) implements CustomPayload {
	public static final Id<RunSummaryPayload> ID =
		new Id<>(Identifier.of(Roguelite.MOD_ID, "run_summary"));

	public record SummaryLine(String label, int points) {}

	public static final PacketCodec<RegistryByteBuf, RunSummaryPayload> CODEC = new PacketCodec<>() {
		@Override
		public RunSummaryPayload decode(RegistryByteBuf buf) {
			long runId = buf.readLong();
			String starter = buf.readString();
			String modifier = buf.readString();
			String reason = buf.readString();
			int count = buf.readVarInt();
			List<SummaryLine> lines = new ArrayList<>(count);
			for (int i = 0; i < count; i++) {
				lines.add(new SummaryLine(buf.readString(), buf.readVarInt()));
			}
			int total = buf.readVarInt();
			int paid = buf.readVarInt();
			int balance = buf.readVarInt();
			return new RunSummaryPayload(runId, starter, modifier, reason, lines, total, paid, balance);
		}

		@Override
		public void encode(RegistryByteBuf buf, RunSummaryPayload value) {
			buf.writeLong(value.runId());
			buf.writeString(value.starterName());
			buf.writeString(value.modifierName());
			buf.writeString(value.endReason());
			buf.writeVarInt(value.lines().size());
			for (SummaryLine l : value.lines()) {
				buf.writeString(l.label());
				buf.writeVarInt(l.points());
			}
			buf.writeVarInt(value.total());
			buf.writeVarInt(value.paid());
			buf.writeVarInt(value.balance());
		}
	};

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}

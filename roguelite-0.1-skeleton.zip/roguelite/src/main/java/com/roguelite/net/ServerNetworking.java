package com.roguelite.net;

import com.roguelite.core.RunManager;
import com.roguelite.core.StartResult;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

/** Server-side packet handling. Everything the client sends is treated as a request and re-validated. */
public final class ServerNetworking {
	private ServerNetworking() {}

	public static void register() {
		ServerPlayNetworking.registerGlobalReceiver(StartRunRequestPayload.ID, (payload, context) -> {
			ServerPlayerEntity player = context.player();
			context.server().execute(() -> {
				StartResult result = RunManager.startRun(player, payload.starterId());
				ServerPlayNetworking.send(player, new StartResultPayload(result.ok(), result.message()));
			});
		});
	}
}

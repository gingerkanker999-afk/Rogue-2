package com.roguelite.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.roguelite.modifier.ModifierDef;
import com.roguelite.modifier.ModifierRegistry;
import com.roguelite.relic.RelicDef;
import com.roguelite.relic.RelicRegistry;
import net.minecraft.command.CommandSource;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.roguelite.Roguelite;
import com.roguelite.core.RunManager;
import com.roguelite.economy.MetaEconomy;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;

/**
 * /roguelite status - run + balance summary. /roguelite start - reopen the starter screen if you closed it.
 * /roguelite debug end | grant <n> | relic <id> | modifier <id> - only registered in a dev environment, with -Droguelite.debug=true, or when an
 * empty file named 'debug' exists in config/roguelite/,
 * because 1.21.11 changed how command permissions are declared and I did not want to guess that API.
 */
public final class RogueliteCommands {
	private RogueliteCommands() {}

	private static String upgradeStash() {
		if (!com.roguelite.core.RunManager.inOutpost()) return "Upgrade your stash at the outpost.";
		try {
			if (com.roguelite.economy.MetaEconomy.buyStashUpgrade()) {
				return "Stash upgraded. Capacity is now " + com.roguelite.economy.MetaEconomy.stashCapacity() + " items.";
			}
			return "Not enough meta for the next stash upgrade, or the stash is already maxed.";
		} catch (IOException e) {
			return "Could not save your profile. Nothing was spent.";
		}
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			boolean debug = Boolean.getBoolean("roguelite.debug")
				|| FabricLoader.getInstance().isDevelopmentEnvironment()
				|| Files.exists(FabricLoader.getInstance().getConfigDir().resolve(Roguelite.MOD_ID).resolve("debug"))
				|| Files.exists(FabricLoader.getInstance().getConfigDir().resolve(Roguelite.MOD_ID).resolve("debug.txt"));

			LiteralArgumentBuilder<ServerCommandSource> root = CommandManager.literal("roguelite")
				.then(CommandManager.literal("outpost").then(CommandManager.literal("mark").executes(ctx -> {
					try {
						com.roguelite.core.Outpost.mark(ctx.getSource().getServer());
						ctx.getSource().sendFeedback(() -> Text.literal(
							"This world is now your outpost. Place a lectern (the Run Table) and right-click it."), false);
						return 1;
					} catch (IOException e) {
						ctx.getSource().sendFeedback(() -> Text.literal("Could not mark this world: " + e.getMessage()), false);
						return 0;
					}
				})))
				.then(CommandManager.literal("stash").then(CommandManager.literal("upgrade").executes(ctx -> {
					String message = upgradeStash();
					ctx.getSource().sendFeedback(() -> Text.literal(message), false);
					return 1;
				})))
				.then(CommandManager.literal("start").executes(ctx -> {
					ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
					boolean opened = RunManager.openStarterScreen(player);
					if (!opened) {
						ctx.getSource().sendFeedback(() -> Text.literal("This world already has a run."), false);
					}
					return opened ? 1 : 0;
				}))
				.then(CommandManager.literal("status").executes(ctx -> {
					for (String line : RunManager.statusLines()) {
						ctx.getSource().sendFeedback(() -> Text.literal(line), false);
					}
					return 1;
				}));

			if (debug) {
				root.then(CommandManager.literal("debug")
					.then(CommandManager.literal("end").executes(ctx -> {
						ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
						boolean ended = RunManager.debugEndRun(player);
						ctx.getSource().sendFeedback(() -> Text.literal(ended ? "Run ended." : "No active run owned by you."), false);
						return ended ? 1 : 0;
					}))
					.then(CommandManager.literal("relic")
						.then(CommandManager.argument("id", StringArgumentType.word())
							.suggests((ctx, builder) -> CommandSource.suggestMatching(
								RelicRegistry.all().stream().map(r -> r.id).toList(), builder))
							.executes(ctx -> {
								ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
								String id = StringArgumentType.getString(ctx, "id");
								RelicDef def = RelicRegistry.get(id);
								boolean ok = def != null && RunManager.grantRelic(player, id, false);
								ctx.getSource().sendFeedback(() -> Text.literal(ok
									? "Gave relic " + def.name
									: "Unknown relic or no active run."), false);
								return ok ? 1 : 0;
							})))
					.then(CommandManager.literal("modifier")
						.then(CommandManager.argument("id", StringArgumentType.word())
							.suggests((ctx, builder) -> CommandSource.suggestMatching(
								ModifierRegistry.all().stream().map(m -> m.id).toList(), builder))
							.executes(ctx -> {
								ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
								String id = StringArgumentType.getString(ctx, "id");
								boolean ok = RunManager.debugSetModifier(player, id);
								ModifierDef def = ModifierRegistry.get(id);
								ctx.getSource().sendFeedback(() -> Text.literal(ok
									? "Modifier is now " + def.name
									: "Unknown modifier or no active run."), false);
								return ok ? 1 : 0;
							})))
					.then(CommandManager.literal("shrine").executes(ctx -> {
						ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
						String message = com.roguelite.core.Extraction.placeShrine(player, ctx.getSource().getWorld());
						ctx.getSource().sendFeedback(() -> Text.literal(message), false);
						return 1;
					}))
					.then(CommandManager.literal("vault").executes(ctx -> {
						ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
						String message = com.roguelite.core.Caches.place(player, ctx.getSource().getWorld(), com.roguelite.core.CacheRules.Kind.VAULT);
						ctx.getSource().sendFeedback(() -> Text.literal(message), false);
						return 1;
					}))
					.then(CommandManager.literal("cache").executes(ctx -> {
						ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
						String message = com.roguelite.core.Caches.place(player, ctx.getSource().getWorld(), com.roguelite.core.CacheRules.Kind.CACHE);
						ctx.getSource().sendFeedback(() -> Text.literal(message), false);
						return 1;
					}))
					.then(CommandManager.literal("grant")
						.then(CommandManager.argument("amount", IntegerArgumentType.integer(1, 1000))
							.executes(ctx -> {
								int amount = IntegerArgumentType.getInteger(ctx, "amount");
								try {
									MetaEconomy.debugGrant(amount);
								} catch (IOException e) {
									Roguelite.LOGGER.error("debug grant failed", e);
									ctx.getSource().sendFeedback(() -> Text.literal("Could not save profile."), false);
									return 0;
								}
								ctx.getSource().sendFeedback(
									() -> Text.literal("Balance is now " + MetaEconomy.balance() + " " + Roguelite.CURRENCY_SYMBOL), false);
								return 1;
							}))));
			}

			dispatcher.register(root);
		});
	}
}

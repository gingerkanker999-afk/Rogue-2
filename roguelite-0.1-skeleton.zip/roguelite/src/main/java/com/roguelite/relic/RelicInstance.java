package com.roguelite.relic;

/** One relic owned during a run. The instance id is unique, so duplicates and wagers can target a specific copy. */
public class RelicInstance {
	public String instanceId;
	public String relicId;

	public RelicInstance() {}

	public RelicInstance(String instanceId, String relicId) {
		this.instanceId = instanceId;
		this.relicId = relicId;
	}
}

package com.roguelite.relic;

import com.google.gson.reflect.TypeToken;
import com.roguelite.Roguelite;
import com.roguelite.data.DefinitionLoader;
import com.roguelite.effect.RunEffect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public final class RelicRegistry {
	private static final Map<String, RelicDef> DEFS = new LinkedHashMap<>();
	private static final Map<String, RunEffect> EFFECTS = new HashMap<>();

	private RelicRegistry() {}

	public static void load() {
		DEFS.clear();
		List<RelicDef> list = DefinitionLoader.loadList("relics.json", new TypeToken<List<RelicDef>>() {}.getType());
		for (RelicDef def : list) {
			if (def == null || def.id == null || def.id.isBlank()) {
				Roguelite.LOGGER.warn("Skipping relic with no id");
				continue;
			}
			if (DEFS.putIfAbsent(def.id, def) != null) {
				Roguelite.LOGGER.warn("Duplicate relic id '{}' ignored", def.id);
			}
		}
		Roguelite.LOGGER.info("Loaded {} relics", DEFS.size());
	}

	/** Attach real gameplay to a relic id. Not used yet - every relic is NO_OP in the skeleton. */
	public static void registerEffect(String relicId, RunEffect effect) {
		EFFECTS.put(relicId, effect);
	}

	public static RunEffect effectFor(String relicId) {
		return EFFECTS.getOrDefault(relicId, RunEffect.NO_OP);
	}

	public static RelicDef get(String id) {
		return id == null ? null : DEFS.get(id);
	}

	public static Collection<RelicDef> all() {
		return DEFS.values();
	}

	/** Weighted roll of one relic, skipping the given ids. Null if nothing is left to roll. */
	public static RelicDef rollOne(Random random, Set<String> exclude) {
		List<RelicDef> candidates = new ArrayList<>();
		int total = 0;
		for (RelicDef def : DEFS.values()) {
			if (def.weight > 0 && !exclude.contains(def.id)) {
				candidates.add(def);
				total += def.weight;
			}
		}
		if (candidates.isEmpty()) return null;
		int pick = random.nextInt(total);
		for (RelicDef def : candidates) {
			pick -= def.weight;
			if (pick < 0) return def;
		}
		return candidates.get(candidates.size() - 1);
	}
}

package com.roguelite.relic;

/** Data definition of a relic (loaded from relics.json). Gameplay lives in a RunEffect registered separately. */
public class RelicDef {
	public String id;
	public String name;
	public String description;
	public String rarity = "common";
	public int weight = 1;
	/** Whether it can be put up as a Blackjack wager. */
	public boolean wagerable = true;
	/** Whether it lasts for the whole run once obtained. */
	public boolean permanent = true;
	/** Free-form hint about how it is obtained ("any" in 0.1). */
	public String acquisition = "any";
}

package com.roguelite.modifier;

import com.google.gson.reflect.TypeToken;
import com.roguelite.Roguelite;
import com.roguelite.data.DefinitionLoader;
import com.roguelite.effect.RunEffect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public final class ModifierRegistry {
	private static final Map<String, ModifierDef> DEFS = new LinkedHashMap<>();
	private static final Map<String, RunEffect> EFFECTS = new HashMap<>();

	private ModifierRegistry() {}

	public static void load() {
		DEFS.clear();
		List<ModifierDef> list = DefinitionLoader.loadList("modifiers.json", new TypeToken<List<ModifierDef>>() {}.getType());
		for (ModifierDef def : list) {
			if (def == null || def.id == null || def.id.isBlank()) {
				Roguelite.LOGGER.warn("Skipping modifier with no id");
				continue;
			}
			if (DEFS.putIfAbsent(def.id, def) != null) {
				Roguelite.LOGGER.warn("Duplicate modifier id '{}' ignored", def.id);
			}
		}
		Roguelite.LOGGER.info("Loaded {} modifiers", DEFS.size());
	}

	/** Attach real gameplay to a modifier id. Not used yet - every modifier is NO_OP in the skeleton. */
	public static void registerEffect(String modifierId, RunEffect effect) {
		EFFECTS.put(modifierId, effect);
	}

	public static RunEffect effectFor(String modifierId) {
		return EFFECTS.getOrDefault(modifierId, RunEffect.NO_OP);
	}

	public static ModifierDef get(String id) {
		return id == null ? null : DEFS.get(id);
	}

	public static Collection<ModifierDef> all() {
		return DEFS.values();
	}

	public static boolean hasPool(String pool) {
		return DEFS.values().stream().anyMatch(d -> pool != null && pool.equals(d.category));
	}

	public static String poolLabel(String pool) {
		if (pool == null) return "None";
		return switch (pool) {
			case "basic" -> "Basic";
			case "good_bad" -> "Good/Bad";
			case "duality" -> "Duality";
			case "luck" -> "Luck";
			default -> pool;
		};
	}

	/** Weighted roll from a pool; null if the pool is empty or unknown. */
	public static ModifierDef roll(String pool, Random random) {
		List<ModifierDef> candidates = new ArrayList<>();
		int total = 0;
		for (ModifierDef def : DEFS.values()) {
			if (pool != null && pool.equals(def.category) && def.weight > 0) {
				candidates.add(def);
				total += def.weight;
			}
		}
		if (candidates.isEmpty()) return null;
		int pick = random.nextInt(total);
		for (ModifierDef def : candidates) {
			pick -= def.weight;
			if (pick < 0) return def;
		}
		return candidates.get(candidates.size() - 1);
	}
}

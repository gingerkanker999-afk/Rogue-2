package com.roguelite.modifier;

import java.util.random.RandomGenerator;

/**
 * Daily Roll (Luck): a six-sided effect for each in-game day. Faces 1-3 are curses, 4-6 are blessings.
 * Luck gives a bad roll a chance to be re-rolled, keeping the better result, so Luck never makes a day worse.
 */
public final class DailyRoll {
	public record Effect(int face, String name, double mining, double movement, double attack) {}

	public static final int MAX_LUCK = 20;

	private static final Effect[] TABLE = {
		new Effect(1, "Harsh curse", -0.40, -0.20, 0.0),
		new Effect(2, "Moderate curse", -0.20, 0.0, 0.0),
		new Effect(3, "Mild curse", 0.0, -0.10, 0.0),
		new Effect(4, "Mild blessing", 0.0, 0.10, 0.0),
		new Effect(5, "Strong blessing", 0.30, 0.0, 0.20),
		new Effect(6, "Major blessing", 0.50, 0.10, 0.30),
	};

	private DailyRoll() {}

	public static Effect effect(int face) {
		if (face < 1 || face > 6) throw new IllegalArgumentException("face must be 1-6, got " + face);
		return TABLE[face - 1];
	}

	/** Rolls a face. With Luck L (clamped to 0-20), a face of 1-3 gets an L/20 chance to be re-rolled and kept if better. */
	public static int roll(RandomGenerator rng, int luck) {
		int face = 1 + rng.nextInt(6);
		int clamped = Math.max(0, Math.min(MAX_LUCK, luck));
		if (face <= 3 && clamped > 0 && rng.nextInt(MAX_LUCK) < clamped) {
			face = Math.max(face, 1 + rng.nextInt(6));
		}
		return face;
	}
}

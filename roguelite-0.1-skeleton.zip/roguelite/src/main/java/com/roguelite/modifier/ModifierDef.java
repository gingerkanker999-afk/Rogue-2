package com.roguelite.modifier;

/** Data definition of a modifier (loaded from modifiers.json). Gameplay lives in a RunEffect registered separately. */
public class ModifierDef {
	public String id;
	public String name;
	public String description;
	/** Pool this modifier is rolled from: basic, good_bad, duality or luck. */
	public String category;
	public String rarity = "common";
	/** Relative roll weight inside its pool. */
	public int weight = 1;
}

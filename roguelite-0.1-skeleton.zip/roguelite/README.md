# Roguelite (Fabric mod, Minecraft Java 1.21.11)

A roguelite layer on top of normal Minecraft: buy a starter with meta currency, get a modifier (and maybe a relic),
play, die, bank your score as meta currency, buy the next starter.

**Status: 0.1 vertical skeleton.** Run lifecycle, persistent profile, starter purchase and the death -> reward ->
summary flow work end to end *in design*. Modifier and relic *effects* are intentionally NOT implemented yet
(they are data + empty hooks). **This code has never been compiled** - see "Unverified" below.

## Requirements
- JDK 21
- Minecraft 1.21.11, Fabric Loader >= 0.18.4, Fabric API 0.141.3+1.21.11, Yarn 1.21.11+build.4, Loom 1.14 (needs Gradle 9.2+)

## Build online (no Gradle needed)
Push this folder to a GitHub repo. The included workflow (`.github/workflows/build.yml`) builds it on GitHub's servers:
Actions tab -> latest run -> Artifacts -> `roguelite-jar`. Use the jar that does NOT end in `-sources`.

## Build and run locally
The Gradle wrapper **JAR and scripts are not included** (could not be generated offline). Do one of:
- Open the folder in IntelliJ IDEA (it reads `gradle/wrapper/gradle-wrapper.properties`), or
- With Gradle 9.2+ installed, run `gradle wrapper --gradle-version 9.2.0` once, then use `./gradlew`.

```
./gradlew build          # jar in build/libs/
./gradlew runClient      # dev client (debug commands are enabled automatically)
```

## Playtest checklist (the 0.1 loop)
1. Launch, create a new survival world, join. After ~1.5 s the starter screen opens (balance 5).
2. Pick BAREBONES (free) or SCAVENGER (5), Start Run. You get the kit and a chat message with your modifier.
3. `/roguelite status` shows the run, the balance before it, and the score so far. Die (or `/roguelite debug end`).
4. Respawn -> spectator + summary screen with reward lines. Balance went up exactly once.
5. Create another world: the profile balance carried over; buy the next starter.
Re-joining the dead world shows the summary again and never pays twice.

Debug commands (`/roguelite debug end`, `/roguelite debug grant <n>`) are only registered if you create an empty file named
`debug` in `config/roguelite/` (then re-enter the world), or launch with `-Droguelite.debug=true`, or run in a dev environment.

## Never locked out
- BAREBONES costs 0, so a run is always possible. (Extra safety net in code: if you ever cannot afford the cheapest starter, it is free.)
- Esc or "Not now" closes the starter screen. Type `/roguelite start` to reopen it (or rejoin the world).

## Resetting your profile
Deleting worlds does not reset anything: the meta currency lives in `<minecraft folder>/config/roguelite/profile.json`.
Delete that file (with the game closed) to get a fresh profile with 5 currency. Or use `/roguelite debug grant <n>`
when debug commands are enabled (see above).

## Where state lives
| What | Where |
|---|---|
| Meta balance, run-id counter, banked run ids, schema version | `<minecraft>/config/roguelite/profile.json` (global) |
| Active/ended run (starter, modifier, relics, stats, reward) | `<world>/roguelite/run.json` (per world) |

A copied world carries its `run.json`, but the profile remembers every banked run id, so it cannot pay out twice
on the same profile. (Copying the world to a *different* profile can; that is unavoidable without a server.)
Corrupt files are renamed `*.corrupt-<time>`, never deleted.

## Balancing without recompiling
Built-in defaults are in `src/main/resources/data/roguelite/defs/` (`starters.json`, `modifiers.json`,
`relics.json`, `rewards.json`). Put a file with the same name in `config/roguelite/` to override it.

## Code map
```
core/      RunManager (lifecycle), RunState, WorldRunStore, StartResult
profile/   ProfileData, ProfileStore (global JSON, atomic writes)
economy/   MetaEconomy (spend/allocate run id, bank once, refund)
starter/   StarterDef, StarterRegistry
modifier/  ModifierDef, ModifierRegistry (weighted roll by pool)
relic/     RelicDef, RelicInstance, RelicRegistry
effect/    RunEffect  <- the one extension point for modifier/relic gameplay
reward/    RewardTable, RewardCalculator
item/      RogueliteItems (placeholder chip / Dealer's Deck)
net/       payloads + server receiver
client/    StarterSelectScreen, RunSummaryScreen, RogueliteClient
command/   /roguelite status (+ debug)
```

## Adding an effect later
Register a `RunEffect` for the id (`ModifierRegistry.registerEffect("pack_rat", ...)`) and hook gameplay with Fabric
events that read `RunManager.activeRun()` / `activeEffects()`. The Run Manager does not change.
`onActivate` runs at run start, relic grant, and every owner join, so it must be idempotent.

## Blackjack engine (pure Java, tested)
`com.roguelite.gambling.blackjack` has no Minecraft code and 23 unit tests (`src/test/java`, run by `gradle build`).
- Round state machine: BETTING -> PLAYER_TURN -> DEALER_TURN -> SETTLED. `BlackjackTable` keeps one shoe per session.
- Rules: 6 decks (reshuffle under 52 cards), dealer stands on all 17s, blackjack pays 3:2 (rounded down), hit / stand /
  double on any first two cards, no splits, no insurance. Dealer checks for a natural immediately.
- Wagers: `ChipWager(amount)` or `RelicWager(instanceId)`. The engine never touches inventories: the server escrows the
  stake up front and pays out `Settlement.chipPayout`. Relic result: KEPT / WON (keep + choose 1 of 2 new) / LOST.
- Hollow Coin = `freeSurrenders` on the table; a free surrender refunds the full stake (or keeps the relic).
- `GameView` hides the dealer's hole card until the player's turn ends, so the client cannot peek.
- There is no Luck input anywhere, by design. The shoe is shuffled only by the RandomGenerator you pass in.
See "Gambling in the game" below for the wiring.

## Cee-lo engine (pure Java, tested)
`com.roguelite.gambling.ceelo`: street dice against the dealer. 19 unit tests; `Wager` and `RelicOutcome` are shared
with Blackjack in `com.roguelite.gambling`.
- Three dice. 4-5-6 = auto win, 1-2-3 = auto loss, three of a kind = triple (higher wins), a pair plus an odd die =
  the odd die is your point (1-6). Anything else rerolls.
- Banker rules: the dealer rolls first in the open. Dealer 4-5-6 or triple wins at once (the player never rolls),
  dealer 1-2-3 loses at once, otherwise the dealer has a point and the player rolls. Pays 1:1, equal points push.
- Exact house edge is 1/108 (about 0.93%); the test enumerates all 108 scoring rolls to prove it.
- Intentionally NO raise/double after seeing the dealer's roll: doubling when the dealer's point is 1-3 would give
  the player a large edge (about +19% per unit with a simple strategy) and let chips be farmed.
- IMPORTANT for the server wiring (applies to Blackjack too): closing the screen or disconnecting mid-round must
  force the round to finish (Cee-lo: roll for the player; Blackjack: stand), never refund the stake.
- `DiceSource` lets tests script exact dice. No Luck input anywhere.
See "Gambling in the game" below for the wiring.

## Gambling in the game
Right-click the **Dealer's Deck** (a renamed paper item in the Gambler and High Roller kits) during your own active run.
- `gambling/session/GamblingSession` (pure Java, 23 tests) runs the whole visit: menu -> pick Blackjack or Cee-lo -> bet
  -> play -> result -> play again. It answers every action with a `ScreenModel` (title, lines, buttons).
- The client `GamblingScreen` is a dumb renderer of that model; every button just sends an action string back.
  The server checks each action against the session state, range-checks bets (1-100) and escrows them.
- Chips = gold nuggets named "Gambling Chip" in your inventory. The stake is taken when you bet and the payout is
  handed back when the round settles. Doubling takes a second stake.
- Relic wagers: pick "Wager relic: X". Loss removes the relic for the run. Win keeps it and offers a choice of 2 new relics.
  Push or surrender returns it. Relics won this way do not pay the "relic found" run reward.
- Hollow Coin gives the table one free surrender per coin owned.
- Esc, the Leave button or a disconnect finishes the round for you (Blackjack: stand, Cee-lo: roll) and never refunds.
- If you die, the table session is dropped (the run is over).

## Implemented vs stubbed
Implemented: profile + 5 starting balance, atomic transactions, run ids, per-world run file, starter registry and
JSON kits, purchase validation (server re-checks everything), modifier roll by starter pool, random starter relic,
starter + summary screens, death -> reward -> bank-once -> spectator -> summary, reward detection for: days survived,
Nether entered, diamond in inventory, relic granted, Ender Dragon/Wither killed.
Stubbed/not done: all modifier + relic effects, structure-found detection
(`RunManager.award("find_structure")` exists but nothing calls it), a "return to menu" button.

## Assumptions and placeholders
- Run storage is a JSON file in the world folder, not Minecraft's `PersistentState` (that API changed in 1.21.5; avoided).
- Gambling chip = renamed gold nugget, Dealer's Deck = renamed paper, both tagged with custom data. Not real items yet.
- "Relic materials" in kits = amethyst shards; Luck values (0/3/8) and chip counts (10/25) are placeholders.
- Meta currency symbol is `◆` (the planned emoji does not render in the default font). One constant: `Roguelite.CURRENCY_SYMBOL`.
- Screens open ~30 ticks after join so the terrain-loading screen does not close them.
- A dead world cannot start a new run; make a new world (matches the "no world reset yet" decision).
- Only the player who bought the starter (owner) can end the run by dying.

## Unverified (compile fixes most likely needed here)
Written against Yarn 1.21.11 from memory; exact names may differ by build. First places to look if it fails to compile:
- `ServerPlayNetworkHandler.getPlayer()` (RogueliteEvents)
- `PlayerInventory.offerOrDrop`, `PlayerInventory.count(Item)` (RunManager)
- `DamageSource.getDeathMessage(LivingEntity)` (RunManager)
- `ServerCommandSource.getPlayerOrThrow()`, `sendFeedback(Supplier, boolean)` (commands)
- `Screen.clearAndInit()`, `TextRenderer.wrapLines`, `DrawContext.drawCenteredTextWithShadow` / `drawTextWithShadow(OrderedText)` (client screens)
- `Identifier.tryParse`, `Registries.ITEM.containsId` (RogueliteItems)
- Do not call `renderBackground` in screens: 1.21.x renders it inside `Screen.render` (calling it twice can crash with a blur error).
- Loom version string `1.14-SNAPSHOT` and Gradle 9.2.0 are best guesses for 1.21.11.
